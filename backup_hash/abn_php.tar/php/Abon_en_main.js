var edit_row_id=0;
var on_progress=0;

jQuery(function(){ 

  jQuery('#client_table').jqGrid({
    url:'Abon_en_main_data.php',
    editurl: '',
    datatype: 'json',
    mtype: 'POST',
    //height:500,
    //width:800,
    autowidth: true,
    scroll: 0,
    colNames:['Код','Книга','Особ.рахунок','Адреса','Абонент','Прим.','Арх'],
    colModel :[ 
      {name:'id', index:'id', width:40, editable: false, align:'center', key:true, hidden:true},     
      {name:'book', index:'book', width:50, editable: true, align:'left',edittype:'text'},           
      {name:'code', index:'code', width:50, editable: true, align:'left',edittype:'text'},                 
      {name:'addr', index:'addr', width:200, editable: true, align:'left',edittype:'text'},           
      {name:'abon', index:'abon', width:200, editable: true, align:'left',edittype:'text'},
      {name:'note', index:'note', width:100, editable: true, align:'left',edittype:'text'},
      {name:'archive', index:'archive', width:30, editable: false, align:'right',hidden:true,
          formatter:'checkbox',edittype:'checkbox'}
                            
    ],
    pager: '#client_tablePager',
    rowNum:50,
    rowList:[20,50,100,300,500],
    sortname: 'book',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: 'Абоненти',
    postData:{'arch_mode': 0},
    //hiddengrid: false,
    hidegrid: false,

    gridComplete:function(){
    on_progress=0;
    if ($(this).getDataIDs().length > 0) 
    {      
     var first_id = parseInt($(this).getDataIDs()[0]);
     $(this).setSelection(first_id, true);
    }
   },

   onSelectRow: function(rowid) { 
        edit_row_id = rowid; 
    },

    
    ondblClickRow: function(id){ 
      //jQuery(this).editGridRow(id,{width:300,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});  
    
    var gsr = jQuery(this).jqGrid('getGridParam','selrow'); 
      if(gsr)
      { 

        edit_row_id = id;
        $("#fpaccnt_params").find("#pmode").attr('value',0 );
        $("#fpaccnt_params").find("#pid_paccnt").attr('value',id );

        $("#fpaccnt_params").find("#ppaccnt_info").attr('value',
            $("#client_table").jqGrid('getCell',edit_row_id,'book')+'/'+
            $("#client_table").jqGrid('getCell',edit_row_id,'code')+
            $("#client_table").jqGrid('getCell',edit_row_id,'abon')      );
        $("#fpaccnt_params").attr('target',"_blank" );           
        $("#fpaccnt_params").attr("action","Abon_en_paccnt.php");                  
        document.paccnt_params.submit();
        
      } else {alert("Please select Row")}       
      
    } ,  
      
  loadError : function(xhr,st,err) {jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText);}

  }).navGrid('#client_tablePager',
        {edit:false,add:false,del:false},
        {}, 
        {}, 
        {}, 
        {} 
        ); 


jQuery('#client_table').jqGrid('navButtonAdd','#client_tablePager',{id:'btn_active', 
  caption:'Активні', title:"Тільки активні абоненти",
	onClickButton:function(){
            if (on_progress==0)
                {
                    on_progress=1;
                    jQuery('#btn_active').addClass('navButton_selected') ;
                    jQuery('#btn_archive').removeClass('navButton_selected') ;
                    jQuery('#btn_all').removeClass('navButton_selected') ;
                    jQuery("#client_table").jqGrid('hideCol',["archive"]);    
                    jQuery('#client_table').jqGrid('setGridParam',{'postData':{'arch_mode':0}}).trigger('reloadGrid');        
                    innerLayout.resizeAll();
                }
        } 
    });        
jQuery('#btn_active').addClass('navButton_selected') ;    
//jQuery('#btn_active').css('border','1px solid #999999');    
//jQuery('#btn_active').css('margin','-1px');    

//jQuery('#btn_active_text').css('font-weight','bold');    
//jQuery('#btn_active').addClass('ui-state-hover');
    
jQuery('#client_table').jqGrid('navButtonAdd','#client_tablePager',{id:'btn_archive',caption:"Архів", title:"Тільки архів",
	onClickButton:function(){ 
            if (on_progress==0)
                {
                    on_progress=1;
            
                    jQuery('#btn_active').removeClass('navButton_selected') ;
                    jQuery('#btn_archive').addClass('navButton_selected') ;
                    jQuery('#btn_all').removeClass('navButton_selected') ;
                    jQuery("#client_table").jqGrid('hideCol',["archive"]);                                        
                    jQuery('#client_table').jqGrid('setGridParam',{'postData':{'arch_mode':1}}).trigger('reloadGrid');                    
                    innerLayout.resizeAll();
                }
         } 
    });        
jQuery('#client_table').jqGrid('navButtonAdd','#client_tablePager',{
    id:'btn_all',   caption:"Всі",    title:"Показати всіх абонентів",
    onClickButton:function(){ 
        if (on_progress==0)
        {
            on_progress=1;
            jQuery('#btn_active').removeClass('navButton_selected') ;
            jQuery('#btn_archive').removeClass('navButton_selected') ;
            jQuery('#btn_all').addClass('navButton_selected') ;
            jQuery("#client_table").jqGrid('showCol',["archive"]);                            
            jQuery('#client_table').jqGrid('setGridParam',{'postData':{'arch_mode':2}}).trigger('reloadGrid');                    
            innerLayout.resizeAll();
        }
    } 
});        



jQuery("#client_table").jqGrid('filterToolbar','');

    outerLayout = $("body").layout({
		name:	"outer" 
	,	north__paneSelector:	"#pmain_header"
	,	north__closable:	false
	,	north__resizable:	false
        ,	north__size:		40
	,	north__spacing_open:	0
	,	south__paneSelector:	"#pmain_footer"
	,	south__closable:	true
	,	south__resizable:	false
        ,	south__size:		40
	,	south__spacing_open:	0
	,	center__paneSelector:	"#pmain_content"
	//,	center__onresize:		'innerLayout.resizeAll'
	,	resizeWhileDragging:	true
	,	autoBindCustomButtons:	true
	});

    innerLayout = $("#pmain_content").layout({
		name:			"inner" 
	,	north__paneSelector:	"#pwork_header"
	,	north__closable:	true
	,	north__resizable:	true
        ,	north__size:		100
        ,	center__paneSelector:	"#pwork_grid"
	,	autoBindCustomButtons:	true
	,       center__onresize:	function (pane, $pane, state, options) 
        {
            jQuery("#client_table").jqGrid('setGridWidth',$pane.innerWidth()-9);
            jQuery("#client_table").jqGrid('setGridHeight',$pane.innerHeight()-142);
        }
        
	});
        
    innerLayout.resizeAll();
    innerLayout.hide('north');        
        
    jQuery(".btn").button();
    jQuery(".btnSel").button({icons: {primary:'ui-icon-folder-open'}});
        
   $("#debug_ls1").click( function() {jQuery("#message_zone").dialog('open');});
   $("#debug_ls2").click( function() {jQuery("#message_zone").dialog('close');});
   $("#debug_ls3").click( function() {jQuery("#message_zone").html('');});
   
   $("#message_zone").dialog({autoOpen: false});
   
   
   //-------------------------------------------------------------
   $("#pActionBar").find("#bt_add").click( function(){ 

        $("#fpaccnt_params").find("#pmode").attr('value',1 );
        $("#fpaccnt_params").find("#pid_paccnt").attr('value',0 );

        $("#fpaccnt_params").attr('target',"_blank" );           
        $("#fpaccnt_params").attr("action","Abon_en_paccnt.php");          
        
        document.paccnt_params.submit();
   });
   //-------------------------------------------------------------
   $("#pActionBar").find("#bt_edit").click( function(){ 

        if ($('#client_table').getDataIDs().length > 0) 
        {
          $("#fpaccnt_params").find("#pmode").attr('value',0 );
          
          $("#fpaccnt_params").find("#pid_paccnt").attr('value',edit_row_id );
          $("#fpaccnt_params").find("#ppaccnt_info").attr('value',
            $("#client_table").jqGrid('getCell',edit_row_id,'book')+'/'+
            $("#client_table").jqGrid('getCell',edit_row_id,'code')+' '+
            $("#client_table").jqGrid('getCell',edit_row_id,'abon')      );
          $("#fpaccnt_params").attr('target',"_blank" );           
          $("#fpaccnt_params").attr("action","Abon_en_paccnt.php");          
          
          document.paccnt_params.submit();
        }
   });
   //-------------------------------------------------------------
   $("#pActionBar").find("#bt_saldo").click( function(){ 

        if ($('#client_table').getDataIDs().length > 0) 
        {
          $("#fpaccnt_params").find("#pmode").attr('value',0 );
          $("#fpaccnt_params").find("#pid_paccnt").attr('value',edit_row_id );
          $("#fpaccnt_params").find("#ppaccnt_info").attr('value',
            $("#client_table").jqGrid('getCell',edit_row_id,'book')+'/'+
            $("#client_table").jqGrid('getCell',edit_row_id,'code')+' '+ 
            $("#client_table").jqGrid('getCell',edit_row_id,'abon')      );
          $("#fpaccnt_params").attr('target',"_blank" );  
          $("#fpaccnt_params").attr("action","Abon_en_saldo.php");                    
          
          document.paccnt_params.submit();
        }
   });
   //-------------------------------------------------------------

   $("#pActionBar").find("#bt_bills").click( function(){ 

          $("#fpaccnt_params").find("#pmode").attr('value',0 );
          $("#fpaccnt_params").find("#pid_paccnt").attr('value',edit_row_id );
          $("#fpaccnt_params").attr('target',"_blank" );  
          $("#fpaccnt_params").attr("action","Abon_en_bills.php");                    
          
          document.paccnt_params.submit();
   });
   //-------------------------------------------------------------

  $("#pActionBar").find("#bt_abons").click( function(){ 
        window.open ('dov_abon.php','_self',false)
   });

});
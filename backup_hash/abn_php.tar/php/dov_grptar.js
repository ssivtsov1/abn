jQuery(function() { 
  jQuery('#dov_grptar_table').jqGrid({
    url:'Dov_list3_grid.php',
    editurl: 'Dov_list3_edit.php',
    datatype: 'json',
    mtype: 'POST',
    height:400,
    width:400,
    colNames:['id','сумма мин','сумма макс','лим мин','лим макс','дата открытия','дата закрытия','период мин',
    'период макс','текст'],
    colModel:[
    {
      name:'id', 
      index:'id', 
      width:40, 
      editable: false, 
      align:'center', 
      key:true
    },
    {
      name:'sum_min',  
      index:'sum_min', 
      width:50, 
      editable: true, 
      align:'right'
    },
    {
      name:'sum_max', 
      index:'sum_max', 
      width:50, 
      editable: true, 
      align:'right'
    },
    {
      name:'lim_min', 
      index:'lim_min', 
      width:60, 
      editable: true, 
      align:'right'
    },
    {
      name:'lim_max', 
      index:'lim_max', 
      width:60, 
      editable: true, 
      align:'right'
    },
    {
      name:'dt_b', 
      index:'dt_b', 
      width:60, 
      editable: true, 
      align:'right'
    },
    {
      name:'dt_e', 
      index:'dt_e', 
      width:60, 
      editable: false, 
      align:'right'
    },
    {
      name:'per_min', 
      index:'per_min', 
      width:60, 
      editable: true, 
      align:'right'
    },
    {
      name:'per_max', 
      index:'per_max', 
      width:60, 
      editable: true, 
      align:'right'
    },
    {
      name:'name', 
      index:'name', 
      width:60, 
      editable: true, 
      align:'right'
    }
    ],
    pager: '#dov_grptar_tablePager',
    autowidth: true,
    rowNum:50,
    rowList:[20,50,100,300,500],
    sortname: 'id',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: 'Тарифы',
    hidegrid: false,
    
    ondblClickRow: function(id){ 
      jQuery(this).editGridRow(id,{
        width:400,
        height:500,
        reloadAfterSubmit:true,
        closeAfterAdd:true,
        closeAfterEdit:true
      });
    } ,  


    loadError : function(xhr,st,err) {
      jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText);
    }
  
  //  jsonReader : { repeatitems: false }

  }).navGrid('#dov_grptar_tablePager',
  {
    edit:true,
    add:true,
    del:true
  },
  {
    width:400,
    height:500,
    reloadAfterSubmit:false,
    closeAfterAdd:true,
    closeAfterEdit:true
    
  }, 
  {
    width:400,
    height:500,
    reloadAfterSubmit:false,
    closeAfterAdd:true,
    closeAfterEdit:true
  }, 
  {
    reloadAfterSubmit:false
  }, 
  {} 
  ); 

  jQuery('#dov_grptar_table').jqGrid('filterToolbar','');
  jQuery("#dov_grptar_table").jqGrid('bindKeys', {
    "onEnter":function( id ) { 
      jQuery(this).editGridRow(id,{
        width:400,
        height:500,
        reloadAfterSubmit:false,
        closeAfterAdd:true,
        closeAfterEdit:true
      });
    }
  } );
});

function processAfterEdit(response, postdata) {
  if (response.responseText=='') {
    return [true,''];
  } else {
    errorInfo = jQuery.parseJSON(response.responseText);
    if (errorInfo.errcode==0) {
      return [true,errorInfo.errstr]
    }; 
             
    if (errorInfo.errcode==1) {
      jQuery('#message_zone').append(errorInfo.errstr);  
      jQuery('#message_zone').append('<br>');  
      jQuery('#message_zone').dialog('open');
      return [true,errorInfo.errstr]
    };              
               
    if (errorInfo.errcode==2) {
      jQuery('#message_zone').append(errorInfo.errstr);  
      jQuery('#message_zone').append('<br>');                 
     
      return [false,errorInfo.errstr]
    };              
  }
}

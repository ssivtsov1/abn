var validator_lgt = null;
var lgt_form_options;
var lgt_list_mode;
var cur_lgt_id = null;
var fLgtParam_ajaxForm;
var lgt_hist_visible =0;
var isLgtHistGridCreated = false;

jQuery(function(){ 
/*    
  setTimeout(function(){
      if (mode == 0)
        {
         jQuery('#paccnt_meter_zones_table').trigger('reloadGrid');              
        } 
  },300);  
*/  
  //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\  
  jQuery('#paccnt_lgt_table').jqGrid({
    url:     'Abon_en_paccnt_lgt_data.php',
    editurl: 'Abon_en_paccnt_lgt_edit.php',
    datatype: 'json',
    mtype: 'POST',
    height:100,
    width:800,
    autowidth: true,
    scroll: 0,
    colNames:[], 
    colModel :[  
      {label:'id',name:'id', index:'id', width:40, editable: false, align:'center', key:true, hidden:true},     
      {label:'id_paccnt',name:'id_paccnt', index:'id_paccnt', width:40, editable: false, align:'center', hidden:true},           
      {label:'id_grp_lgt',name:'id_grp_lgt', index:'id_grp_lgt', width:40, editable: false, align:'center', hidden:true},                 
      {label:'id_calc',name:'id_calc', index:'id_calc', width:40, editable: false, align:'center', hidden:true},                       
      
      {label:'Пільга',name:'grp_lgt', index:'grp_lgt', width:150, editable: false, align:'center', hidden:false},                       
      {label:'Метод розрах.',name:'calc_name', index:'calc_name', width:100, editable: false, align:'center', hidden:true},                       
      {label:"Кільк.сім'ї",name:'family_cnt', index:'family_cnt', width:100, editable: false, align:'center', hidden:false},                             

      {label:'Приор.',name:'prior_lgt', index:'prior_lgt', width:30, editable: true, align:'left',edittype:'text'},           

      {label:'Особа',name:'fio_lgt', index:'fio_lgt', width:300, editable: true, align:'left',edittype:'text',hidden:true},           
      
      {label:'Документ',name:'id_doc', index:'id_doc', width:100, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:ldocs},stype:'text'},                       
      
      {label:'Серія',name:'s_doc', index:'s_doc', width:50, editable: true, align:'left',edittype:'text'},                 
      {label:'Номер',name:'n_doc', index:'n_doc', width:50, editable: true, align:'left',edittype:'text'},           
      
      {label:'Дата док.',name:'dt_doc', index:'dt_doc', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      
      {label:'ІНН',name:'ident_cod_l', index:'ident_cod_l', width:80, editable: true, align:'left',edittype:'text',hidden:true},           
      
      {label:'Дата перереєстр.',name:'dt_reg', index:'dt_reg', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},      
      
      {label:'Дата початку',name:'dt_start', index:'dt_start', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},      
      {label:'Дата закінч.',name:'dt_end', index:'dt_end', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      {label:'dt',name:'dt', index:'dt', width:100, editable: true, align:'left', formatter:'date',
            formatoptions:{ srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i' }}
    ],
    pager: '#paccnt_lgt_tablePager',
    rowNum:100,
    sortname: 'dt_start',
    sortorder: 'asc',
    viewrecords: true,
    pgbuttons: false,
    pgtext: null, 
    gridview: true,
    caption: '',
    hidegrid: false,
    postData:{'p_id': id_paccnt, 'hist_mode': 0},
    jsonReader : {repeatitems: false},
 
    onSelectRow: function(id) { 
      cur_lgt_id = id;  
      
      var gsr = jQuery(this).jqGrid('getGridParam','selrow'); 
      if(gsr)
      { 

       if (lgt_hist_visible==0)
       {    
          validator_lgt.resetForm();  //для сброса состояния валидатора
          $("#fLgtParam").resetForm();
          $("#fLgtParam").clearForm();
          
          jQuery(this).jqGrid('GridToForm',gsr,"#fLgtParam"); 
          $("#fLgtParam").find("#foper").attr('value','edit');    
          CommitJQFormVal($("#fLgtParam"));

          $("#fLgtParam").find("#bt_add").hide();
          $("#fLgtParam").find("#bt_edit").show();   
          //jQuery('#paccnt_meter_zones_table').jqGrid('setGridParam',{'postData':{'p_id':id}}).trigger('reloadGrid');        
       }   
       else
       {
        jQuery('#hist_lgt_table').jqGrid('setGridParam',{'postData':{'lg_id':id}}).trigger('reloadGrid');                   
       }    
      }
      
    },

        
  loadError : function(xhr,st,err) {jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText);},
  
  gridComplete:function(){

    lgt_list_mode =0; //edit   
    if ($(this).getDataIDs().length > 0) 
    {      
     if (lgt_hist_visible==0)
     {
       $("#pLgtParam").show();        
     }  
     
     var first_id = parseInt($(this).getDataIDs()[0]);
     $(this).setSelection(first_id, true);

    }
    else
    {
        $("#pLgtParam").hide();        
    }
    
  }

  }).navGrid('#paccnt_lgt_tablePager',
        {edit:false,add:false,del:false},
        {}, 
        {}, 
        {}, 
        {} 
        ); 

  //---------------------------------------------------------------------
  jQuery("#pLgtParam :input").addClass("ui-widget-content ui-corner-all");
  
  lgt_form_options = { 
    dataType:"json",
    beforeSubmit: LgtBeforeSubmit, // функция, вызываемая перед передачей 
    success: LgtSubmitResponse // функция, вызываемая при получении ответа
  };

fLgtParam_ajaxForm = $("#fLgtParam").ajaxForm(lgt_form_options);
  
jQuery("#paccnt_lgt_table").jqGrid('navButtonAdd','#paccnt_lgt_tablePager',{caption:"Історія пільг",
	onClickButton:function(){ 

     
       if (lgt_hist_visible==0)
           {
               createLgtHistGrid();
               lgt_hist_visible=1;
               $("#pLgtParam").hide();
               $("#hist_lgt_div").show();
               
              
               //$("#paccnt_meters_table").jqGrid('showCol',["dt_e"]); 
               $("#paccnt_lgt_table").jqGrid('setGridParam',{'postData':{'p_id': id_paccnt, 'hist_mode': 1}}).trigger('reloadGrid');        
               //innerLayout.resizeAll(); 
           }
       else
           {
               lgt_hist_visible=0;

               $("#pLgtParam").show();
               $("#hist_lgt_div").hide();

               //$("#paccnt_meters_table").jqGrid('hideCol',["dt_e"]);                
               $("#paccnt_lgt_table").jqGrid('setGridParam',{'postData':{'p_id': id_paccnt, 'hist_mode': 0}}).trigger('reloadGrid');                       
               //innerLayout.resizeAll(); 
           }
               
          
        ;} 
});


jQuery("#paccnt_lgt_table").jqGrid('navButtonAdd','#paccnt_lgt_tablePager',{caption:"Нова пільга",
	onClickButton:function(){ 

        if (lgt_hist_visible==1)
           {
               lgt_hist_visible=0;

               $("#pLgtParam").show();
               $("#hist_lgt_div").hide();

           }

          $("#pLgtParam").show();        
          
          validator_lgt.resetForm();
          $("#fLgtParam").resetForm();
          $("#fLgtParam").clearForm();
          
          $("#fLgtParam").find("[data_old_value]").attr('value',''); 
          $("#fLgtParam").find("[data_old_value]").attr('data_old_value',''); 

          $("#fLgtParam").find("#fid").attr('value',-1 );    
          $("#fLgtParam").find("#fid_paccnt").attr('value',id_paccnt );  
          $("#fLgtParam").find("#foper").attr('value','add');              
          
          $("#fLgtParam").find("#bt_add").show();
          $("#fLgtParam").find("#bt_edit").hide(); 
          
          $("#lui_paccnt_lgt_table" ).show(); // disable grid
          //meterLayout.close('east');
          lgt_list_mode =1; //insert   
          //jQuery("#dialog_editform").dialog('open');          
          
        ;} 
});

jQuery("#paccnt_lgt_table").jqGrid('navButtonAdd','#paccnt_lgt_tablePager',{caption:"Видалити",
	onClickButton:function(){ 

      if ($("#paccnt_lgt_table").getDataIDs().length == 0) 
       {return} ;    

      if (lgt_hist_visible==1) return;
          
      jQuery("#dialog-confirm").find("#dialog-text").html('Видалити пільгу?');
    
      $("#dialog-confirm").dialog({
			resizable: false,
			height:140,
			modal: true,
                        autoOpen: false,
                        title:'Видалення',
			buttons: {
				"Видалити": function() {
                                        
                                        $("#dialog-changedate").dialog({ 
                                            resizable: false,
                                            height:140,
                                            modal: true,
                                            autoOpen: false,
                                            buttons: {
                                                "Ok": function() {
                                                   var cur_dt_change = jQuery("#dialog-changedate").find("#fdate_change").val();
                                                   fLgtParam_ajaxForm[0].change_date.value = cur_dt_change;
                                                   fLgtParam_ajaxForm[0].oper.value = 'del';
                                                   fLgtParam_ajaxForm.ajaxSubmit(lgt_form_options);       
                                                   

                                                    $( this ).dialog( "close" );
                                                },
                                                "Отмена": function() {
                                                    $( this ).dialog( "close" );
                                                }
                                            }

                                        });
                                        
                                        jQuery("#dialog-changedate").dialog('open');
                                    
					$( this ).dialog( "close" );
				},
				"Відмінити": function() {
					$( this ).dialog( "close" );
				}
			}
		});
    
       jQuery("#dialog-confirm").dialog('open');
          
        ;} 
});

//-------------------------------------------------------------
// опции валидатора 
var lgt_valid_options = { 

		rules: {
			grp_lgt: "required",
                        dt_start: "required"
		},
		messages: {
			grp_lgt: "Виберіть пільгу!",
                        dt_start: "Вкажіть дату початку"
		}
};

validator_lgt = $("#fLgtParam").validate(lgt_valid_options);


//-------------------------------------------------------------
$("#pLgtParam").find("#bt_reset").click( function() 
{
    if (lgt_list_mode==0 )
    {
     validator_lgt.resetForm();
     ResetJQFormVal($("#fLgtParam"));
    } 

    if (lgt_list_mode==1 )
    {
     
        $("#lui_paccnt_lgt_table" ).hide();
        //meterLayout.open('east');
        lgt_list_mode =0; //edit    
        
        if ($("#paccnt_lgt_table").getDataIDs().length > 0) 
        {      
     
             var first_id = parseInt($("#paccnt_lgt_table").getDataIDs()[0]);
            $("#paccnt_lgt_table").setSelection(first_id, true);

        }
        else
        {
            $("#pLgtParam").hide();        
        }
    }
  
});
//------------------------------------------------------------

   jQuery("#btFamily").click( function() { 
       
/*       
    $("#fLgtParam").attr('target',"lgtfamily_win" );           
    $("#fLgtParam").attr('action',"Abon_en_lgtfamily.php" );               
    
     var ww = window.open("Abon_en_lgtfamily.php", "lgtfamily_win", "toolbar=0,width=800,height=600");
     document.fLgtParam.submit();
     ww.focus();
     
    $("#fLgtParam").attr('target',"" );           
    $("#fLgtParam").attr('action',"Abon_en_paccnt_lgt_edit.php" );               
*/     

    createFamilyGrid();

    //jQuery("#grid_lgtfamily").css({'left': jQuery("#btFamily").position().left+1, 'top': jQuery("#btFamily").position().top+20});
    jQuery("#grid_lgtfamily").css({'left': 100, 'top': 300});
    jQuery("#grid_lgtfamily").toggle( );

   });

//------------------------------------------------------
//----------------таблица истории счетчика -------------
var createLgtHistGrid = function(){ 
    
  if (isLgtHistGridCreated) return;
  isLgtHistGridCreated =true;


  jQuery('#hist_lgt_table').jqGrid({
    url:'Abon_en_paccnt_lgt_hist_data.php',
    //editurl: '',
    datatype: 'json',
    mtype: 'POST',
    height:130,
    //width:800,
    autowidth: true,
    shrinkToFit : false,
    scroll: 0,
    colModel :[ 
      {name:'id_key', index:'id_key', width:40, editable: false, align:'center', key:true,hidden:true},

      {label:'id',name:'id', index:'id', width:40, editable: false, align:'center', key:true, hidden:true},     
      {label:'id_paccnt',name:'id_paccnt', index:'id_paccnt', width:40, editable: false, align:'center', hidden:true},           
      {label:'id_grp_lgt',name:'id_grp_lgt', index:'id_grp_lgt', width:40, editable: false, align:'center', hidden:true},                 
      {label:'id_calc',name:'id_calc', index:'id_calc', width:40, editable: false, align:'center', hidden:true},                       
      
      {label:'Пільга',name:'grp_lgt', index:'grp_lgt', width:150, editable: false, align:'center', hidden:false},                       
      {label:'Метод розрах.',name:'calc_name', index:'calc_name', width:100, editable: false, align:'center', hidden:false},                       
      {label:"Кільк.сім'ї",name:'family_cnt', index:'family_cnt', width:50, editable: false, align:'center', hidden:false},                             

      {label:'Приор.',name:'prior_lgt', index:'prior_lgt', width:30, editable: true, align:'left',edittype:'text'},           

      {label:'Особа',name:'fio_lgt', index:'fio_lgt', width:200, editable: true, align:'left',edittype:'text',hidden:false},           
      
      {label:'Документ',name:'id_doc', index:'id_doc', width:100, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:ldocs},stype:'text'},                       
      
      {label:'Серія',name:'s_doc', index:'s_doc', width:50, editable: true, align:'left',edittype:'text'},                 
      {label:'Номер',name:'n_doc', index:'n_doc', width:50, editable: true, align:'left',edittype:'text'},           
      
      {label:'Дата док.',name:'dt_doc', index:'dt_doc', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      
      {label:'ІНН',name:'ident_cod_l', index:'ident_cod_l', width:80, editable: true, align:'left',edittype:'text',hidden:false},           
      
      {label:'Дата перереєстр.',name:'dt_reg', index:'dt_reg', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},      
      
      {label:'Дата початку',name:'dt_start', index:'dt_start', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},      
      {label:'Дата закінч.',name:'dt_end', index:'dt_end', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},


      {name:'dt_b', index:'dt_b', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      {name:'dt_e', index:'dt_e', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      {name:'period_open', index:'period_open', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      {name:'dt_open', index:'dt_open', width:100, editable: true, align:'left', formatter:'date',
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i'}},
      {name:'user_name_open', index:'user_name_open', width:100, editable: true, align:'left',edittype:'text'},

      {name:'period_close', index:'period_close', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      {name:'dt_close', index:'dt_close', width:100, editable: true, align:'left', formatter:'date',
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i'}},
      {name:'user_name_close', index:'user_name_close', width:100, editable: true, align:'left',edittype:'text'},

    ],
    pager: '#hist_lgt_tablePager',
    rowNum:50,
    sortname: 'dt_b',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: '',
    pgbuttons: false,
    pgtext: null, 
    hiddengrid: false,
    jsonReader : {repeatitems: false},
    postData:{'lg_id':0},
      
  loadError : function(xhr,st,err) {jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText);}

  }).navGrid('#hist_lgt_tablePager',
        {edit:false,add:false,del:false,search:false}
        ); 
        
};        
        


jQuery("#btLgtSel").click( function() { 
     var ww = window.open("lgt_list.php", "lgt_win", "toolbar=0,width=800,height=600");
     document.lgt_sel_params.submit();
     ww.focus();
   });


// обработчик, который вызываетя перед отправкой формы
function LgtBeforeSubmit(formData, jqForm, options) { 

    submit_form = jqForm;

    var queryString = $.param(formData);     
    $('#message_zone').append('Вот что мы передаем:' + queryString);  
    $('#message_zone').append("<br>");                 
    
    var btn = '';
    for (var i=0; i < formData.length; i++) { 
        if (formData[i].name =='submitButton') { 
           btn= formData[i].value; 
           submit_form[0].oper.value = btn;
        } 
    } 

    if((btn=='edit')||(btn=='add'))
    {
       if(!submit_form.validate().form())  {return false;}
       else {
        if (btn=='edit')
            {
                
               $("#dialog-changedate").dialog({ 
			resizable: false,
			height:140,
			modal: true,
                        autoOpen: false,
			buttons: {
				"Ok": function() {
                                        //SaveLgtChanges();
                                          var cur_dt_change = jQuery("#dialog-changedate").find("#fdate_change").val();
  
                                          fLgtParam_ajaxForm[0].change_date.value = cur_dt_change;
                                          fLgtParam_ajaxForm.ajaxSubmit(meters_form_options);         

					$( this ).dialog( "close" );
				},
				"Отмена": function() {
                                        //CancelLgtChanges();
					$( this ).dialog( "close" );
				}
			}

                });
                
                $("#dialog-changedate").dialog('open');
                
                return false; 
                
            }
            else
                {return true;}

       }
    }
    else {return true;}       
    //}
    
} ;

// обработчик ответа сервера после отправки формы
function LgtSubmitResponse(responseText, statusText)
{
             errorInfo = responseText;

             if (errorInfo.errcode==0) {
             return [true,errorInfo.errstr]
             }; 

             if (errorInfo.errcode==-1) {  // insert/delete  ok
                 
               //jQuery("#dialog_editform").dialog('close');                           
               $('#paccnt_lgt_table').trigger('reloadGrid');     
               
               if (lgt_list_mode==1 )
                {
                    $("#lui_paccnt_lgt_table" ).hide();
                    
                    //meterLayout.open('east');
                    lgt_list_mode =0; //edit    
        
                }
                var first_id = parseInt($("#paccnt_lgt_table").getDataIDs()[0]);
                $("#paccnt_lgt_table").setSelection(first_id, true);

               
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');  
              // jQuery('#message_zone').dialog('open');
               return [true,errorInfo.errstr]};              
             
             if (errorInfo.errcode==1) {
               
               var fid = $("#fLgtParam").find("#fid").val();
               if(fid) 
               { 
                 jQuery("#paccnt_lgt_table").jqGrid('FormToGrid',fid,"#fLgtParam"); 
               }  
               
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');  
              // jQuery('#message_zone').dialog('open');
               return [true,errorInfo.errstr]};              
               
             if (errorInfo.errcode==2) {
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');                 
               jQuery('#message_zone').dialog('open');
               return [false,errorInfo.errstr]};   

};

});


function SelectLgtExternal(id, name, id_calc, name_calc) {
        $("#fLgtParam").find("#fid_grp_lgt").attr('value',id );
        $("#fLgtParam").find("#fgrp_lgt").attr('value',name );    
        
        $("#fLgtParam").find("#fid_calc_lgt").attr('value',id_calc );
        $("#fLgtParam").find("#fcalc_name_lgt").attr('value',name_calc );    
        
}




jQuery(function(){ 


    outerLayout = $("body").layout({
		name:	"outer" 
	,	north__paneSelector:	"#pmain_header"
	,	north__closable:	false
	,	north__resizable:	false
        ,	north__size:		40
	,	north__spacing_open:	0
	,	south__paneSelector:	"#pmain_footer"
	,	south__closable:	true
	,	south__resizable:	false
        ,	south__size:		40
	,	south__spacing_open:	0
	,	center__paneSelector:	"#pmain_content"
	,	resizeWhileDragging:	true
	,	autoBindCustomButtons:	true
	});

    innerLayout = $("#pmain_content").layout({
		name:			"inner" 
	,	north__paneSelector:	"#preps_header"
	,	north__closable:	true
	,	north__resizable:	true
        ,	north__size:		100
        ,	center__paneSelector:	"#preps_buttons"
	,	autoBindCustomButtons:	true
	,       center__onresize:	function (pane, $pane, state, options) 
        {
          //  jQuery("#client_table").jqGrid('setGridWidth',$pane.innerWidth()-9);
          //  jQuery("#client_table").jqGrid('setGridHeight',$pane.innerHeight()-142);
        }
        
	});
        
    //innerLayout.resizeAll();
    //innerLayout.hide('north');        
        
    jQuery(".btn").button();
    jQuery(".btnSel").button({icons: {primary:'ui-icon-folder-open'}});
        
   $("#debug_ls1").click( function() {jQuery("#message_zone").dialog('open');});
   $("#debug_ls2").click( function() {jQuery("#message_zone").dialog('close');});
   $("#debug_ls3").click( function() {jQuery("#message_zone").html('');});
   
   $("#message_zone").dialog({autoOpen: false});
   //---------------------------------------------------------------------
   
   $.ajaxSetup({  type: "POST",   dataType: "json" });
   
   var form_options = { 
    dataType:"json",
    beforeSubmit: FormBeforeSubmit, 
    success: FormSubmitResponse 
  };

   var ajaxForm = $("#freps_params").ajaxForm(form_options);
   
   // опции валидатора общей формы
   var form_valid_options = { 
                //errorPlacement: function(error, element) {
		//		error.appendTo( element.parent("label").parent("div"));
                //},
		rules: {
			//book: "required",
			//code: "required"
		},
		messages: {
			//book: "Вкажіть номер книги!",
			//code: "Вкажіть особовий рахунок!"
		}
   };

   validator = $("#freps_params").validate(form_valid_options);   
   
});


// обработчик, который вызываетя перед отправкой формы
function FormBeforeSubmit(formData, jqForm, options) { 

    submit_form = jqForm;

    var queryString = $.param(formData);     
    $('#message_zone').append('Вот что мы передаем:' + queryString);  
    $('#message_zone').append("<br>");                 
    
    var btn = '';
    for (var i=0; i < formData.length; i++) { 
        if (formData[i].name =='submitButton') { 
           btn= formData[i].value; 
           submit_form[0].oper.value = btn;
        }  
    } 

    return true;        
    
} ;

// обработчик ответа сервера после отправки формы
function FormSubmitResponse(responseText, statusText)
{
             errorInfo = responseText;

             if (errorInfo.errcode==0) {
             return [true,errorInfo.errstr]
             }; 

             if (errorInfo.errcode==1) {
                 
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');  
              // jQuery('#message_zone').dialog('open');
              
               return [true,errorInfo.errstr]};              
               
             if (errorInfo.errcode==2) {
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');                 
               jQuery('#message_zone').dialog('open');
               return [false,errorInfo.errstr]};   

};
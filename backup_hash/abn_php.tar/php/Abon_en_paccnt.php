<?php

header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';
session_name("session_kaa");
session_start();

error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) {
  $ids = $_SESSION['id_sess'];

  $res_par = sel_par($ids);
  $row_par = pg_fetch_array($res_par);
  $cons = $row_par['con_str1'];
  $Q = $row_par['qu'];
  $na = $row_par['nacc'];
  $Link = pg_connect($cons);
}

$rr = pg_query($Link, $Q);

$lnk_sys = log_s_pgsql("login");
$lnk1 = $lnk_sys['lnks'];
 */
/*
$idstr = 0;
$idreg = 0;
$idtwn = 0;
$idareg = 0;
$idlgt = 0;
$idgrpl = 0;
$iddev = 0;
$idtypdev = 0;

$QS = "update dbusr_var set idstr=" . $idstr . ",idreg=" . $idreg . ",idtwn=" . $idtwn . ",idareg=" . $idareg .
        ",idlgt=" . $idlgt . ",idgrpl=" . $idgrpl . ",iddev=" . $iddev . ",idtypdev=" . $idtypdev . " where id_sess=" . $ids;
$res_qs = pg_query($lnk1, $QS);


////////Переменные для формы Адреса

$OS_regt = 0;
$indx = "";
$house = "";
$slash = "";
$korp = "";
$flat = 0;
$fslash = 0;
$n_phone = "";
$m_check = 0;
*/
////////Переменные для формы Адреса



if ((isset($_POST['mode']))&&($_POST['mode']=='1'))
{
   
   $mode = 1; 
   $id_paccnt =0;
   $nm1 = "Абон-енерго (Новий особовий рахунок абонента)";
}
else
{
   $mode = 0; 
   $nm1 = "Абон-енерго (Особовий рахунок абонента)";

   if ((isset($_POST['id_paccnt']))&&($_POST['id_paccnt']!=''))    
   {
     $id_paccnt = $_POST['id_paccnt']; 
       
   }
    
}    

start_mpage($nm1);
head_addrpage();

print('<link rel="stylesheet" type="text/css" href="css/ded_styles.css" /> ');
print('<link rel="stylesheet" type="text/css" href="css/layout-default-latest.css" /> ');
    
print('<script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.form.js"></script>');
print('<script type="text/javascript" src="js/jquery.validate.min.js" ></script>');
print('<script type="text/javascript" src="js/jquery.ui.datepicker-uk.js"></script> ');
print('<script type="text/javascript" src="js/jquery.maskedinput-1.3.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.layout.min-latest.js"></SCRIPT>');
print('<script type="text/javascript" src="js/jquery.layout.resizeTabLayout.min-1.2.js"></SCRIPT>');

print('<script type="text/javascript" src="Abon_en_paccnt.js"></script> ');
print('<script type="text/javascript" src="Abon_en_paccnt_meters.js"></script> ');
print('<script type="text/javascript" src="Abon_en_paccnt_lgt.js"></script> ');
print('<script type="text/javascript" src="Abon_en_paccnt_dogovor.js"></script> ');
print('<script type="text/javascript" src="Abon_en_paccnt_plomb.js"></script> ');
print('<script type="text/javascript" src="Abon_en_paccnt_notlive.js"></script> ');
print('<script type="text/javascript" src="Abon_en_paccnt_works.js"></script> ');

print('<script type="text/javascript" src="dov_meters_sel.js"></script> ');
print('<script type="text/javascript" src="dov_compi_sel.js"></script> ');
print('<script type="text/javascript" src="dov_tp_sel.js"></script> ');
print('<script type="text/javascript" src="Abon_en_lgtfamily.js"></script> ');

$lmeters=DbTableSelList($Link,'eqk_meter_tbl','id','name');
$lphase=DbTableSelList($Link,'eqk_phase_tbl','id','name');
$lvolt=DbTableSelList($Link,'eqk_voltage_tbl','id','voltage');

$lzones=DbTableSelList($Link,'eqk_zone_tbl','id','nm');
$lzoneselect=DbTableSelect($Link,'eqk_zone_tbl','id','nm');

$ldocs=DbTableSelList($Link,'cli_doc_tbl','id','name');
$ldocselect=DbTableSelect($Link,'cli_doc_tbl','id','name');

$ldogovortype=DbTableSelList($Link,'cli_agreem_tbl','id','name');
$ldogovortypeselect=DbTableSelect($Link,'cli_agreem_tbl','id','name');
$lhousetypeselect=DbTableSelect($Link,'cli_house_type_tbl','id','name');

$lplombtype =DbTableSelList($Link,'plomb_type','id','name');
$lplombowner =DbTableSelList($Link,'plomb_owner','id','name');
$lplombplace =DbTableSelList($Link,'plomb_places','id','name');
$lplombtypeselect =DbTableSelect($Link,'plomb_type','id','name');
$lplombownerselect =DbTableSelect($Link,'plomb_owner','id','name');
$lplombplaceselect =DbTableSelect($Link,'plomb_places','id','name');

$lmeterplaceselect =DbTableSelect($Link,'eqk_meter_places_tbl','id','name');

$lmetersselect =DbTableSelect($Link," (select id,num_meter from clm_meterpoint_tbl where id_paccnt = $id_paccnt) as ss ",'id','num_meter');

$lworktypes =DbTableSelList($Link,'cli_works_tbl','id','name');
$lworkmetstatus =DbTableSelList($Link,'cli_metoper_tbl','id','name');

$lrel=     DbTableSelList($Link,'cli_family_rel_tbl','id','nm_rel');
$lrelselect=DbTableSelect($Link,'cli_family_rel_tbl','id','nm_rel');

?>
<style type="text/css"> 
#pmain_content {padding:3px}
#pwork_header {padding:3px; font-size: 14px;}
#pwork_center {padding:3px}
/* #pmeterzones {float:left; border-width:1;} */
#pMeterParam_left {padding: 1px;  background-color: #CCCCCC; border-color: #444444; border-style: solid; border-width:1px;}
#pMeterParam_right {padding: 1px;  background-color: #CCCCCC; border-color: #444444; border-style: solid; border-width:1px;}
#pMeterParam_buttons {margin:3px;  background-color: #CCCCCC; border-color: #444444; border-style: solid; border-width:1px; padding: 5px; }

#pMeterParam {height:250px}
.tabPanel {padding:1px; margin: 1px; }
.ui-tabs .ui-tabs-panel {padding:1px;}
.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {  color: #111111; }

</style>   

<script type="text/javascript">

var mode = <?php echo "$mode" ?>;
var id_paccnt = <?php echo "$id_paccnt" ?>;
 
var lkind_meter = <?php echo "$lmeters" ?>;
var lphase = <?php echo "$lphase" ?>;
var lvolt = <?php echo "$lvolt" ?>;
var lzones = <?php echo "$lzones" ?>; 
var ldocs = <?php echo "$ldocs" ?>; 
var ldogovortype = <?php echo "$ldogovortype" ?>; 
var lworktypes = <?php echo "$lworktypes" ?>; 
var lworkmetstatus = <?php echo "$lworkmetstatus" ?>; 

var lplombtype = <?php echo "$lplombtype" ?>; 
var lplombowner = <?php echo "$lplombowner" ?>; 
var lplombplace = <?php echo "$lplombplace" ?>; 
var lrel = <?php echo "$lrel" ?>; 

</script>


</head>
<body >


<DIV id="pmain_header"> 
    <?php main_menu(); ?>
</DIV>
    
<DIV id="pmain_footer">
   <a href="javascript:void(0)" id="debug_ls1">show debug window</a> 
   <a href="javascript:void(0)" id="debug_ls2">hide debug window</a> 
   <a href="javascript:void(0)" id="debug_ls3">clear debug window</a>
</DIV>

<DIV id="pmain_content">
    
    <DIV id="pwork_header">
    
      
        
        <form id="fAccEdit" name="fAccEdit" method="post" action="Abon_en_paccnt_edit" >
          <div class="pane"  >
            <input name="id" type="hidden" id="fid" value="" />
            <input name="oper" type="hidden" id="foper" value="" />            
            <input name="change_date" type="hidden" id ="fchange_date" value="" />                
            
            <p> <div style="display: inline-block;"> 
            <label>Книга/особовий рахунок &nbsp &nbsp
            <input name="book" type="text" id = "fbook" size="5" value= "" data_old_value = ""/>
            </label> 
            <label> /
            <input name="code" type="text" id = "fcode" size="10" value= "" data_old_value = ""/>            
            </label>                 
            </div>
            &nbsp &nbsp &nbsp &nbsp
            <div style="display: inline-block; width: 264px;"> 
            <label>Дата початку
                  <input name="dt_b" type="text" size="15" class="dtpicker" id ="fdt_b" value= "" data_old_value = "" />
            </label>
            </div>  
            &nbsp &nbsp &nbsp &nbsp
            
            <label id="archive_label" style="display: inline-block; width: 170px; color:red; ">
              <input type="checkbox" name="archive" id="farchive" value="1" data_old_checked = "" onclick="return false" onkeydown="return false" />
              Архів з
              <input name="dt_archive" type="text" size="10" class="dtpicker" id ="fdt_archive" value= "" data_old_value = "" readonly />
            </label>
            
            </p>

            <p>  
            <div style="display: inline-block;">     
            <input name="addr" type="hidden" id = "faddr" size="10" value= "" data_old_value = ""/>    
            <label style="display: inline-block; width: 600px;" >Адреса 
            <input style="float:right" name="addr_str" type="text" id = "faddr_str" size="80" value= "" data_old_value = "" readonly />
            </label> 
            <button type="button" class ="btnSel" id="btAddrSel"></button>       
            </div>
            &nbsp &nbsp
            <label style="display: inline-block; width: 130px; ">
              <input type="checkbox" name="activ" id="factiv" value="Yes" data_old_checked = ""/>
              Підключений
            </label>
            
            </p>
            
            <p>  
            <div style="display: inline-block;">     
            <input name="id_abon" type="hidden" id = "fid_abon" size="10" value= "" data_old_value = ""/>    
            <label style="display: inline-block; width: 600px;">Абонент  
            <input style="float:right" name="abon" type="text" id = "fabon" size="80" value= "" data_old_value = "" readonly />
            </label> 
            <button type="button" class ="btnSel" id="btAbonSel"></button>     
            </div>
            &nbsp &nbsp
            <label style="display: inline-block; width: 130px;">
              <input type="checkbox" name="rem_worker" id="frem_worker" value="Yes" data_old_checked = ""/>
              Працівник РЕМ
            </label>
            
            </p>

            <p>            
            <div style="display: inline-block;">         
            <input name="id_gtar" type="hidden" id = "fid_gtar" size="10" value= "" data_old_value = ""/>    
            <label style="display: inline-block; width: 600px;"> Тариф  
            <input style="float:right" name="gtar" type="text" id = "fgtar" size="80" value= "" data_old_value = "" readonly />
            </label> 
            <button type="button" class ="btnSel" id="btTarSel"></button>      
            </div>
            &nbsp &nbsp
            <label style="display: inline-block; width: 130px;">
              <input type="checkbox" name="not_live" id="fnot_live" value="Yes" data_old_checked = ""/>
              Не проживає
            </label>
            
            </p>

            <p>  
            <div style="display: inline-block;">         
            <input name="id_cntrl" type="hidden" id = "fid_cntrl" size="10" value= "" data_old_value = ""/>    
            <label style="display: inline-block; width: 600px;"> Інспектор
            <input style="float:right" name="cntrl" type="text" id = "fcntrl" size="80" value= "" data_old_value = "" readonly />
            </label> 
            <button type="button" class ="btnSel" id="btCntrlSel"></button>      
            </div>
            &nbsp &nbsp
            <label style="display: inline-block; width: 170px; margin:2px;">
              <input type="checkbox" name="pers_cntrl" id="fpers_cntrl" value="Yes" data_old_checked = ""/>
              Особливий контроль
            </label>
            </p>
            
            <p> 
            <label>Тип житла&nbsp &nbsp&nbsp &nbsp
                  <select name="idk_house" size="1" id="fidk_house" value= "" data_old_value = "" >
                     <?php echo "$lhousetypeselect" ?>;
                   </select>                    
            </label>      

            &nbsp &nbsp    
            <label> Опалювальна площа,м2
                <input name="heat_area" type="text" id = "fheat_area" size="10" value= "" data_old_value = ""/>
            </label> 

            &nbsp &nbsp    
            <label> Номер субсідії
                <input name="n_subs" type="text" id = "fn_subs" size="15" value= "" data_old_value = ""/>
            </label> 

            </p>
            
            <p> Примітка <br/>
                <textarea  style="height: 20px" cols="100" name="note" id="fnote" data_old_value = "" ></textarea>
            </p>
            
          </div>    
        <div class="pane" >
                <button name="submitButton" type="submit" class ="btn" id="bt_edit" value="edit" >Записати</button>
                <button name="submitButton" type="submit" class ="btn" id="bt_add" value="add" style="display:none;">Записати новий</button>
                <button name="resetButton" type="button" class ="btn" id="bt_reset" value="bt_reset" >Відмінити</button>
                <button type="button" class ="btn" id="bt_mainhistory" value="bt_mainhistory" >Історія</button>
                <button type="button" class ="btn" id="bt_showtree" value="bt_showtree" >Схема обладнання</button>
                &nbsp;&nbsp;&nbsp;
                <button type="button" class ="btn" id="bt_delabon" value="bt_delabon" >Видалити</button>
                <button name="submitButton" type="submit" class ="btn" id="bt_archabon" value="arch" >В архів</button>
        </div>
            
      </FORM>
            
      
      <DIV>
       <form id="fabon_sel_params" name="abon_sel_params" target="abon_win" method="post" action="dov_abon.php">
         <input type="hidden" name="select_mode" value="1" />
         <input type="hidden" name="id_abon" id="fabon_sel_params_id_abon" value="0" />
       </form>
          
       <form id="fcntrl_sel_params" name="cntrl_sel_params" target="cntrl_win" method="post" action="staff_list.php">
         <input type="hidden" name="select_mode" value="1" />
         <input type="hidden" name="id_person" id="fcntrl_sel_params_id_cntrl" value="0" />
       </form>

       <form id="ftarif_sel_params" name="tarif_sel_params" target="tar_win" method="post" action="tarif_list.php">
         <input type="hidden" name="select_mode" value="1" />
       </form>

       <form id="flgt_sel_params" name="lgt_sel_params" target="lgt_win" method="post" action="lgt_list.php">
         <input type="hidden" name="select_mode" value="1" />
       </form>
          
      </DIV>
        
        
    
    </DIV>

    <DIV id="pwork_center">
     
     <!--   <div id="paccnt_tabs"> -->
            <ul id="tabButtons">
		<li><a href="#tab_meters">Лічильники</a></li>
                <li><a href="#tab_lgt">Пільги</a></li>
		<li><a href="#tab_dogovor">Договір</a></li>
                <li><a href="#tab_plomb">Пломби</a></li>
                <li><a href="#tab_works">Роботи</a></li>
                <li><a href="#tab_notlive">Тимчасове непрож.</a></li>
            </ul>            

            <div id="tab_meters" class="tabPanel ui-widget-content ui-tabs-hide" > 

               <div id="paccnt_meters_list" > 
                <table id="paccnt_meters_table" style="margin:1px;"></table>
                <div id="paccnt_meters_tablePager"></div>
               </div>
                
               <div id ="pMeterParam" >
                <form id="fMeterParam" name="fMeterParam" method="post" action="Abon_en_paccnt_meters_edit.php" >
                <div id="pMeterParam_left" class="pane">
                <div id="pMeterEditForm" >    
                <div style="margin:3px;  border-color: #444444; border-style: solid; border-width:1px; padding: 5px; " >
                <p>
                <input type="hidden" name="id" id = "fid" size="10" value= ""  />                 
                <input type="hidden" name="oper" id="foper" value="" />            
                <input type="hidden" name="change_date"  id="fchange_date" value="" />                    
                <input type="hidden" name="id_paccnt" id = "fid_paccnt" size="10" value= "" />                 
                
                <input type="hidden" name="code_eqp" id = "fcode_eqp" size="10" value= "" data_old_value = "" />                 

                <input type="hidden" name="id_type_meter" id = "fid_type_meter" size="10" value= "" data_old_value = "" /> 

                <label>Тип приладу обліку
                <input name="type_meter" type="text" id = "ftype_meter" size="40" value= "" data_old_value = "" readonly  />
                </label> 
                <button type="button" class ="btnSel" id="show_mlist"></button>
                <label> Номер 
                <input name="num_meter" type="text" id="fnum_meter" value= "" data_old_value = "" />
                </label>
                <label> Кількість розрядів
                <input name="carry" type="text" size="7" id = "fcarry" value= "" data_old_value = "" />
                </label>
                </p>
                <p>
                  <label>Дата встановлення
                     <input name="dt_b" type="text" size="15" class="dtpicker" id ="fdt_start" value= "" data_old_value = "" />
                  </label>
                  <label>Дата повірки лічильника
                     <input name="dt_control" type="text" size="15" class="dtpicker" id ="fdt_control" value= "" data_old_value = "" />
                  </label>

                </p>
                
                </div>
                <div style="margin:3px;  border-color: #444444; border-style: solid; border-width:1px; padding: 5px; " >

                <p>
                <label>Коеф. трансформації
                <input name="coef_comp" type="text" size="12" id="fcoef_comp" value= "1" data_old_value = "1" />
                </label>
                <button type="button" class ="btn btnSmall" id="toggle_comp">Вимірювальні тр.</button>                                
                </p>
                <div id="pMeterParam_comp">    
                <p>
                <input type="hidden" name="id_typecompa" id = "fid_typecompa" size="10" value= "" data_old_value = "" />     
                <label>Трансформатор струму
                <input name="typecompa" type="text" id = "ftypecompa" size="30" value= "" data_old_value = "" readonly />
                </label>
                <button type="button" class ="btnSel" id="show_compa"></button>      
                <label>Дата повірки тр. струму
                <input type="text" name="dt_control_ca" class="dtpicker" id ="fdt_control_ca" size="15" value= "" data_old_value = "" />
                </label>
                </p>
                <p>
                <input type="hidden" name="id_typecompu" id = "fid_typecompu" size="10" value= "" data_old_value = "" />         
                <label>Трансформатор напруги
                <input name="typecompu" type="text" id = "ftypecompu" size="30" value= "" data_old_value = "" readonly />
                </label>
                <button type="button" class ="btnSel" id="show_compu"></button>            
                <label>Дата повірки тр. напруги
                <input type="text" name="dt_control_cu" class="dtpicker" id ="fdt_control_cu" size="15" value= "" data_old_value = "" />
                </label>
                </p>
                </div>
                </div>
                <div style="margin:3px;  border-color: #444444; border-style: solid; border-width:1px; padding: 5px; " >
                    <p>
                         <label>Місце встановлення
                             <select name="id_extra" size="1" id="fid_extra" value= "" data_old_value = "" >
                                 <?php echo "$lmeterplaceselect" ?>;
                             </select>                    
                         </label>      
                        <label>Встановлена потужність
                        <input name="power" type="text" size="15" id ="fpower" value= "" data_old_value = "" />
                    </label>
                    </p> 
                    <p> 
                    <input type="hidden"   name="calc_losts"  value="No" />                                            
                    <label>
                    <input type="checkbox" name="calc_losts" id="fcalc_losts" value="Yes" data_old_checked = ""/>
                    Розрахунок втрат</label>
                    <input type="hidden"   name="warm"  value="No" />                                            
                    <label>
                    <input type="checkbox" name="warm" id="fwarm" value="Yes" data_old_checked = "" />
                    Встан. у неопалюваному приміщенні</label>
                    <input type="hidden"   name="magnet"  value="No" />                                            
                    <label>
                    <input type="checkbox" name="magnet" id="fmagnet" value="Yes" data_old_checked = "" />
                    Індикатор магніта</label>
                    </p>
                    <p>
                    <input type="hidden" name="id_station" id ="fid_station" size="10" value= "" data_old_value = "" /> </label>                        
                    <label>Підключений до ТП
                    <input type="text" name="station" id ="fstation" size="30" value= "" data_old_value = "" readonly /> </label>
                    <button type="button" class ="btnSel" id="show_tplist"></button>
                    </p>

                </div>
                </div>        
                <div id="hist2meter_div" style="display:none;"> 
                     <table id="hist2meter_table" style="margin:1px;"></table>
                     <div id="hist2meter_tablePager"></div>
                </div>            
                    
                </div>
                <div id="pMeterParam_right">    
                   <div id="paccnt_meter_zones" > 
                    <table id="paccnt_meter_zones_table" style="margin:1px;"></table>
                    <div   id="paccnt_meter_zones_tablePager"></div>
                   </div>

                    <div id="paccnt_meter_zones_hist" style="display:none;"> 
                    <table id="paccnt_meter_zones_hist_table" style="margin:1px;"></table>
                    <div   id="paccnt_meter_zones_hist_tablePager"></div>
                   </div>

                    
                </div>

                <div id="pMeterParam_buttons"  >
                
                <button name="submitButton" type="submit" class ="btn" id="bt_edit" value="edit" >Записати</button>
                <button name="submitButton" type="submit" class ="btn" id="bt_add" value="add" style="display:none;">Записати новий</button>                
                <button name="resetButton" type="button" class ="btn" id="bt_reset" value="reset" >Відмінити</button>         
                
                </div>
                </form>
            </div>

            </DIV>    

            <div id="tab_lgt" class="tabPanel ui-widget-content ui-tabs-hide">
               <div id="paccnt_lgt_list" > 
                <table id="paccnt_lgt_table" style="margin:1px;"></table>
                <div id="paccnt_lgt_tablePager"></div>
               </div>

               <div id ="pLgtParam" >
                <form id="fLgtParam" name="fLgtParam"  target=""  method="post" action="Abon_en_paccnt_lgt_edit.php" >
                <div id="pLgtParam_left" class="pane">
                 <input type="hidden" name="id" id = "fid" size="10" value= ""  />                 
                 <input type="hidden" name="oper" id="foper" value="" />            
                 <input type="hidden" name="change_date"  id="fchange_date" value="" />                    
                 <input type="hidden" name="id_paccnt" id = "fid_paccnt" size="10" value= "" />                 
                 <div class="pane"  >
                     <p>            
                         <input name="id_grp_lgt" type="hidden" id = "fid_grp_lgt" size="10" value= "" data_old_value = ""/>    
                         <label> Пільга
                             <input name="grp_lgt" type="text" id = "fgrp_lgt" size="70" value= "" data_old_value = "" readonly />
                         </label> 
                         <button type="button" class ="btnSel" id="btLgtSel"></button>      
                         &nbsp; 
                         <label> Кількість членів сім'ї
                             <input name="family_cnt" type="text" id = "ffamily_cnt" size="5" value= "" data_old_value = "" />
                         </label> 
                         
                         <button type="button" class ="btn btnSmall" id="btFamily">Члени сім'ї</button>      
                    </p>
                         <input name="id_calc" type="hidden" id = "fid_calc_lgt" size="10" value= "" data_old_value = ""/>    
                         <label> Розрахунок
                             <input name="calc_name" type="text" id = "fcalc_name_lgt" size="40" value= "" data_old_value = "" readonly />
                         </label> 
                         <label>Пріорітет пільги
                             <input name="prior_lgt" type="text" id = "fprior_lgt" size="5" value= "" data_old_value = ""/>
                         </label> 
                         
                     </p>
                     <p>            
                         <label> Особа, якій надана пільга
                             <input name="fio_lgt" type="text" id = "ffio_lgt" size="50" value= "" data_old_value = ""/>
                         </label> 

                         <label>Ідентифікаційний номер
                             <input name="ident_cod_l" type="text" id = "fident_cod_l" size="15" value= "" data_old_value = ""/>
                         </label> 
                             
                     </p>
                 </div>   
                 <div class="pane"  >
                     <p>            
                         <label>Вид документа
                             <select name="id_doc" size="1" id="fid_doc" value= "" data_old_value = "" >
                                 <?php echo "$ldocselect" ?>;
                             </select>                    
                                 
                         </label> 
                     </p>
                     <p>
                         <label>Серія док.
                             <input name="s_doc" type="text" id = "fs_doc" size="10" value= "" data_old_value = ""/>
                         </label> 
                         <label>Номер док.
                             <input name="n_doc" type="text" id = "fn_doc" size="20" value= "" data_old_value = ""/>
                         </label> 
                         <label>Дата видачі
                             <input name="dt_doc" type="text" size="12" value="" id="fdt_doc" class="dtpicker" data_old_value = "" />
                         </label>
                     </p>
                 </div>
                 <div class="pane"  >    
                     <p>
                         <label>Дата початку
                             <input name="dt_start" type="text" size="13" class="dtpicker" id ="flgtdt_b" value= "" data_old_value = "" />
                         </label>
                         <label>Дата закінчення
                             <input name="dt_end" type="text" size="13" class="dtpicker" id ="flgtdt_e" value= "" data_old_value = "" />
                         </label>
                         <label>Дата перереєстрації
                             <input name="dt_reg" type="text" size="13" class="dtpicker" id ="fdt_reg" value= "" data_old_value = "" />
                         </label>
                             
                     </p>
                     
                 </div>    
                 
                </div>
                    <!--
                <div id="pMeterParam_right">    
                   <div id="paccnt_meter_zones" > 
                    <table id="paccnt_meter_zones_table" style="margin:1px;"></table>
                    <div   id="paccnt_meter_zones_tablePager"></div>
                   </div>
                </div>
                    -->
                <div class ="pane" id="pLgtParam_buttons"  >
                
                <button name="submitButton" type="submit" class ="btn" id="bt_edit" value="edit" >Записати</button>
                <button name="submitButton" type="submit" class ="btn" id="bt_add" value="add" style="display:none;">Записати новий</button>                
                <button name="resetButton" type="button" class ="btn" id="bt_reset" value="reset" >Відмінити</button>         
                
                </div>
                </form>
              </div>

              <div id="hist_lgt_div" style="display:none;"> 
                     <table id="hist_lgt_table" style="margin:1px;"></table>
                     <div id="hist_lgt_tablePager"></div>
              </div>            
                
            </DIV>
                
            <div id="dialog_editlgtform" style="display:none; overflow:visible; z-index: 100000; ">        
                <form id="fFamilyEdit" name="fFamilyEdit" method="post" action="Abon_en_lgtfamily_edit.php" >
                    <div class="pane"  >
                        <input name="id" type="hidden" id="fid" value="" />
                        <input name="id_lgt" type="hidden" id="fid_lgt" value="<?php echo $id_lgt; ?>" />
                        <input name="oper" type="hidden" id="foper" value="" />            
                        <div class="pane"  >    
                            <p>
                                <label>Член сім'ї 
                                    <input name="fio" type="text" id = "ffio" size="50" value= "" data_old_value = ""/>
                                </label> 
                                <input type="hidden"   name="lgt"  value="No" />                    
                                <label>
                                    <input type="checkbox" name="lgt" id="flgt" value="Yes" data_old_checked = ""/>
                                    Пільговик
                                </label>
                            </p>
                            <p>            
                                <label>Дата народження
                                    <input name="dt_birth" type="text" size="15" class="dtpicker" id ="fdt_birth" value= "" data_old_value = "" />
                                </label>
                                <label>Сімейні відносини
                                    <select name="id_rel" size="1" id="fid_rel" value= "" data_old_value = "" >
                                        <?php echo "$lrelselect" ?>;
                                    </select>                    
                                </label> 
                            </p>
                        </div>    
                        <div class="pane"  >    
                            <p>
                                <label>Дата початку
                                    <input name="dt_b" type="text" size="15" class="dtpicker" id ="flgtfamdt_b" value= "" data_old_value = "" />
                                </label>
                                <label>Дата закінчення
                                    <input name="dt_e" type="text" size="15" class="dtpicker" id ="flgtfamdt_e" value= "" data_old_value = "" />
                                </label>
                            </p>
                        </div>    
                    </div>    
                    <div class="pane" >
                        <button name="submitButton" type="submit" class ="btn" id="bt_edit" value="edit" >Записати</button>
                        <button name="submitButton" type="submit" class ="btn" id="bt_add" value="add" style="display:none;">Записати новий</button>                
                        <button name="resetButton" type="button" class ="btn" id="bt_reset" value="bt_reset" >Відмінити</button>         
                    </div>
                </FORM>
            </div>   
     
            <div id="tab_dogovor" class="tabPanel ui-widget-content ui-tabs-hide">
               <div id="paccnt_dogovor_list" > 
                <table id="paccnt_dogovor_table" style="margin:1px;"></table>
                <div id="paccnt_dogovor_tablePager"></div>
               </div>

               <div id ="pDogovorParam" >
                <form id="fDogovorParam" name="fDogovorParam"  target=""  method="post" action="Abon_en_paccnt_dogovor_edit.php" >
                 <input type="hidden" name="id" id = "fid" size="10" value= ""  />                 
                 <input type="hidden" name="oper" id="foper" value="" />            
                 <input type="hidden" name="change_date"  id="fchange_date" value="" />                    
                 <input type="hidden" name="id_paccnt" id = "fid_paccnt" size="10" value= "" />                 
                 <div class="pane"  >
                 <div class="pane"  >
                     <p>            
                         <label>Вид договора
                             <select name="id_iagreem" size="1" id="fid_iagreem" value= "" data_old_value = "" >
                                 <?php echo "$ldogovortypeselect" ?>;
                             </select>                    
                     </p>
                     <p>
                         </label> 
                         <label>Номер
                             <input name="num_agreem" type="text" id = "fnum_agreem" size="20" value= "" data_old_value = ""/>
                         </label> 
                         <label>Дата 
                             <input name="date_agreem" type="text" size="12" value="" id="fdate_agreem" class="dtpicker" data_old_value = "" />
                         </label>
                         <label>Шифр
                             <input name="shifr" type="text" id = "fshifr" size="20" value= "" data_old_value = ""/>
                         </label> 
                     </p>
                     <p>            
                         <input name="id_abon" type="text" id = "fid_abon" size="10" value= "" data_old_value = ""/>    
                         <label> Договір підписав
                             <input name="abon" type="text" id = "fabon" size="50" value= "" data_old_value = ""/>
                         </label> 
                         <button type="button" class ="btnSel" id="btAbonDogSel"></button>      
                     </p>
                     <p>            
                         <input name="id_town_agreem" type="text" id = "fid_town_agreem" size="10" value= "" data_old_value = ""/>    
                         <label> Населений пункт
                             <input name="town" type="text" id = "ftown" size="50" value= "" data_old_value = ""/>
                         </label> 
                         <button type="button" class ="btnSel" id="btTownDogSel"></button>      
                     </p>

                     <p>            
                         <label>Потужність
                             <input name="power" type="text" id = "fpower" size="15" value= "" data_old_value = ""/>
                         </label> 
                         <label>Категорія
                             <input name="categ" type="text" id = "fcateg" size="15" value= "" data_old_value = ""/>
                         </label> 
                             
                     </p>
                 </div>   

                 <div class="pane"  >    
                     <p>
                         <label>Дата початку
                             <input name="dt_b" type="text" size="15" class="dtpicker" id ="fdogdt_b" value= "" data_old_value = "" />
                         </label>
                         <label>Дата закінчення
                             <input name="dt_e" type="text" size="15" class="dtpicker" id ="fdogdt_e" value= "" data_old_value = "" />
                         </label>
                             
                     </p>
                     
                 </div>    
                 </div>   
                <div class ="pane" id="pDogovorParam_buttons"  >
                
                <button name="submitButton" type="submit" class ="btn" id="bt_edit" value="edit" >Записати</button>
                <button name="submitButton" type="submit" class ="btn" id="bt_add" value="add" style="display:none;">Записати новий</button>                
                <button name="resetButton" type="button" class ="btn" id="bt_reset" value="reset" >Відмінити</button>         
                
                </div>
                </form>
              </div>
                
                
            </DIV>
                
     
            <div id="tab_plomb" class="tabPanel ui-widget-content ui-tabs-hide">
               <div id="paccnt_plomb_list" > 
                <table id="paccnt_plomb_table" style="margin:1px;"></table>
                <div id="paccnt_plomb_tablePager"></div>
               </div>

               <div id ="pPlombParam" >
                <form id="fPlombParam" name="fPlombParam"  target=""  method="post" action="Abon_en_paccnt_plomb_edit.php" >
                 <input type="hidden" name="id" id = "fid" size="10" value= ""  />                 
                 <input type="hidden" name="oper" id="foper" value="" />            
                 <input type="hidden" name="change_date"  id="fchange_date" value="" />                    
                 <input type="hidden" name="id_paccnt" id = "fid_paccnt" size="10" value= "" />                 
                 <div class="pane"  >
                   <div class="pane"  >
                     <p>            
                         <label>Номер пломби 
                             <input name="plomb_num" type="text" id = "fplomb_num" size="20" value= "" data_old_value = ""/>
                         </label> 

                         <label>Тип пломби
                             <select name="id_type" size="1" id="fid_type" value= "" data_old_value = "" >
                                 <?php echo "$lplombtypeselect" ?>;
                             </select>                    
                         </label>                              
                     </p>
                     <p>
                         <label>Місце встановлення
                             <select name="id_place" size="1" id="fid_place" value= "" data_old_value = "" >
                                 <?php echo "$lplombplaceselect" ?>;
                             </select>                    
                         </label>                              

                         <label>Приналежність пломби
                             <select name="id_plomb_owner" size="1" id="fid_plomb_owner" value= "" data_old_value = "" >
                                 <?php echo "$lplombownerselect" ?>;
                             </select>                    
                         </label>                              
                     </p>
                     
                     <p> 
                         <label>Лічильник
                             <select name="id_meter" size="1" id = "fid_meter" size="10" value= "" data_old_value = "">                             
                                 <?php echo "$lmetersselect" ?>;
                             </select>                    
                             <input name="num_meter" type="hidden" id = "fnum_meter" size="20" value= "" data_old_value = ""/>
                         </label> 
                     </p>
                   </div>  
                   <div class="pane"  >
                     <p>                                 
                         <label style="display: inline-block; width: 250px;" >Дата встановлення 
                             <input name="dt_on" type="text" size="12" value="" id="fdt_on" class="dtpicker" data_old_value = "" />
                         </label>
                     
                         <input name="id_person_on" type="hidden" id = "fid_person_on" size="10" value= "" data_old_value = ""/>                             
                         <label>Пломбу встановив
                             <input name="person_on" type="text" id = "fperson_on" size="40" value= "" data_old_value = ""/>
                         </label> 
                         <button type="button" class ="btnSel" id="btPlombPersonOnSel"></button>      
                     </p>

                     <p>                                 
                         <label style="display: inline-block; width: 250px;" >Дата видалення  &nbsp&nbsp&nbsp &nbsp 
                             <input name="dt_off" type="text" size="12" value="" id="fdt_off" class="dtpicker" data_old_value = "" />
                         </label>
                     
                         <input name="id_person_off" type="hidden" id = "fid_person_off" size="10" value= "" data_old_value = ""/>                             
                         <label>Пломбу видалив&nbsp&nbsp&nbsp
                             <input name="person_off" type="text" id = "fperson_off" size="40" value= "" data_old_value = ""/>
                         </label> 
                         <button type="button" class ="btnSel" id="btPlombPersonOffSel"></button>      
                     </p>
                    </div> 
                     <p>            
                         <label>Примітка
                             <input name="comment" type="text" id = "fcomment" size="100" value= "" data_old_value = ""/>
                         </label> 
                             
                     </p>
                 </div>   

                <div class ="pane" id="pPlombParam_buttons"  >
                
                <button name="submitButton" type="submit" class ="btn" id="bt_edit" value="edit" >Записати</button>
                <button name="submitButton" type="submit" class ="btn" id="bt_add" value="add" style="display:none;">Записати новий</button>                
                <button name="resetButton" type="button" class ="btn" id="bt_reset" value="reset" >Відмінити</button>         
                
                </div>
                </form>
              </div>
                
            </DIV>     
     
            <div id="tab_notlive" class="tabPanel ui-widget-content ui-tabs-hide">
               <div id="paccnt_notlive_list" > 
                <table id="paccnt_notlive_table" style="margin:1px;"></table>
                <div id="paccnt_notlive_tablePager"></div>
               </div>

               <div id ="pNotliveParam" >
                <form id="fNotliveParam" name="fNotLiveParam"  target=""  method="post" action="Abon_en_paccnt_notlive_edit.php" >
                 <input type="hidden" name="id" id = "fid" size="10" value= ""  />                 
                 <input type="hidden" name="oper" id="foper" value="" />            
                 <input type="hidden" name="change_date"  id="fchange_date" value="" />                    
                 <input type="hidden" name="id_paccnt" id = "fid_paccnt" size="10" value= "" />                 
                 <div class="pane"  >
                   <div class="pane"  >
                       
                       
                     <p>            
                         <label>Номер док.
                             <input name="num_doc" type="text" id = "fnum_doc" size="20" value= "" data_old_value = ""/>
                         </label> 
                         <label>Дата док.
                             <input name="date_doc" type="text" size="12" value="" id="fdate_doc" class="dtpicker" data_old_value = "" />
                         </label>

                     </p>
                   </div>  
                   <div class="pane"  >
                     <p>                                 
                         <label style="display: inline-block; width: 350px;" >Дата початку непроживання &nbsp&nbsp&nbsp
                             <input name="dt_b" type="text" size="12" value="" id="fdt_b_notlive" class="dtpicker" data_old_value = "" />
                         </label>
                     </p>

                     <p>                                 
                         <label style="display: inline-block; width: 350px;" >Дата закінчення непроживання 
                             <input name="dt_e" type="text" size="12" value="" id="fdt_e_notlive" class="dtpicker" data_old_value = "" />
                         </label>
                     </p>
                    </div> 
                     <p>            
                         <label>Примітка
                             <input name="comment" type="text" id = "fcomment" size="100" value= "" data_old_value = ""/>
                         </label> 
                             
                     </p>
                 </div>   

                <div class ="pane" id="pNotliveParam_buttons"  >
                
                <button name="submitButton" type="submit" class ="btn" id="bt_edit" value="edit" >Записати</button>
                <button name="submitButton" type="submit" class ="btn" id="bt_add" value="add" style="display:none;">Записати новий</button>                
                <button name="resetButton" type="button" class ="btn" id="bt_reset" value="reset" >Відмінити</button>         
                
                </div>
                </form>
              </div>
                
            </DIV>     
            <div id="tab_works" class="tabPanel ui-widget-content ui-tabs-hide">
               <div id="paccnt_works_list" > 
                <table id="paccnt_works_table" style="margin:1px;"></table> 
                <div id="paccnt_works_tablePager"></div>
               </div>
               <div id="paccnt_works_indic_list" > 
                <table id="paccnt_works_indic_table" style="margin:1px;"></table>
                <div id="paccnt_works_indic_tablePager"></div>
               </div>

            </DIV>     
     
            <div id="tab_saldo" class="tabPanel ui-widget-content ui-tabs-hide">
                  Saldo
            </DIV>

            <div id="tab_akt" class="tabPanel ui-widget-content ui-tabs-hide">
                  Akt
            </DIV>

       <!-- </DIV> -->
    </DIV>

    
</DIV>

     <div id="grid_selmeter" style="display:none; position:absolute; margin:1px; background: #FFFFCC; borderWidth:1px;z-index: 100000;" >   
            <table id="dov_meters_table" style="margin:1px;"></table>
            <div id="dov_meters_tablePager"></div>
     </div>    

     <div id="grid_selci" style="display:none; position:absolute; margin:1px; background: #FFFFCC; borderWidth:1px;z-index: 100000;" >   
             <table id="dov_compi_table" style="margin:1px;"></table>
             <div id="dov_compi_tablePager"></div>
     </div>    

     <div id="grid_seltp" style="display:none; position:absolute; margin:1px; background: #FFFFCC; borderWidth:1px;z-index: 100000;" >   
             <table id="dov_tp_table" style="margin:1px;"></table>
             <div id="dov_tp_tablePager"></div>
     </div>    

     <div id="grid_lgtfamily" style="display:none; position:absolute; margin:1px; background: #FFFFCC; borderWidth:1px ;z-index: 500;" >   
             <table id="lgt_family_table" style="margin:1px;"></table>
             <div id="lgt_family_tablePager"></div>
     </div>    
    
    <div id="dialog-changedate" title="Дата редагування" style="display:none;">
	<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        <p id="dialog-text">Вкажіть дату редагування </p></p>
        <br>
        <input name="date_change" type="text" size="20" class="dtpicker" id ="fdate_change"/>
    </div>
    
    <div id="dialog-confirm" title="Удалить учет?" style="display:none;">
	<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        <p id="dialog-text">Учет будет удален. Продолжить? </p></p>
    </div>
    
    <div id="dialog-newmeterzone" title="Нова зона" style="display:none;">

        <form>
        <p>    
        <label style="display: inline-block; width: 250px;" > Зона
           <select style="float:right" name="id_zone" size="1" id="fid_zone" value= "" data_old_value = "" >
              <?php echo "$lzoneselect" ?>;                        
           </select>                    
        </label>
        </p>   
        <p>           
        <label> Дата встановлення
                <input  name="date_install" id ="fdate_install" type="text" size="19" class="dtpicker" />
        </label>    
        </p>           
        </form> 
    </div>

    <div id="dialog-mainhistory" title="Історія змін особового рахунку" style="display:none;">
     <div id="grid_mainhistory" >   
             <table id="mainhistory_table" style="margin:1px;"></table>
             <div id="mainhistory_tablePager"></div>
     </div>    
    </div>
    
    
    <DIV style="display:none;">
      <form id="fpaccnt_params" name="paccnt_params" method="post" action="">
         <input type="text" name="mode" id="pmode" value="0" />
         <input type="text" name="id_meter" id="pid_meter" value="0" />         
         <input type="text" name="id_paccnt" id="pid_paccnt" value="0" />                  
         <input type="text" name="id_work" id="pid_work" value="0" />                  
         <input type="text" name="idk_work" id="pidk_work" value="0" />                           
      </form>
    </DIV>
    <form id="fadr_sel_params" name="adr_sel_params" target="adr_win" method="post" action="adr_tree_selector.php">
        <input type="hidden" name="select_mode" value="1" />
        <input type="hidden" name="address" id="fadr_sel_params_address" value="" />
    </form>
    
    

<div id="message_zone" style ="padding: 5px;color: blue;" >  </div>


<?php

end_mpage();
?>
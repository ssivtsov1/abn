<?php
function sql_field_val($fname,$ftype) { 
    
  $result='';
  
  if (isset($_POST[$fname])&& (trim($_POST[$fname])!='')){
      $result=$_POST[$fname]; 

      if ($ftype == 'string') {$result = "'$result'";}
      if ($ftype == 'record') 
          {
          
          $array= explode(",", trim($result,')('));
          
          foreach ($array as &$value) {
            if ($value =='')  $value ='null'; 
            else $value = "'$value'";
          }          
          unset($value);          
          
          $result = 'ROW('.implode(',',$array).')';
          
          }
      
      if ($ftype == 'int') {
          
        if($result=='on') {$result = 1;}
        if($result=='On') {$result = 1;}
        if($result=='Yes'){$result = 1;}
        if($result=='off'){$result = 0;}
        if($result=='Off'){$result = 0;}
        if($result=='No') {$result = 0;}
        }

      if ($ftype == 'bool') {
          
        if($result=='on') {$result = 'true';}
        if($result=='On') {$result = 'true';}
        if($result=='Yes'){$result = 'true';}
        if($result=='1')  {$result = 'true';}        
        if($result=='off'){$result = 'false';}
        if($result=='Off'){$result = 'false';}
        if($result=='No') {$result = 'false';}
        if($result=='0')  {$result = 'false';}        
        }
        
      if ($ftype == 'date') {
        //Return ($result);        
        //$date = DateTime::createFromFormat('d.m.Y', $result);
        //$result= $date->format($date, 'Y-m-d');          
        if ((trim($result)=='--')||($result=='\u00a0')||(trim($result)=='__.__.____')) 
            {$result = 'null';}
        else{    
        list($day, $month, $year) = split('[/.-]', $result);
        if(($day!='') && ($month!='')&& ($year!=''))
            {$result = "'$year-$month-$day'"; }
        else
            {$result = 'null';}
        }
      }
        
  } else {$result = 'null';}

  Return ($result);

};

function echo_result($errcode,$errstr,$id=0) {
    
    $arr = array('errcode' => $errcode, 'errstr' => $errstr, 'id' => $id);
    echo json_encode($arr);
};

function DbTableSelList($lnk,$table,$fid,$fname) {
// для лукапа из jqGrid    
    $SQL = "select $fid, $fname from $table Order by $fid ";

    $result = pg_query($lnk,$SQL);

    
    if (!$result) { $res_str = "";}
    else {
    
    $res_str = "'null: ;";
    $i =0;
    while($row = pg_fetch_array($result)) {
       $i++;
       if ($i>1){$res_str.=';';};
       $res_str.= $row[$fid].':'.$row[$fname];
    }
    $res_str.= "'";    
 } 
 return $res_str;
    
};

function DbTableSelect($lnk,$table,$fid,$fname) {
    // для лукапа из формы    
    $SQL = "select $fid, $fname from $table Order by $fid ";

    $result = pg_query($lnk,$SQL);

    if (!$result) { $res_str = "";}
    else {
    
    $res_str = "";
    $i =0;
    $res_str.= '<option value="null">  </option>';    
    while($row = pg_fetch_array($result)) {
       $i++;
       
       $res_str.= '<option value="'.$row[$fid].'">'.$row[$fname].'</option>';
    }
 } 
 return $res_str;
    
};

function DbGetFieldsArray($lnk,$table) {
    
    $SQL = "select column_name, data_type from information_schema.columns where table_name = '$table'; ";

    $result = pg_query($lnk,$SQL);

    $array = array();
    
    if ($result) 
    {
    
        while($row = pg_fetch_array($result)) 
        {
            $array[$row['column_name']]= array('f_name'=>$row['column_name'],'f_type'=>$row['data_type']);
        }

    } 
    return $array;
    
};

function DbBuildWhere($_POST_val,$farrey) {
    
$qW = ' WHERE ';

$stringTypes = array('text', 'character varying','character','string');

if (isset($_POST_val['_search']) && $_POST_val['_search'] == 'true') 
{    
    
    //throw new Exception($searchData);
    //throw new Exception(json_encode($_POST));
    $firstElem = true;    
    
    foreach ($_POST_val as $k=>$v) {
     
        if (array_key_exists($k, $farrey)) {
          
          if ($v =='null')  continue;
              
          if (!$firstElem) {
              $qW .= ' AND ';
          }
          else {
            $firstElem = false;
          }
            
          $qW .=$farrey[$k]['f_name'];
          if (in_array($farrey[$k]['f_type'],$stringTypes))
          {
              $qW .=' ~* ';
          }
          else
          {
              $qW .=' = ';              
          }
          
          $qW .="'".$v."'";
        }        
        
    }
    
    if (isset($_POST_val['searchField']) && isset($_POST_val['searchString']) && isset($_POST_val['searchOper']))     
    {
       if (!$firstElem) {
          $qW .= ' AND ';
       }
       else {
          $firstElem = false;
       }
       
       $qW .= $_POST_val['searchField'];

        switch ($_POST_val['searchOper']) 
        {
          case 'eq': $qW .= " = '".$_POST_val['searchString']."'" ; break;
          case 'ne': $qW .= " <> '".$_POST_val['searchString']."'" ; break;
          case 'bw': $qW .= " LIKE '".$_POST_val['searchString']."%'" ; break;
          case 'bn': $qW .= " NOT LIKE '".$_POST_val['searchString']."%'" ; break;
          case 'ew': $qW .= " LIKE '%".$_POST_val['searchString']."'" ; break;
          case 'en': $qW .= " NOT LIKE '%".$_POST_val['searchString']."'" ; break;
          case 'cn': $qW .= " LIKE '%".$_POST_val['searchString']."%'" ; break;
          case 'nc': $qW .= " NOT LIKE '%".$_POST_val['searchString']."%'" ; break;
          case 'nu': $qW .= " is null " ; break;
          case 'nn': $qW .= " is not null " ; break;
          case 'in': $qW .= " in (".$_POST_val['searchString'].")" ; break;
          case 'ni': $qW .= " not in (".$_POST_val['searchString'].")" ; break;
        }
       
    }
    
/*
    //объединяем все полученные условия
    $searchData = json_decode($_POST['filters']);
    foreach ($searchData->rules as $rule) {
      if (!$firstElem) {
        //объединяем условия (с помощью AND или OR)
        if (in_array($searchData->groupOp, $allowedOperations)) {
          $qWhere .= ' '.$searchData->groupOp.' ';
        }
        else {
          //если получили не существующее условие - возвращаем описание ошибки
          throw new Exception('!!!');
        }
      }
      else {
        $firstElem = false;
      }
      
      //вставляем условия

        switch ($rule->op) 
        {
          case 'eq': $qWhere .= $rule->field.' = '.$rule->data; break;
          case 'ne': $qWhere .= $rule->field.' <> '.$rule->data; break;
          case 'bw': $qWhere .= $rule->field.' LIKE '.$rule->data.'%'; break;
          case 'cn': $qWhere .= $rule->field.' LIKE '.'%'.$rule->data.'%'; break;
          default: throw new Exception('!!!');
        }
    }
 
 */
}

if ($qW == ' WHERE ') {$qW ='';};
    
return $qW;    
}

function ukr_month($month_num, $format)
{


$month=array(
    '1'=>"Січень",'2'=>"Лютий",'3'=>"Березень",
    '4'=>"Квітень",'5'=>"Травень",'6'=>"Червень",
    '7'=>"Липень",'8'=>"Серпень",'9'=>"Вересень",
    '10'=>"Жовтень",'11'=>"Листопад",'12'=>"Грудень");

$month_2=array(
    '1'=>"Січня",'2'=>"Лютого",'3'=>"Березня",
    '4'=>"Квітня",'5'=>"Травня",'6'=>"Червня",
    '7'=>"Липня",'8'=>"Серпня",'9'=>"Вересня",
    '10'=>"Жовтня",'11'=>"Листопада",'12'=>"Грудня");

$month_3=array(
    '1'=>"у січні",'2'=>" у лютому",'3'=>" у березні",
    '4'=>"у квітні",'5'=>" у травні",'6'=>" у червні",
    '7'=>"у липні",'8'=>"у серпні",'9'=>" у вересні",
    '10'=>"у жовтні",'11'=>" у листопаді",'12'=>"у грудні");

if ($format == 0)
{
 return $month[$month_num];
}

if ($format == 1)
{
 return $month_2[$month_num];
}

if ($format == 2)
{
 return $month_3[$month_num];
}

}
?>

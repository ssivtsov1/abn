var edit_row_id=0;

jQuery(function(){ 


  jQuery('#bill_table').jqGrid({
    url:'Abon_en_bills_data.php',
    editurl: '',
    datatype: 'json',
    mtype: 'POST',
    height:400,
    //width:800,
    autowidth: true,
    scroll: 0,
    colNames:[],
    colModel :[ 

    {name:'id_doc', index:'id_doc', width:40, editable: false, align:'center', key:true ,hidden:true},
    {name:'id_paccnt', index:'id_paccnt', width:40, editable: false, align:'center',hidden:true},    
    
    {label:'Книга',name:'book', index:'book', width:40, editable: true, align:'left',edittype:'text'},            
    {label:'Рахунок',name:'code', index:'code', width:40, editable: true, align:'left',edittype:'text'},                
    {label:'Абонент',name:'abon', index:'abon', width:150, editable: true, align:'left',edittype:'text'},

    //{label:'Місто/село',name:'town', index:'town', width:100, editable: true, align:'left',edittype:'text'},                    
    //{label:'Вулиця',name:'street', index:'street', width:100, editable: true, align:'left',edittype:'text'},                        
    {label:'Адреса',name:'addr', index:'addr', width:150, editable: true, align:'left',edittype:'text'},                            
    
    
    {label:'№ .',name:'reg_num', index:'reg_num', width:80, editable: true, align:'left',edittype:'text'},            
    {label:'Дата',name:'reg_date', index:'reg_date', width:80, editable: true, 
                        align:'left',edittype:'text',formatter:'date'},
    
    {label:'Тип',name:'idk_doc', index:'idk_doc', width:40, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lidk_doc},stype:'text'},                       
    
    {label:'id_pref',name:'id_pref', index:'id_pref', width:40, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lid_pref},stype:'text'},                       
    
    {label:'Сума,грн',name:'value', index:'value', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           
    {label:'ПДВ,грн',name:'value_tax', index:'value_tax', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           
    
    {label:'mmgg',name:'mmgg', index:'mmgg', width:80, editable: true, align:'left',edittype:'text', hidden:false},
    {name:'dt', index:'dt', width:100, editable: true, align:'left', formatter:'date', hidden:false,
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i'}},
    {label:'Закр.',name:'flock', index:'flock', width:30, editable: true, align:'right',
                            formatter:'checkbox',edittype:'checkbox',
                            stype:'select', searchoptions:{value:': ;1:*'}}

    ],
    pager: '#bill_tablePager',
    rowNum:50,
    rowList:[20,50,100,300,500],
    sortname: 'reg_date',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: 'Рахунки',
    //hiddengrid: false,
    hidegrid: false,
    //postData:{'p_id': id_paccnt},
    jsonReader : {repeatitems: false},

    gridComplete:function(){

    if ($(this).getDataIDs().length > 0) 
    {      
     var first_id = parseInt($(this).getDataIDs()[0]);
     $(this).setSelection(first_id, true);
    }
   },

   onSelectRow: function(rowid) { 
     //   edit_row_id = rowid; 
    },

    
    ondblClickRow: function(id){ 
      //jQuery(this).editGridRow(id,{width:300,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});  
    
    var gsr = jQuery(this).jqGrid('getGridParam','selrow'); 
      if(gsr)
      { 

      //  edit_row_id = id;
      //  $("#fpaccnt_params").find("#pmode").attr('value',0 );
      //  $("#fpaccnt_params").find("#pid_paccnt").attr('value',id );
      //  document.paccnt_params.submit();
        
      } else { alert("Please select Row") }       
      
    } ,  
      
  loadError : function(xhr,st,err) { jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText); }

  }).navGrid('#bill_tablePager',
        {edit:false,add:false,del:false},
        {}, 
        {}, 
        {}, 
        {} 
        ); 

jQuery("#bill_table").jqGrid('filterToolbar','');

jQuery("#bill_table").jqGrid('navButtonAdd','#bill_tablePager',{caption:"Друкувати рахунки",
	onClickButton:function(){ 

       //var filters = jQuery("#bill_table").jqGrid('getGridParam', 'postData').filters;
       var rows = $('#bill_table').getDataIDs();
       var json_str = JSON.stringify(rows);

       $("#fprint_params").find("#pbill_list").attr('value',json_str ); 
       
       $("#fprint_params").attr('target',"_blank" );           
       document.print_params.submit();
  
       ;} 
});



    outerLayout = $("body").layout({
		name:	"outer" 
	,	north__paneSelector:	"#pmain_header"
	,	north__closable:	false
	,	north__resizable:	false
        ,	north__size:		40
	,	north__spacing_open:	0
	,	south__paneSelector:	"#pmain_footer"
	,	south__closable:	false
	,	south__resizable:	false
        ,	south__size:		60
	,	south__spacing_open:	0
	,	center__paneSelector:	"#pmain_content"
	//,	center__onresize:		'innerLayout.resizeAll'
	,	resizeWhileDragging:	true
	,	autoBindCustomButtons:	true
	,       center__onresize:	function (pane, $pane, state, options) 
        {
            $("#bill_table").jqGrid('setGridWidth',$pane.innerWidth()-20);
            $("#bill_table").jqGrid('setGridHeight',$pane.innerHeight()-120);
        }
        
	});

        
    outerLayout.resizeAll();
   // innerLayout.hide('north');        
        
    jQuery(".btn").button();
    jQuery(".btnSel").button({ icons: {primary:'ui-icon-folder-open'} });
        
   $("#debug_ls1").click( function() {jQuery("#message_zone").dialog('open'); });
   $("#debug_ls2").click( function() {jQuery("#message_zone").dialog('close');});
   $("#debug_ls3").click( function() {jQuery("#message_zone").html('');});
   
 /*  
   
   //-------------------------------------------------------------
   $("#pActionBar").find("#bt_add").click( function(){ 

        $("#fpaccnt_params").find("#pmode").attr('value',1 );
        $("#fpaccnt_params").find("#pid_paccnt").attr('value',0 );
        document.paccnt_params.submit();
   });
   //-------------------------------------------------------------
   $("#pActionBar").find("#bt_edit").click( function(){ 

        if ($('#client_table').getDataIDs().length > 0) 
        {
          $("#fpaccnt_params").find("#pmode").attr('value',0 );
          $("#fpaccnt_params").find("#pid_paccnt").attr('value',edit_row_id );
          document.paccnt_params.submit();
        }
   });
   //-------------------------------------------------------------
   $("#pActionBar").find("#bt_abons").click( function(){ 
        window.open ('dov_abon.php','_self',false)
   });
*/
});
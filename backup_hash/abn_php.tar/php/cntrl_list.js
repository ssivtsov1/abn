
jQuery(function(){ 
  jQuery('#cntrl_list_table').jqGrid({
    url:'cntrl_list_data.php',
    editurl: 'cntrl_list_edit.php',
    datatype: 'json',
    mtype: 'POST',
    height:500,
    width:800,
    colNames:['Код','П.І.Б. контролера','Працівник', 'Примітка'],
    colModel :[ 
      {name:'id_cntrl', index:'id_cntrl', width:40, editable: false, align:'center', key:true, hidden:true },     
      {name:'fio_cntrl', index:'fio_cntrl', width:200, editable: true, align:'left',edittype:'text',
          editoptions:{size:40},editrules:{required:true}},           

      {name:'id_person_cntrl', index:'id_person_cntrl', width:100, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lpersons} , 
                            stype:'text' },   
      {name:'notes', index:'notes', width:200, editable: true, align:'left',edittype:"textarea", editoptions:{rows:"2",cols:"40"}}                 
                            
    ],
    pager: '#cntrl_list_tablePager',
    autowidth: true,
    rowNum:50,
    rowList:[20,50,100,300,500],
    sortname: 'fio_cntrl',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: 'Дільниці контролеріів',
    hidegrid: false,
    
    ondblClickRow: function(id){ 
      if(selmode==1)
      {
           window.opener.SelectCntrlExternal(id,jQuery(this).jqGrid('getCell',id,'fio_cntrl') );
           window.opener.focus();
           self.close();            
      }

      if(selmode==0)
      {
         jQuery(this).editGridRow(id,{width:400,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});  
      }

     } ,  

  loadError : function(xhr,st,err) { jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText); }

  }).navGrid('#cntrl_list_tablePager',
        {edit:true,add:true,del:true},
        {width:400,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,
            afterSubmit:processAfterEdit}, 
        {width:400,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,
            afterSubmit:processAfterEdit}, 
        {reloadAfterSubmit:false,afterSubmit:processAfterEdit}, 
        {} 
        ); 


jQuery("#cntrl_list_table").jqGrid('bindKeys', {"onEnter":function( id ) { 
      jQuery(this).editGridRow(id,{width:300,height:300,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});  } } );

$("#message_zone").dialog({ autoOpen: false });

$("#debug_ls1").click( function() {jQuery("#message_zone").dialog('open'); });
$("#debug_ls2").click( function() {jQuery("#message_zone").dialog('close');});
$("#debug_ls3").click( function() {jQuery("#message_zone").html('');});

 outerLayout = $("body").layout({
		name:	"outer" 
	,	north__paneSelector:	"#pmain_header"
	,	north__closable:	false
	,	north__resizable:	false
        ,	north__size:		40
	,	north__spacing_open:	0
	,	south__paneSelector:	"#pmain_footer"
	,	south__closable:	false
	,	south__resizable:	false
        ,	south__size:		40
	,	south__spacing_open:	0
	,	center__paneSelector:	"#grid_dform"
	,	resizeWhileDragging:	true
	,	autoBindCustomButtons:	true
	,       center__onresize:	function (pane, _pane, state, options) 
        {
            jQuery("#cntrl_list_table").jqGrid('setGridWidth',_pane.innerWidth()-9);
            jQuery("#cntrl_list_table").jqGrid('setGridHeight',_pane.innerHeight()-110);
        }

	});
        
        outerLayout.resizeAll();

}); 
 

 //jQuery('#lshow_grid').click( function() { jQuery('#dov_meters_table').jqGrid('setGridParam',{caption: 'Счетчики 111'}).trigger('reloadGrid')});

 function processAfterEdit(response, postdata) {
            //alert(response.responseText);
            if (response.responseText=='') { return [true,'']; }
            else
            {
             errorInfo = jQuery.parseJSON(response.responseText);
             
             if (errorInfo.errcode==0) {
             return [true,errorInfo.errstr]}; 
             
             if (errorInfo.errcode==1) {
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');  
               //jQuery('#message_zone').dialog('open');
               return [true,errorInfo.errstr]};              
               
             if (errorInfo.errcode==2) {
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');                 
               jQuery('#message_zone').dialog('open');
               return [false,errorInfo.errstr]};              
            }
        }

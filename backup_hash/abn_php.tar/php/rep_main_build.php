<?php

header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';
/** PHPExcel_IOFactory */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
 
define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Europe/London');
set_time_limit(6000); 
require_once '../Classes/PHPExcel/IOFactory.php';


session_name("session_kaa");
session_start();

//error_reporting(1);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];


if (isset($_POST['submitButton'])) {
      $oper = $_POST['submitButton'];
}
 else {
    
    if (isset($_POST['oper'])) {
          $oper = $_POST['oper'];
    }
     
}

if ($oper=='rep1')
{
 
    $objReader = PHPExcel_IOFactory::createReader('Excel5');
    $objPHPExcel = $objReader->load("../XL/clientlist.xls");
    
    $SQL = "select acc.id, acc.book, acc.code, acc.note, acc.archive,
    regexp_replace(regexp_replace(acc.code, '-.*?$', '') , '[^0-9]', '','g')::int as int_code,
    (adr.adr||' '||
    (coalesce('буд.'||(acc.addr).house||'','')||
		coalesce('/'||(acc.addr).slash||' ','')||
			coalesce((acc.addr).korp||'','')||
				coalesce(', кв. '||(acc.addr).flat,'')||
					coalesce('/'||(acc.addr).f_slash||' ',''))::varchar
    )::varchar as addr,
    (c.last_name||' '||coalesce(c.name,'')||' '||coalesce(c.patron_name,''))::varchar as abon
    from clm_paccnt_tbl as acc 
    join clm_abon_tbl as c on (c.id = acc.id_abon) 
    left join adv_addr_tbl as adr on (adr.id = (acc.addr).id_class)
    order by acc.book, int_code; ";

   // throw new Exception(json_encode($SQL));

    $result = pg_query($Link, $SQL) or die("SQL Error: " . pg_last_error($Link) . $SQL);
    if ($result) {
        
        $i = 0;
        $baseRow = 6;
        while ($row = pg_fetch_array($result)) {

            
            $r = $baseRow + $i;
            $objPHPExcel->getActiveSheet()->insertNewRowBefore($r,1);
            
       	    $objPHPExcel->getActiveSheet()->setCellValue('B'.$r, $i+1)
	                                  ->setCellValue('C'.$r, $row['book'])
	                                  ->setCellValue('D'.$r, $row['code'])
                                          ->setCellValue('E'.$r, $row['abon'])
                                          ->setCellValue('F'.$r, $row['addr'])
                                          ->setCellValue('H'.$r, $row['note']);

            $i++;
        }
    }
    
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save("../tmp/clientlist.xls");
    //$objWriter->save('php://output');
    echo_result(1, 'report generated');
    
}


echo_result(0, 'nothing to do');
?>
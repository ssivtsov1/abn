<?php
header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();

error_reporting(1);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) { 
    $ids=$_SESSION['id_sess'];  
    $res_par=sel_par($ids);
    $row_par=pg_fetch_array($res_par);
    $cons=$row_par['con_str1'];
    //$Q=$row_par['qu'];
    $Link=pg_connect($cons) or die("Connection Error: " .pg_last_error($Link) );
}
//print("<br> ids =  $ids cons = $cons "); 
*/
$node = sql_field_val('cur_node', 'int');

$Query= " (select id,name from lgi_kategor_tbl 
        where ((lgt_isparent_fun(id, $node) = false) and (id<>$node)) or ($node is null)
        order by sort) as ss ";

$lcategoryselect = DbTableSelect($Link,$Query,'id','name');

echo $lcategoryselect;


?>
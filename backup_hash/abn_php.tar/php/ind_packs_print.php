<?php

header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();
error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) {
  $ids = $_SESSION['id_sess'];

  $res_par = sel_par($ids);
  $row_par = pg_fetch_array($res_par);
  $cons = $row_par['con_str1'];
  $Q = $row_par['qu'];
  $Link = pg_connect($cons);
}
*/
//$lnk_sys = log_s_pgsql("login");
//$lnk1 = $lnk_sys['lnks'];

//$rr = pg_query($Link, $Q);
/*
$idgrt = 0;
$idtar = 0;
$idgrpl = 0;
$idbperc = 0;

$QS = "update dbusr_var set idgrt=" . $idgrt . ",idtar=" . $idtar . ",idgrpl=" . $idgrpl .
        ",idbperc=" . $idbperc . " where id_sess=" . $ids;
$res_qs = pg_query($lnk1, $QS);
*/

$nmp1 = "Абон-енерго (Рознесення показань)";
  
start_mpage($nmp1); //заголовок
head_addrpage();  // хедер, подключение библиотек

$id_pack = sql_field_val('id','int');

$id_sector = sql_field_val('id_sector', 'int');
$sector = sql_field_val('sector', 'str');
$id_runner = sql_field_val('id_runner', 'int');
$runner = sql_field_val('runner', 'str');
$id_ioper = sql_field_val('id_ioper', 'int');
  
$num_pack = sql_field_val('num_pack', 'str');
$dt_pack = sql_field_val('dt_pack', 'str');


print('<link rel="stylesheet" type="text/css" href="css/ded_styles.css" /> ');
print('<link rel="stylesheet" type="text/css" href="css/layout-default-latest.css" /> ');
print('<script type="text/javascript" src="js/jquery.layout.min-latest.js"></SCRIPT>');
print('<script type="text/javascript" src="js/jquery.form.js"></script>');
print('<script type="text/javascript" src="js/jquery.validate.min.js" ></script>');
print('<script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.ui.datepicker-uk.js"></script> ');
print('<script type="text/javascript" src="js/jquery.maskedinput-1.3.min.js"></script> ');

?>

<style type="text/css">
body {background-color: white}
.tab_head {font-family: "Times New Roman", Times, serif; font-size: 12px; }
.table_footer{font-family: "Times New Roman", Times, serif; font-size: 12px; }

table.indic_print_table { border-collapse:collapse; font-family: "Times New Roman", Times, serif; font-size: 11px; }
table.indic_print_table td, table.indic_print_table th { border:1px solid black;padding:2px; }

.tab_street { border:2px solid black; }

@page {margin-left:2cm; margin-right:1cm;}

</style>

</head>
<body >


    <DIV id="pmain_center" style="padding:2px; margin:3px;">    
        <div id="pheader" style="padding:2px; margin:3px;text-align:center; ">  
            <b> ВІДОМІСТЬ  </b>  </br> 
            облiку показань лiчильникiв та вручення рахункiв на оплату електроенергii </br> 
            № <b> <?php echo "$num_pack" ?>; </b>від <b><?php echo "$dt_pack" ?>; </b> </br> 
            Дільниця: <b> <?php echo "$sector" ?>;</b> </br> 
            Кур'єр/контролер: <b> <?php echo "$runner" ?>; </b> </br> 
        </div>    

<table class ="indic_print_table">
  <tr>
    <th width="4%" height="51" scope="col"><span class="tab_head">№ п/п </span></th>
    <th width="24%" scope="col"><span class="tab_head">Прiзвище, iм'я, по батьковi <br> 
    Адреса</span></th>
    <th width="7%" scope="col"><span class="tab_head">Особ.рах.</span></th>
    <th width="6%" scope="col"><span class="tab_head">Номер лiчиль- ника</span></th>
    <th width="5%" scope="col"><span class="tab_head">Роз ряд ність</span></th>
    <th width="6%" scope="col"><span class="tab_head">Зона фазн. </span></th>
    <th width="9%" scope="col"><span class="tab_head">Порередні показання лічильника </span></th>
    <th width="10%" scope="col"><span class="tab_head">Дата зняття попер. показань </span></th>
    <th width="10%" scope="col"><span class="tab_head">Показання лічильника на дату зняття </span></th>
    <th width="10%" scope="col"><span class="tab_head">Дата зняття показань та вручення рахунку</span></th>
    <th width="9%" scope="col"><span class="tab_head">Підпис споживача </span></th>
  </tr>
  
 <?php
$SQL = " select pd.*, acc.book, acc.code, adr.adr as street, address_print(acc.addr) as adr,
 (c.last_name||' '||coalesce(c.name,'')||' '||coalesce(c.patron_name,''))::varchar as abon,
 im.carry ,
 (CASE WHEN z.id = 0 THEN '' ELSE z.nm END)||(CASE WHEN im.phase = 1 THEN '' ELSE ' 3f' END)::varchar as zone_phase
from 
ind_pack_data as pd 
join clm_paccnt_tbl as acc on (acc.id = pd.id_paccnt)
join clm_abon_tbl as c on (c.id = acc.id_abon) 
join eqi_meter_tbl as im on (im.id = pd.id_type_meter)
left join eqk_zone_tbl as z on (z.id = pd.id_zone)
left join adv_addr_tbl as adr on (adr.id = (acc.addr).id_class)
 where id_pack = $id_pack 
 order by adr.adr, (acc.addr).house, (acc.addr).korp , (acc.addr).flat::int ;"; 


$result = pg_query($Link,$SQL) or die("SQL Error: " .pg_last_error($Link) );
$nn = 0;  
$prn_nn = 5;
$prn_max = 45;
$table_text= "";
$cur_street= "";
if ($result) 
{
 while($row = pg_fetch_array($result)) 
  {
    $nn++;
    $abon            =$row['abon']; 
    $adr             =$row['adr']; 
    $street          =$row['street'];     
    $code            =$row['code']; 
    $book            =$row['book']; 
    $num_meter       =$row['num_meter']; 
    $carry           =$row['carry']; 
    $zone_phase      =$row['zone_phase']; 
    $p_indic         =$row['p_indic']; 
    $dt_p_indic      =$row['dt_p_indic']; 
    
    if ($cur_street != $street) {
        $prn_nn ++;
        $cur_street=$street;
            $table_text.= "
             <tr class = 'tab_street'>
              <td ></td>
              <td colspan = '10'>$cur_street</td>
             </tr> ";
    }

    $table_text.= <<<TAB_STR

  <tr>
    <td rowspan="2">$nn</td>
    <td>$abon</td>
    <td rowspan="2">$book/$code</td>
    <td rowspan="2">$num_meter</td>
    <td rowspan="2">$carry</td>
    <td rowspan="2">$zone_phase</td>
    <td rowspan="2">$p_indic</td>
    <td rowspan="2">$dt_p_indic</td>
    <td rowspan="2">&nbsp;</td>
    <td rowspan="2">&nbsp;</td>
    <td rowspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td>$adr</td>
  </tr>
   
TAB_STR;
    
    $prn_nn=$prn_nn+2;
    if ($prn_nn>=$prn_max)
    {
        $table_text.= '</table>';
        $table_text.= '<br style="page-break-after: always">';
        $table_text.= '<table class ="indic_print_table"> <tr>
    <th width="4%" height="51" scope="col"><span class="tab_head">№ п/п </span></th>
    <th width="24%" scope="col"><span class="tab_head">Прiзвище, iм\'я, по батьковi <br> 
    Адреса</span></th>
    <th width="7%" scope="col"><span class="tab_head">Особ.рах.</span></th>
    <th width="6%" scope="col"><span class="tab_head">Номер лiчиль- ника</span></th>
    <th width="5%" scope="col"><span class="tab_head">Роз ряд ність</span></th>
    <th width="6%" scope="col"><span class="tab_head">Зона фазн. </span></th>
    <th width="9%" scope="col"><span class="tab_head">Порередні показання лічильника </span></th>
    <th width="10%" scope="col"><span class="tab_head">Дата зняття попер. показань </span></th>
    <th width="10%" scope="col"><span class="tab_head">Ноказання лічильника на дату зняття </span></th>
    <th width="10%" scope="col"><span class="tab_head">Дата зняття показань та вручення рахунку</span></th>
    <th width="9%" scope="col"><span class="tab_head">Підпис споживача </span></th>
  </tr>';

        $prn_nn = 1;
        
    
    }
    
  }
}
echo $table_text;
 
 ?>
  
</table>
    <div class ="table_footer">        
       <br/><br/> 
       &nbsp;&nbsp;Дата здачi вiдомостi <br/><br/>

       &nbsp;&nbsp;Дата прийому виконаної роботи<br/><br/>

       <div style="float:left; width: 400; ">
        &nbsp;&nbsp;Пiдпис вiдповiдальної особи, яка приймає завдання <br/><br/>
        &nbsp;&nbsp;Пiдпис виконавця
       </div>
       <div style="float:left; text-align:center;">
        _________________________________<br/>
        посада, П.I.Б.<br/>
        _________________________________<br/>
        посада, П.I.Б.<br/>

       </div>
     </div>        
    </div>        
    

      <div id="dialog-confirm" title="" style="display:none;">
	<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        <p id="dialog-text"> </p></p>
      </div>

    <div id="dialog-changedate" title="Дата редагування" style="display:none;">
	<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        <p id="dialog-text">Вкажіть дату редагування </p></p>
        <br>
        <input name="date_change" type="text" size="20" class="dtpicker" id ="fdate_change"/>
    </div>

<?php

print('<div id="message_zone" style ="padding: 5px;color: blue;" >  </div>');


end_mpage();
?>
var edit_row_id=0;

jQuery(function(){ 

  jQuery('#indic_table').jqGrid({
    url:'Abon_en_saldo_indic_data.php',
    editurl: '',
    datatype: 'json',
    mtype: 'POST',
    height:400,
    //width:800,
    autowidth: true,
    scroll: 0,
    colNames:[],
    colModel :[ 

    {name:'id', index:'id', width:40, editable: false, align:'center', key:true ,hidden:true},
//    {name:'id_pack', index:'id_pack', width:40, editable: false, align:'center',hidden:true},
    {name:'id_paccnt', index:'id_paccnt', width:40, editable: false, align:'center',hidden:true},    
    {name:'id_meter', index:'id_meter', width:40, editable: false, align:'center',hidden:true},    
    {name:'id_type_meter', index:'id_type_meter', width:40, editable: false, align:'center',hidden:true},    
 //   {name:'id_p_indic', index:'id_p_indic', width:40, editable: false, align:'center',hidden:true},    
    
    {label:'№ ліч.',name:'num_meter', index:'num_meter', width:80, editable: true, align:'left',edittype:'text'},            
    {label:'Тип ліч.',name:'type_meter', index:'type_meter', width:80, editable: true, align:'left',edittype:'text'},                
    {label:'Розр. ліч.',name:'carry', index:'carry', width:40, editable: true, align:'left',edittype:'text'},                    
    {label:'К.тр',name:'k_tr', index:'k_tr', width:40, editable: true, align:'left',edittype:'text'},                        
    {label:'Зона',name:'id_zone', index:'id_zone', width:60, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lzones},stype:'text'},                       

    {label:'Операція',name:'kind_operation', index:'kind_operation', width:60, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lindicoper},stype:'text'},                       

    //{label:'Попер.пок.',name:'p_indic', index:'p_indic', width:80, editable: true, align:'right',hidden:false,edittype:'text'},           

    //{label:'Дата попер.',name:'dt_p_indic', index:'dt_p_indic', width:80, editable: true, 
    //                    align:'left',edittype:'text',formatter:'date'},

    {label:'Поточні пок.',name:'indic', index:'indic', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text'},           
    
    {label:'Дата',name:'dat_ind', index:'dat_ind', width:80, editable: true, 
                        align:'left',edittype:'text',formatter:'date'},


    {label:'mmgg',name:'mmgg', index:'mmgg', width:80, editable: true, align:'left',edittype:'text', hidden:true},
    {name:'dt', index:'dt', width:100, editable: true, align:'left', formatter:'date', hidden:true,
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i'}},
    {label:'Закр.',name:'flock', index:'flock', width:30, editable: true, align:'right',
                            formatter:'checkbox',edittype:'checkbox',
                            stype:'select', searchoptions:{value:': ;1:*'}}
        

    ],
    pager: '#indic_tablePager',
    rowNum:50,
    rowList:[20,50,100,300,500],
    sortname: 'dat_ind',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: 'Показники',
    //hiddengrid: false,
    hidegrid: false,
    postData:{'p_id': id_paccnt},

    gridComplete:function(){

    if ($(this).getDataIDs().length > 0) 
    {      
     var first_id = parseInt($(this).getDataIDs()[0]);
     $(this).setSelection(first_id, true);
    }
   },

   onSelectRow: function(rowid) { 
      //  edit_row_id = rowid; 
    },

    
    ondblClickRow: function(id){ 
      //jQuery(this).editGridRow(id,{width:300,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});  
    
    var gsr = jQuery(this).jqGrid('getGridParam','selrow'); 
      if(gsr)
      { 

      //  edit_row_id = id;
      //  $("#fpaccnt_params").find("#pmode").attr('value',0 );
      //  $("#fpaccnt_params").find("#pid_paccnt").attr('value',id );
      //  document.paccnt_params.submit();
        
      } else { alert("Please select Row") }       
      
    } ,  
      
  loadError : function(xhr,st,err) { jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText); }

  }).navGrid('#indic_tablePager',
        {edit:false,add:false,del:false},
        {}, 
        {}, 
        {}, 
        {} 
        ); 


  jQuery('#bill_table').jqGrid({
    url:'Abon_en_saldo_bill_data.php',
    editurl: '',
    datatype: 'json',
    mtype: 'POST',
    height:400,
    //width:800,
    autowidth: true,
    scroll: 0,
    colNames:[],
    colModel :[ 

    {name:'id_doc', index:'id', width:40, editable: false, align:'center', key:true ,hidden:true},
    {name:'id_paccnt', index:'id_paccnt', width:40, editable: false, align:'center',hidden:true},    
    
    {label:'№ .',name:'reg_num', index:'reg_num', width:80, editable: true, align:'left',edittype:'text'},            
    {label:'Дата',name:'reg_date', index:'reg_date', width:80, editable: true, 
                        align:'left',edittype:'text',formatter:'date'},
    
    {label:'Тип',name:'idk_doc', index:'idk_doc', width:60, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lidk_doc},stype:'text'},                       
    
    {label:'id_pref',name:'id_pref', index:'id_pref', width:60, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lid_pref},stype:'text'},                       
    
    {label:'Сума,грн',name:'value', index:'value', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           
    {label:'ПДВ,грн',name:'value_tax', index:'value_tax', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           
    
    {label:'mmgg',name:'mmgg', index:'mmgg', width:80, editable: true, align:'left',edittype:'text', hidden:true},
    {name:'dt', index:'dt', width:100, editable: true, align:'left', formatter:'date', hidden:true,
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i'}},
    {label:'Закр.',name:'flock', index:'flock', width:30, editable: true, align:'right',
                            formatter:'checkbox',edittype:'checkbox',
                            stype:'select', searchoptions:{value:': ;1:*'}}

    ],
    pager: '#bill_tablePager',
    rowNum:50,
    rowList:[20,50,100,300,500],
    sortname: 'reg_date',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: 'Рахунки',
    //hiddengrid: false,
    hidegrid: false,
    postData:{'p_id': id_paccnt},

    gridComplete:function(){

    if ($(this).getDataIDs().length > 0) 
    {      
     var first_id = parseInt($(this).getDataIDs()[0]);
     $(this).setSelection(first_id, true);
    }
   },

   onSelectRow: function(rowid) { 
     //   edit_row_id = rowid; 
    },

    
    ondblClickRow: function(id){ 
      //jQuery(this).editGridRow(id,{width:300,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});  
    
    var gsr = jQuery(this).jqGrid('getGridParam','selrow'); 
      if(gsr)
      { 

      //  edit_row_id = id;
      //  $("#fpaccnt_params").find("#pmode").attr('value',0 );
      //  $("#fpaccnt_params").find("#pid_paccnt").attr('value',id );
      //  document.paccnt_params.submit();
        
      } else { alert("Please select Row") }       
      
    } ,  
      
  loadError : function(xhr,st,err) { jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText); }

  }).navGrid('#bill_tablePager',
        {edit:false,add:false,del:false},
        {}, 
        {}, 
        {}, 
        {} 
        ); 




  jQuery('#pay_table').jqGrid({
    url:'Abon_en_saldo_pay_data.php',
    editurl: '',
    datatype: 'json',
    mtype: 'POST',
    height:400,
    //width:800,
    autowidth: true,
    scroll: 0,
    colNames:[],
    colModel :[ 

    {name:'id_doc', index:'id', width:40, editable: false, align:'center', key:true ,hidden:true},
    {name:'id_paccnt', index:'id_paccnt', width:40, editable: false, align:'center',hidden:true},    
    
    {label:'№ .',name:'reg_num', index:'reg_num', width:80, editable: true, align:'left',edittype:'text'},            

    {label:'Дата опл.',name:'reg_date', index:'reg_date', width:80, editable: true, 
                        align:'left',edittype:'text',formatter:'date'},

    {label:'Дата надх.',name:'pay_date', index:'pay_date', width:80, editable: true, 
                        align:'left',edittype:'text',formatter:'date'},
    
    {label:'Тип',name:'idk_doc', index:'idk_doc', width:60, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lidk_doc},stype:'text'},                       
    
    {label:'id_pref',name:'id_pref', index:'id_pref', width:60, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lid_pref},stype:'text'},                       

    {label:'Сума,грн',name:'value_pay', index:'value_pay', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           

    {label:'Без ПДВ,грн',name:'value', index:'value', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           
    
    {label:'ПДВ,грн',name:'value_tax', index:'value_tax', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           
    
    {label:'mmgg',name:'mmgg', index:'mmgg', width:80, editable: true, align:'left',edittype:'text', hidden:true},
    {name:'dt', index:'dt', width:100, editable: true, align:'left', formatter:'date', hidden:true,
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i'}},
    {label:'Закр.',name:'flock', index:'flock', width:30, editable: true, align:'right',
                            formatter:'checkbox',edittype:'checkbox',
                            stype:'select', searchoptions:{value:': ;1:*'}}

    ],
    pager: '#pay_tablePager',
    rowNum:50,
    rowList:[20,50,100,300,500],
    sortname: 'reg_date',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: 'Платежі',
    //hiddengrid: false,
    hidegrid: false,
    postData:{'p_id': id_paccnt},

    gridComplete:function(){

    if ($(this).getDataIDs().length > 0) 
    {      
     var first_id = parseInt($(this).getDataIDs()[0]);
     $(this).setSelection(first_id, true);
    }
   },

   onSelectRow: function(rowid) { 
     //   edit_row_id = rowid; 
    },

    
    ondblClickRow: function(id){ 
      //jQuery(this).editGridRow(id,{width:300,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});  
    
    var gsr = jQuery(this).jqGrid('getGridParam','selrow'); 
      if(gsr)
      { 

      //  edit_row_id = id;
      //  $("#fpaccnt_params").find("#pmode").attr('value',0 );
      //  $("#fpaccnt_params").find("#pid_paccnt").attr('value',id );
      //  document.paccnt_params.submit();
        
      } else { alert("Please select Row") }       
      
    } ,  
      
  loadError : function(xhr,st,err) { jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText); }

  }).navGrid('#pay_tablePager',
        {edit:false,add:false,del:false},
        {}, 
        {}, 
        {}, 
        {} 
        ); 


  jQuery('#saldo_table').jqGrid({
    url:'Abon_en_saldo_saldo_data.php',
    editurl: '',
    datatype: 'json',
    mtype: 'POST',
    //height:500,
    //width:800,
    autowidth: true,
    scroll: 0,
    colNames:[],
    colModel :[ 

    {name:'id', index:'id', width:40, editable: false, align:'center', key:true ,hidden:true},
    {name:'id_paccnt', index:'id_paccnt', width:40, editable: false, align:'center',hidden:true},    
    
    {label:'id_pref',name:'id_pref', index:'id_pref', width:60, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lid_pref},stype:'text'},                       
                        
    {label:'mmgg',name:'mmgg', index:'mmgg', width:80, editable: true, align:'left',edittype:'text', hidden:true},

    {label:'Борг початок,грн',name:'b_val', index:'b_val', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           

    {label:'Борг початок ПДВ,грн',name:'b_valtax', index:'b_valtax', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           

    {label:'Нараховано,грн',name:'dt_val', index:'dt_val', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           

    {label:'Нараховано ПДВ,грн',name:'dt_valtax', index:'dt_valtax', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           

    {label:'Сплачено,грн',name:'kt_val', index:'kt_val', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           

    {label:'Сплачено ПДВ,грн',name:'kt_valtax', index:'kt_valtax', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           


    {label:'Борг кінець,грн',name:'e_val', index:'e_val', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           

    {label:'Борг кінець ПДВ,грн',name:'e_valtax', index:'e_valtax', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text',formatter:'number' },           

    {label:'Закр.',name:'flock', index:'flock', width:30, editable: true, align:'right',
                            formatter:'checkbox',edittype:'checkbox',
                            stype:'select', searchoptions:{value:': ;1:*'}}

    ],
    pager: '#saldo_tablePager',
    rowNum:50,
    rowList:[20,50,100,300,500],
    sortname: 'reg_date',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: 'Сальдо',
    //hiddengrid: false,
    hidegrid: false,
    postData:{'p_id': id_paccnt},

    gridComplete:function(){

    if ($(this).getDataIDs().length > 0) 
    {      
     var first_id = parseInt($(this).getDataIDs()[0]);
     $(this).setSelection(first_id, true);
    }
   },

   onSelectRow: function(rowid) { 
     //   edit_row_id = rowid; 
    },

    
    ondblClickRow: function(id){ 
      //jQuery(this).editGridRow(id,{width:300,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});  
    
    var gsr = jQuery(this).jqGrid('getGridParam','selrow'); 
      if(gsr)
      { 

      //  edit_row_id = id;
      //  $("#fpaccnt_params").find("#pmode").attr('value',0 );
      //  $("#fpaccnt_params").find("#pid_paccnt").attr('value',id );
      //  document.paccnt_params.submit();
        
      } else { alert("Please select Row") }       
      
    } ,  
      
  loadError : function(xhr,st,err) { jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText); }

  }).navGrid('#saldo_tablePager',
        {edit:false,add:false,del:false},
        {}, 
        {}, 
        {}, 
        {} 
        ); 




//jQuery("#client_table").jqGrid('filterToolbar','');

    outerLayout = $("body").layout({
		name:	"outer" 
	,	north__paneSelector:	"#pmain_header"
	,	north__closable:	false
	,	north__resizable:	false
        ,	north__size:		40
	,	north__spacing_open:	0
	,	south__paneSelector:	"#pmain_footer"
	,	south__closable:	false
	,	south__resizable:	false
        ,	south__size:		60
	,	south__spacing_open:	0
	,	center__paneSelector:	"#pmain_content"
	//,	center__onresize:		'innerLayout.resizeAll'
	,	resizeWhileDragging:	true
	,	autoBindCustomButtons:	true
	,       center__onresize:	function (pane, $pane, state, options) 
        {
            
            $("#saldo_table").jqGrid('setGridWidth',$pane.innerWidth()-10);
            
            $("#indic_table").jqGrid('setGridWidth',$pane.innerWidth()-20);
            $("#bill_table").jqGrid('setGridWidth',$pane.innerWidth()-20);
            $("#pay_table").jqGrid('setGridWidth',$pane.innerWidth()-20);

            $("#indic_table").jqGrid('setGridHeight',$pane.innerHeight()-$("#psaldo_list").outerHeight()-120);
            $("#bill_table").jqGrid('setGridHeight',$pane.innerHeight()-$("#psaldo_list").outerHeight()-120);
            $("#pay_table").jqGrid('setGridHeight',$pane.innerHeight()-$("#psaldo_list").outerHeight()-120);

        }
        
	});

        
    outerLayout.resizeAll();
   // innerLayout.hide('north');        
        
    jQuery(".btn").button();
    jQuery(".btnSel").button({ icons: {primary:'ui-icon-folder-open'} });
        
   $("#debug_ls1").click( function() {jQuery("#message_zone").dialog('open'); });
   $("#debug_ls2").click( function() {jQuery("#message_zone").dialog('close');});
   $("#debug_ls3").click( function() {jQuery("#message_zone").html('');});
   
   $( "#pTabs" ).tabs({
      //  show: $.layout.callbacks.resizeTabLayout        
    });
 /*  
   
   //-------------------------------------------------------------
   $("#pActionBar").find("#bt_add").click( function(){ 

        $("#fpaccnt_params").find("#pmode").attr('value',1 );
        $("#fpaccnt_params").find("#pid_paccnt").attr('value',0 );
        document.paccnt_params.submit();
   });
   //-------------------------------------------------------------
   $("#pActionBar").find("#bt_edit").click( function(){ 

        if ($('#client_table').getDataIDs().length > 0) 
        {
          $("#fpaccnt_params").find("#pmode").attr('value',0 );
          $("#fpaccnt_params").find("#pid_paccnt").attr('value',edit_row_id );
          document.paccnt_params.submit();
        }
   });
   //-------------------------------------------------------------
   $("#pActionBar").find("#bt_abons").click( function(){ 
        window.open ('dov_abon.php','_self',false)
   });
*/
});
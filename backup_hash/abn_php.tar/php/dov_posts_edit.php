<?php
header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';


session_name("session_kaa");
session_start();

error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) { $ids=$_SESSION['id_sess'];  

	$res_par=sel_par($ids);
	$row_par=pg_fetch_array($res_par);
	$cons=$row_par['con_str1'];
	$Q=$row_par['qu'];
//	$id=$row_par['id'];
//	$id_e1=$row_par['idreg'];
	$Link=pg_connect($cons);}

	$lnk_sys=log_s_pgsql("login");
	$lnk1=$lnk_sys['lnks'];
*/ 
//if (isset($_POST['id_dov'])) { $idtwn=$_POST['id_dov']; 
//	$QS="update dbusr_var set idtwn=".$idtwn." where id_sess=".$ids;
//	$res_qs=pg_query($lnk1,$QS);
//	echo $idtwn."+++".$QS;
//}

 
// connect to the database
//$rr=pg_query($Link,$Q);

try {

if (isset($_POST['oper'])) {
$oper=$_POST['oper'];

//------------------------------------------------------
if ($oper=="edit") {

$p_name = sql_field_val('name','string');
$p_ident=sql_field_val('ident','string');

$p_id=sql_field_val('id','int');    

$QE="UPDATE prs_posts
   SET name=$p_name, ident=$p_ident  WHERE id = $p_id;";

 //echo json_encode(array('errMess'=>'Error: '));

 $res_e=pg_query($Link,$QE);
 if ($res_e) {echo_result(1,'Data updated');}
 else        {echo_result(2,pg_last_error($Link));}
}
//------------------------------------------------------
if ($oper=="add") {

$p_name = sql_field_val('name','string');
$p_ident=sql_field_val('ident','string');

 $QE="insert into prs_posts(name,ident) values($p_name,$p_ident) ;"; 

 $res_e=pg_query($Link,$QE);
 if ($res_e) {echo_result(1,'Data ins');}
 else        {echo_result(2,pg_last_error($Link));}

 }
//------------------------------------------------------
if ($oper=="del") {

 $p_id=sql_field_val('id','int');    
 $QE="Delete from prs_posts where id= $p_id;"; 

 $res_e=pg_query($Link,$QE);

 if ($res_e) {echo_result(1,'Data delated');}
 else        {echo_result(2,pg_last_error($Link));}
}

}


}
catch (Exception $e) {

 echo echo_result(1,'Error: '.$e->getMessage());
}

?>
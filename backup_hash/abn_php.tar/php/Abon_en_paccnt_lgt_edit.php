<?php

header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';



session_name("session_kaa");
session_start();

error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) {
    $ids = $_SESSION['id_sess'];

    $res_par = sel_par($ids);
    $row_par = pg_fetch_array($res_par);
    $cons = $row_par['con_str1'];
    $Q = $row_par['qu'];
//	$id=$row_par['id'];
//	$id_e1=$row_par['idreg'];
    $Link = pg_connect($cons);
}
*/
//$lnk_sys=log_s_pgsql("login");
//$lnk1=$lnk_sys['lnks'];
//if (isset($_POST['id_dov'])) { $idtwn=$_POST['id_dov']; 
//	$QS="update dbusr_var set idtwn=".$idtwn." where id_sess=".$ids;
//	$res_qs=pg_query($lnk1,$QS);
//	echo $idtwn."+++".$QS;
//}
// connect to the database
//$rr=pg_query($Link,$Q);
//echo_result(2,json_encode($_POST));
//return;

try {

    if (isset($_POST['oper'])) {
        $oper = $_POST['oper'];
    }

    $p_id_paccnt = sql_field_val('id_paccnt', 'int');

    $p_id_grp_lgt = sql_field_val('id_grp_lgt', 'int');
    $p_id_calc = sql_field_val('id_calc', 'int');
    $p_prior_lgt = sql_field_val('prior_lgt', 'int');
    $p_fio_lgt = sql_field_val('fio_lgt', 'string');
    $p_id_doc = sql_field_val('id_doc', 'int');
    $p_family_cnt = sql_field_val('family_cnt', 'int');
    $p_s_doc = sql_field_val('s_doc', 'string');
    $p_n_doc = sql_field_val('n_doc', 'string');
    $p_dt_doc = sql_field_val('dt_doc', 'date');
    $p_ident_cod_l = sql_field_val('ident_cod_l', 'string');
    $p_dt_reg = sql_field_val('dt_reg', 'date');
    $p_dt_start = sql_field_val('dt_start', 'date');
    $p_dt_end = sql_field_val('dt_end', 'date');

    $p_change_date    = sql_field_val('change_date','date');
    $p_id_usr = $session_user; // где взять текущего юзера?    
    $p_id = sql_field_val('id', 'int');


//------------------------------------------------------
    if ($oper == "add") {

   

        $result = pg_query($Link, "begin");
        if (!($result)) {
            echo_result(2, pg_last_error($Link));
            return;
        }

        $QE = "select lgt_change_fun(1,$p_id_paccnt,null,$p_dt_start,$p_id_usr,1)";

        $result = pg_query($Link, $QE);
        if (!($result)) {
            echo_result(2, pg_last_error($Link));
            pg_query($Link, "rollback");
            return;
        }


        $QE = "INSERT INTO lgm_abon_tbl(id, id_paccnt, id_calc, id_grp_lgt, prior_lgt, family_cnt, fio_lgt, id_doc, s_doc, 
            n_doc, dt_doc, ident_cod_l, dt_reg, dt_start, dt_end, id_person)
            VALUES (DEFAULT, $p_id_paccnt, $p_id_calc, $p_id_grp_lgt, $p_prior_lgt, $p_family_cnt,$p_fio_lgt, $p_id_doc, $p_s_doc, 
            $p_n_doc, $p_dt_doc, $p_ident_cod_l, $p_dt_reg, $p_dt_start, $p_dt_end,$p_id_usr) returning id;";

        $res_e = pg_query($Link, $QE);
        
        $row = pg_fetch_array($res_e);
        $new_id = $row["id"];
        
        if ($res_e) {
            pg_query($Link, "commit");
            echo_result(-1, 'Data ins');
        } else {
            echo_result(2, pg_last_error($Link));
            pg_query($Link, "rollback");            
        }
    }
//------------------------------------------------------
    if ($oper == "edit") {


        $result = pg_query($Link, "begin");
        if (!($result)) {
            echo_result(2, pg_last_error($Link));
            return;
        }

        $QE = "select lgt_change_fun(2,$p_id_paccnt,$p_id,$p_change_date,$p_id_usr,1)";

        $result = pg_query($Link, $QE);
        if (!($result)) {
            echo_result(2, pg_last_error($Link));
            pg_query($Link, "rollback");
            return;
        }


        $QE = "update lgm_abon_tbl set 
        id_grp_lgt = $p_id_grp_lgt, id_calc = $p_id_calc, prior_lgt=$p_prior_lgt, fio_lgt = $p_fio_lgt, id_doc = $p_id_doc,
        s_doc=$p_s_doc, n_doc=$p_n_doc, dt_doc=$p_dt_doc, ident_cod_l=$p_ident_cod_l, dt_reg = $p_dt_reg,
        dt_start=$p_dt_start, dt_end=$p_dt_end, family_cnt = $p_family_cnt
        where id = $p_id ;";

        $res_e = pg_query($Link, $QE);
        
        if ($res_e) {
            pg_query($Link, "commit");
            echo_result(1, 'Data updated');
        } else {
            echo_result(2, pg_last_error($Link));
            pg_query($Link, "rollback");            
        }
    }
    
//------------------------------------------------------
    if ($oper == "del") {

        $result = pg_query($Link, "begin");
        if (!($result)) {
            echo_result(2, pg_last_error($Link));
            return;
        }

        $QE = "select lgt_change_fun(3,$p_id_paccnt,$p_id,$p_change_date,$p_id_usr,1)";

        $result = pg_query($Link, $QE);
        if (!($result)) {
            echo_result(2, pg_last_error($Link));
            pg_query($Link, "rollback");
            return;
        }        
        
        $QE = "Delete from lgm_abon_tbl where id= $p_id;";        
        $res_e = pg_query($Link, $QE);

        if ($res_e) {
            echo_result(-1, 'Data delated');
            pg_query($Link, "commit");            
        } else {
            echo_result(2, pg_last_error($Link));
            pg_query($Link, "rollback");            
        }
    }
} catch (Exception $e) {

    echo echo_result(1, 'Error: ' . $e->getMessage());
}
?>
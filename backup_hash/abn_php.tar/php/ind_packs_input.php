<?php

header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();
error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) {
  $ids = $_SESSION['id_sess'];

  $res_par = sel_par($ids);
  $row_par = pg_fetch_array($res_par);
  $cons = $row_par['con_str1'];
  $Q = $row_par['qu'];
  $Link = pg_connect($cons);
}
*/
//$lnk_sys = log_s_pgsql("login");
//$lnk1 = $lnk_sys['lnks'];

//$rr = pg_query($Link, $Q);
/*
$idgrt = 0;
$idtar = 0;
$idgrpl = 0;
$idbperc = 0;

$QS = "update dbusr_var set idgrt=" . $idgrt . ",idtar=" . $idtar . ",idgrpl=" . $idgrpl .
        ",idbperc=" . $idbperc . " where id_sess=" . $ids;
$res_qs = pg_query($lnk1, $QS);
*/

$nmp1 = "Абон-енерго (Рознесення показань)";
  
start_mpage($nmp1); //заголовок
head_addrpage();  // хедер, подключение библиотек

$lioper=DbTableSelList($Link,'indic_opration','id','name');
$lioperselect=DbTableSelect($Link,'indic_opration','id','name');

$lzones=DbTableSelList($Link,'eqk_zone_tbl','id','nm');
$lzoneselect=DbTableSelect($Link,'eqk_zone_tbl','id','nm');

$id_pack = sql_field_val('id','int');

$id_sector = sql_field_val('id_sector', 'int');
$sector = sql_field_val('sector', 'str');
$id_runner = sql_field_val('id_runner', 'int');
$runner = sql_field_val('runner', 'str');
$id_ioper = sql_field_val('id_ioper', 'int');
  
$num_pack = sql_field_val('num_pack', 'str');
$dt_pack = sql_field_val('dt_pack', 'str');


print('<link rel="stylesheet" type="text/css" href="css/ded_styles.css" /> ');
print('<link rel="stylesheet" type="text/css" href="css/layout-default-latest.css" /> ');
print('<script type="text/javascript" src="js/jquery.layout.min-latest.js"></SCRIPT>');
print('<script type="text/javascript" src="js/jquery.form.js"></script>');
print('<script type="text/javascript" src="js/jquery.validate.min.js" ></script>');
print('<script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.ui.datepicker-uk.js"></script> ');
print('<script type="text/javascript" src="js/jquery.maskedinput-1.3.min.js"></script> ');


print('<script type="text/javascript" src="ind_packs_input.js"></script> ');

echo <<<SCRYPT
<script type="text/javascript">
    //var lioper = $lioper;
    var lzones = $lzones;
    var id_pack = $id_pack;
</script>
SCRYPT;

?>

</head>
<body >


    <DIV id="pmain_footer">
        <a href="javascript:void(0)" id="debug_ls1">show debug window</a> 
        <a href="javascript:void(0)" id="debug_ls2">hide debug window</a> 
        <a href="javascript:void(0)" id="debug_ls3">clear debug window</a>
    </DIV>

    <DIV id="pmain_center" style="padding:2px; margin:3px;">    
        <div id="pheader" style="padding:2px; margin:3px;">  
        <div class="pane" >    
        <p> <b> Показники лічильників  </b></p>    
        <p>  Відомість № <b> <?php echo "$num_pack" ?>; </b>від <b><?php echo "$dt_pack" ?>; </b></p>            
        <p>  Дільниця: <b> <?php echo "$sector" ?>;</b></p>            
        <p>  Кур'єр/контролер: <b> <?php echo "$runner" ?>; </b></p>    
        
        <p>            
            <label>Дата зняття показників
                <input name="dt_indic" type="text" size="12" value="" id="fdt_indic" class="dtpicker" data_old_value = "" />
            </label>
        </p>
        
        </div>    
        </div>     

        <div id="pIndic_table" style="padding:2px; margin:3px;">    
            <table id="indic_table" > </table>
            <div   id="indic_tablePager" ></div>
        </div>    

        <div id="pBottom" style="padding:2px; margin:3px;">    
                <button name="OkButton" type="button" class ="btn" id="bt_save" value="add" >Записати</button>                     
                <button name="CancelButton" type="button" class ="btn" id="bt_close" value="reset" >Закрити</button>         
        </div>    

    </div>        
    

      <div id="dialog-confirm" title="" style="display:none;">
	<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        <p id="dialog-text"> </p></p>
      </div>

    <div id="dialog-changedate" title="Дата редагування" style="display:none;">
	<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        <p id="dialog-text">Вкажіть дату редагування </p></p>
        <br>
        <input name="date_change" type="text" size="20" class="dtpicker" id ="fdate_change"/>
    </div>

<?php

print('<div id="message_zone" style ="padding: 5px;color: blue;" >  </div>');


end_mpage();
?>
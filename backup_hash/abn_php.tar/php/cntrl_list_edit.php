<?php
header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();

error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) { $ids=$_SESSION['id_sess'];  

	$res_par=sel_par($ids);
	$row_par=pg_fetch_array($res_par);
	$cons=$row_par['con_str1'];
	$Q=$row_par['qu'];
//	$id=$row_par['id']; 
//	$id_e1=$row_par['idreg'];
	$Link=pg_connect($cons);}

	$lnk_sys=log_s_pgsql("login");
	$lnk1=$lnk_sys['lnks'];
*/ 

try {

if (isset($_POST['oper'])) {
$oper=$_POST['oper'];

//------------------------------------------------------
if ($oper=="edit") {

$p_id_person_cntrl = sql_field_val('id_person_cntrl','int');
$p_fio_cntrl=sql_field_val('fio_cntrl','string');
$p_notes=sql_field_val('notes','string');

$p_id=sql_field_val('id','int');    

$QE="UPDATE cntrl_list
   SET id_person_cntrl=$p_id_person_cntrl, fio_cntrl=$p_fio_cntrl, notes=$p_notes
 WHERE id_cntrl = $p_id;";

 $res_e=pg_query($Link,$QE);
 if ($res_e) {echo_result(1,'Data updated'.$QE);}
 else        {echo_result(2,pg_last_error($Link));}
}
//------------------------------------------------------
if ($oper=="add") {

$p_id_person_cntrl = sql_field_val('id_person_cntrl','int');
$p_fio_cntrl=sql_field_val('fio_cntrl','string');
$p_notes=sql_field_val('notes','string');

$QE="INSERT INTO cntrl_list(
            id_person_cntrl,fio_cntrl,notes)
 values( $p_id_person_cntrl,$p_fio_cntrl,$p_notes );"; 

 $res_e=pg_query($Link,$QE);
 if ($res_e) {echo_result(1,'Data ins');}
 else        {echo_result(2,pg_last_error($Link));}

 }
//------------------------------------------------------
if ($oper=="del") {

 $p_id=sql_field_val('id','int');    
 $QE="Delete from cntrl_list where id_cntrl= $p_id;"; 

 $res_e=pg_query($Link,$QE);

 if ($res_e) {echo_result(1,'Data delated'.$QE);}
 else        {echo_result(2,pg_last_error($Link));}
}

}


}
catch (Exception $e) {

 echo echo_result(1,'Error: '.$e->getMessage());
}

?>
<?php

header('Content-type: text/html; charset=utf-8');

include_once 'Abon_en_func.php';
include_once 'abon_ded_func.php';


session_name("session_kaa");
session_start();

error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) {
  $ids = $_SESSION['id_sess'];

  $res_par = sel_par($ids);
  $row_par = pg_fetch_array($res_par);
  $cons = $row_par['con_str1'];
  $Q = $row_par['qu'];
//	$id=$row_par['id'];
//	$id_e1=$row_par['idreg'];
  $Link = pg_connect($cons);
}
*/
//$lnk_sys = log_s_pgsql("login");
//$lnk1 = $lnk_sys['lnks'];

//if (isset($_POST['id_dov'])) { $idtwn=$_POST['id_dov']; 
//	$QS="update dbusr_var set idtwn=".$idtwn." where id_sess=".$ids;
//	$res_qs=pg_query($lnk1,$QS);
//	echo $idtwn."+++".$QS;
//}
// connect to the database
//$rr=pg_query($Link,$Q);

$table_name = 'adi_class_tbl';

try {

  if (isset($_POST['oper'])) {
      
    $oper = $_POST['oper'];

    $p_id = sql_field_val('id', 'int');
    $p_id_parent = sql_field_val('id_parent', 'int');
    $p_name = sql_field_val('name', 'string');
    $p_name_full = sql_field_val('name_full', 'string');
    $p_ident = sql_field_val('ident', 'string');
    $p_idk_class = sql_field_val('idk_class', 'int');
    $p_indx = sql_field_val('indx', 'string');

//------------------------------------------------------
    if ($oper == "edit") {

      $QE = "UPDATE $table_name
        SET name=$p_name, id_parent = $p_id_parent, 
        name_full=$p_name_full,  ident = $p_ident, idk_class = $p_idk_class,
        indx = $p_indx
        WHERE id=$p_id;";

      $res_e = pg_query($Link, $QE);
      if ($res_e) {
        echo_result(1, 'Data updated');
      } else {
        echo_result(2, pg_last_error($Link));
      }
    }
//------------------------------------------------------
    if ($oper == "add") {

      $QE = "INSERT INTO $table_name (id, id_parent, name,name_full, ident, indx, idk_class)
      VALUES(DEFAULT, $p_id_parent, $p_name,$p_name_full, $p_ident, $p_indx, $p_idk_class) returning id";

      $res_e = pg_query($Link, $QE);
      if ($res_e)
      {    
        $row = pg_fetch_array($res_e);     
        echo_result(-1,'Data ins',$row['id']);
      }
      else
        echo_result(2, pg_last_error($Link).$QE);
    }
//------------------------------------------------------
    if ($oper == "del") {

      $QE = "DELETE FROM $table_name WHERE id= $p_id;";

      $res_e = pg_query($Link, $QE);

      if ($res_e)
        echo_result(-2, 'Data deleted');
      else
        echo_result(2, pg_last_error($Link));
    }
  }
} catch (Exception $e) {

  echo echo_result(1, 'Error: ' . $e->getMessage());
}
?>
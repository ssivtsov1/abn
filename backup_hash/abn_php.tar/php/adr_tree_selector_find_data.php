<?php
header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();

error_reporting(1);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) { 
    $ids=$_SESSION['id_sess'];  
    $res_par=sel_par($ids);
    $row_par=pg_fetch_array($res_par);
    $cons=$row_par['con_str1'];
//    $Q=$row_par['qu'];
    $Link=pg_connect($cons) or die("Connection Error: " .pg_last_error($Link) );
}
*/
$id_root = sql_field_val('id_root', 'int'); 
$cnt = sql_field_val('cnt', 'int'); 
$pattern = sql_field_val('pattern', 'string'); 

$SQL = "select find_addr_fun($pattern,$cnt,$id_root) as find_path; ";

$result = pg_query($Link,$SQL) or die("SQL Error: " .pg_last_error($Link) );

$row = pg_fetch_array($result);

$data = $row['find_path'];

//header("Content-type: application/json;charset=utf-8");
echo $data;

?>

<?php

header('Content-type: text/html; charset=utf-8');

require_once 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();
//error_reporting(0);
$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) {
  $ids = $_SESSION['id_sess'];
  $res_s = sel_par($ids);
  $row_s = pg_fetch_array($res_s);
  $page1 = $row_s['pg'];
  $rnum1 = $row_s['rn'];
  $id11 = $row_s['id1'];
  $cons = $row_s['con_str1'];
  $Link = pg_connect($cons);
  $Qm_pp = $row_s['qm_paccnt'];
}


$lnk_sys = log_s_pgsql("login");
$lnk1 = $lnk_sys['lnks'];

$nacc = 0;
$QS = "update dbusr_var set nacc=" . $nacc . " where id_sess=" . $ids;
$res_qs = pg_query($lnk1, $QS);
//$QS_1 = "update s_var set Qm_pcalc='',work_p=null,avance='f' where id_sess=" . $ids;
$QS_1 = "update s_var set Qm_pcalc='',work_p=null where id_sess=" . $ids;

$res_qs_1 = pg_query($lnk1, $QS_1);
*/
$nam = "Абон-енерго (Абоненти)";

//$cp1 = iconv("windows-1251", "utf-8", "Абоненти");
$cp1 = "Абоненти";
$gn1 = "m_grid";
$fn1 = "mgrid";

start_mpage($nam);
head_addrpage();

print('<link rel="stylesheet" type="text/css" href="css/ded_styles.css" /> ');
print('<link rel="stylesheet" type="text/css" href="css/layout-default-latest.css" /> ');
    
print('<script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.form.js"></script>');
print('<script type="text/javascript" src="js/jquery.validate.min.js" ></script>');
print('<script type="text/javascript" src="js/jquery.ui.datepicker-uk.js"></script> ');
print('<script type="text/javascript" src="js/jquery.maskedinput-1.3.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.layout.min-latest.js"></SCRIPT>');
print('<script type="text/javascript" src="Abon_en_main.js"></script> ');
?>
<style type="text/css"> 
#pActionBar { position:relative; height:28px; border-width:1px; width:"100%"; padding:4px; margin: 1px;}    
#pmain_content {padding:3px}
#pwork_grid {padding:3px}

.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {  color: #111111; }

</style>   


</head>
<body >


<DIV id="pmain_header"> 
    
    <?php main_menu(); ?>

</DIV>
    
<DIV id="pmain_footer">
    
   <a href="javascript:void(0)" id="debug_ls1">show debug window</a> 
   <a href="javascript:void(0)" id="debug_ls2">hide debug window</a> 
   <a href="javascript:void(0)" id="debug_ls3">clear debug window</a>

</DIV>

<DIV id="pmain_content">
    
    <DIV id="pwork_header">
    
      <DIV style="display:none;">
       <form id="fpaccnt_params" name="paccnt_params" method="post" action="Abon_en_paccnt.php">
         <input type="text" name="mode" id="pmode" value="1" />
         <input type="text" name="id_paccnt" id="pid_paccnt" value="0" />         
         <input type="text" name="paccnt_info" id="ppaccnt_info" value="" />         
       </form>
      </DIV>
    
    </DIV>

    <DIV id="pwork_grid">
    
        <div class="ui-corner-all ui-state-default" id="pActionBar">
            <button type="button" class ="btn" id="bt_add">Новий</button>		    
            <button type="button" class ="btn" id="bt_edit">Редагувати</button>		
            <button type="button" class ="btn" id="bt_saldo">Сальдо</button>		                        
            <button type="button" class ="btn" id="bt_bills">Рахунки</button>		                        
            <button type="button" class ="btn" id="bt_abons">Довівдник фіз. осіб</button>		
        </div>
    
       <div id="pclient_list" > 
            <table id="client_table" style="margin:1px;"></table>
            <div id="client_tablePager"></div>
       </div>

        
    </DIV>

    
</DIV>

<div id="message_zone" style ="padding: 5px;color: blue;" >  </div>


<?php


//// print("SQL - ".$S1);

end_mpage();
?>



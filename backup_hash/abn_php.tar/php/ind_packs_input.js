var cur_indic_id=0;
var validator = null;

var selICol=0; //iCol of selected cell
var selIRow=0; //iRow of selected cell

jQuery(function(){ 
/*
   setTimeout(function(){
             jQuery('#accnt_table').trigger('reloadGrid');              
    },300);  
*/
  $.datepicker.setDefaults( $.datepicker.regional[ "uk" ] );
  jQuery(".dtpicker").datepicker({showOn: "button", buttonImage: "images/calendar.gif",
			buttonImageOnly: true});

  jQuery(".dtpicker").datepicker( "option", "dateFormat", "dd.mm.yy" );
  jQuery(".dtpicker").mask("99.99.9999");

//==============================================================================

  jQuery('#indic_table').jqGrid({
    url:'ind_packs_indic_data.php',
    datatype: 'json',
    mtype: 'POST',
    height:200,
    width:400,
    colNames:[],
    colModel:[
    {name:'id', index:'id', width:40, editable: false, align:'center', key:true ,hidden:true,sortable:false},
    {name:'id_pack', index:'id_pack', width:40, editable: false, align:'center',hidden:true,sortable:false},
    {name:'id_accnt', index:'id_accnt', width:40, editable: false, align:'center',hidden:true,sortable:false},    
    {name:'id_meter', index:'id_meter', width:40, editable: false, align:'center',hidden:true,sortable:false},    
    {name:'id_type_meter', index:'id_type_meter', width:40, editable: false, align:'center',hidden:true,sortable:false},    
    {name:'id_p_indic', index:'id_p_indic', width:40, editable: false, align:'center',hidden:true,sortable:false},    
    
    
    {label:'Книга',name:'book', index:'book', width:40, editable: false, align:'left',edittype:'text',sortable:false},            
    {label:'Рахунок',name:'code', index:'code', width:40, editable: false, align:'left',edittype:'text',sortable:false},                
    {label:'Адреса',name:'address', index:'address', width:100, editable: false, align:'left',edittype:'text',sortable:false,hidden:true},                    
    {label:'Абонент',name:'abon', index:'abon', width:100, editable: false, align:'left',edittype:'text',sortable:false,hidden:true},                        
    {label:'№ ліч.',name:'num_meter', index:'num_meter', width:80, editable: false, align:'left',edittype:'text',sortable:false},            
    {label:'Тип ліч.',name:'type_meter', index:'type_meter', width:80, editable: false, align:'left',edittype:'text',sortable:false,hidden:true},                
    {label:'Розр. ліч.',name:'carry', index:'carry', width:40, editable: false, align:'left',edittype:'text',sortable:false},                    
    {label:'К.тр',name:'k_tr', index:'k_tr', width:40, editable: false, align:'left',edittype:'text',sortable:false},                        
    {label:'Зона',name:'id_zone', index:'id_zone', width:60, editable: false, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lzones},stype:'text',sortable:false},                       
 
    {label:'Попер.пок.',name:'p_indic', index:'p_indic', width:80, editable: false, align:'right',hidden:false,
                            edittype:'text',sortable:false},           

    {label:'Дата попер.',name:'dt_p_indic', index:'dt_p_indic', width:80, editable: false, 
                        align:'left',edittype:'text',formatter:'date',sortable:false,hidden:true},

    {label:'Поточні пок.',name:'indic', index:'indic', width:80, editable: true, align:'right',hidden:false,
            edittype:'text',
            sortable:false,
            classes: 'editable_column_class',
            editrules:{
                number:true
            },
            editoptions: {
                dataInit : function (elem) {
                    $(elem).focus(function(){
                        this.select();
                    })
                },
                dataEvents: [
                { 
                    type: 'keydown', 
                    fn: function(e) { 
                        var key = e.charCode || e.keyCode;
                        if (key == 13)//enter
                        {
                            setTimeout("jQuery('#indic_table').editCell(" + selIRow + " + 1, " + selICol + ", true);", 100);
                        }
                    }
                } 
                ]
            }                            
                        },
    {label:'Дата',name:'dt_indic', index:'dt_indic', width:80, editable: true, 
                        align:'left',edittype:'text',formatter:'date',sortable:false,classes: 'editable_column_class',
            editoptions: {
                dataInit : function (elem) {
                    $(elem).focus(function(){
                        this.select();
                    })
                },
                dataEvents: [
                { 
                    type: 'keydown', 
                    fn: function(e) { 
                        var key = e.charCode || e.keyCode;
                        if(key == 9)   // tab
                        {
                            setTimeout("jQuery('#indic_table').editCell(" + selIRow + " + 1, 17, true);", 100);
                        }
                        else if (key == 13)//enter
                        {
                            setTimeout("jQuery('#indic_table').editCell(" + selIRow + " + 1, " + selICol + ", true);", 100);
                        }
                    }
                } 
                ]
            }                        
                    },

    {label:'Споживання',name:'demand', index:'demand', width:80, editable: false, align:'right',hidden:false,
                            edittype:'text',sortable:false},           

    {name:'work_period', index:'work_period', width:80, editable: false, align:'left',edittype:'text', hidden:true,sortable:false},
    {name:'dt_input', index:'dt_input', width:100, editable: false, align:'left', formatter:'date', hidden:true,
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i',sortable:false}},
    {name:'user_name', index:'user_name', width:100, editable: false, align:'left',edittype:'text', hidden:true,sortable:false},        

    ],
    pager: '#indic_tablePager',
    autowidth: true,
    //shrinkToFit : false,
    rowNum:500,
    //rowList:[50,100,200],
    sortname: 'id',
    sortorder: 'asc',
    viewrecords: true,
    //gridview: true,
    caption: 'Показники',
    //hiddengrid: false,
    forceFit : true,
    hidegrid: false,    
    postData:{'p_id':id_pack},
    cellEdit: true, 
    cellsubmit: 'clientArray',
    pgbuttons: false,     // disable page control like next, back button
    pgtext: null,         // disable pager text like 'Page 0 of 10'
    
    
    gridComplete:function(){
/*
     if ($(this).getDataIDs().length > 0) 
     {      
       var first_id = parseInt($(this).getDataIDs()[0]);
       $(this).setSelection(first_id, true);
     }
     */
    },
    onSelectRow: function(id) { 
          cur_indic_id = id;
    },
    
    beforeEditCell : function(rowid, cellname, value, iRow, iCol)
    {
        selICol = iCol;
        selIRow = iRow;
    },    
    
    afterEditCell: function (id,name,val,iRow,iCol)
    { 
        if(name=='dt_indic') 
        {
            jQuery("#"+iRow+"_dt_indic","#indic_table").mask("99.99.9999"); 
        }
    },    
     afterSaveCell : function(rowid,name,val,iRow,iCol) {
            if(name == 'indic') {
                var global_dt = jQuery("#fdt_indic").val();
                var p_ind = jQuery("#indic_table").jqGrid('getCell',rowid,iCol-2);
                var k_tr = jQuery("#indic_table").jqGrid('getCell',rowid,iCol-4);
                var dt_ind = jQuery("#indic_table").jqGrid('getCell',rowid,iCol+1);
                var ind = val;
                var length = dt_ind.length;
                if (length<6)
                    {
                      jQuery("#indic_table").jqGrid('setRowData',rowid,{ dt_indic: global_dt});
                    };
                var dem = (ind - p_ind)* k_tr;       
                jQuery("#indic_table").jqGrid('setRowData',rowid,{ demand: dem});    
                    
             };
             
            jQuery('#indic_table').setCell(rowid,name,'','mod_column_class');
            jQuery('#indic_table').setCell(rowid,'dt_indic','','mod_column_class');
            jQuery('#indic_table').setCell(rowid,'demand','','mod_column_class');
        },    
    
    
    //ondblClickRow: function(id){ 
    //     jQuery(this).editGridRow(id,LgtNormEditOptions);  
    //} ,  

    loadError : function(xhr,st,err) {
      jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText);
    }
  
  //  jsonReader : { repeatitems: false }

  }).navGrid('#accnt_tablePager',
         {edit:false,add:false,del:false},
        {}, 
        {}, 
        {}, 
        {} 
        ).jqGrid('bindKeys'); 

//==============================================================================

//jQuery("#headers_table").jqGrid('bindKeys', {"onEnter":function( id ) { 
//      jQuery(this).editGridRow(id,{width:300,height:300,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});}} );


//jQuery("#indic_table").jqGrid('bindKeys');



$("#message_zone").dialog({autoOpen: false});

$("#debug_ls1").click( function() {jQuery("#message_zone").dialog('open');});
$("#debug_ls2").click( function() {jQuery("#message_zone").dialog('close');});
$("#debug_ls3").click( function() {jQuery("#message_zone").html('');});

jQuery(".btn").button();
jQuery(".btnSel").button({icons: {primary:'ui-icon-folder-open'}});

jQuery("#pheader :input").addClass("ui-widget-content ui-corner-all");


//------------------------------------------------------------------------------
$.ajaxSetup({type: "POST",      dataType: "json"});
 outerLayout = $("body").layout({
		name:	"outer" 
	//,	north__paneSelector:	"#pmain_header"
	//,	north__closable:	false
	//,	north__resizable:	false
        //,	north__size:		40
	//,	north__spacing_open:	0
	,	south__paneSelector:	"#pmain_footer"
	,	south__closable:	false
	,	south__resizable:	false
        ,	south__size:		40
	,	south__spacing_open:	0
	,	center__paneSelector:	"#pmain_center"
	,	resizeWhileDragging:	true
	,	autoBindCustomButtons:	true

	});

 innerLayout = $("#pmain_center").layout({
		name:	"inner" 
	,	north__paneSelector:	"#pheader"
	,	north__closable:	false
	,	north__resizable:	false
        ,	north__spacing_open:	0
        ,	north__size:		120
	,	south__paneSelector:	"#pBottom"
	,	south__closable:	false
	,	south__resizable:	false
        ,	south__size:		35
        ,	south__spacing_open:	0
        ,	center__paneSelector:	"#pIndic_table"
	,	resizeWhileDragging:	true
	,	autoBindCustomButtons:	true
	,       north__onresize:	function (pane, _pane, state, options) 
        {
            //jQuery("#headers_table").jqGrid('setGridWidth',_pane.innerWidth()-10);
            //jQuery("#headers_table").jqGrid('setGridHeight',_pane.innerHeight()-85);
        }
	,       center__onresize:	function (pane, _pane, state, options) 
        {
            jQuery("#indic_table").jqGrid('setGridWidth',_pane.innerWidth()-10);
            jQuery("#indic_table").jqGrid('setGridHeight',_pane.innerHeight()-85);
        }

	});

        outerLayout.resizeAll();
        
        
$("#bt_close").click( function() 
{
  self.close();    
});
//----------------------------------------------------------------
jQuery("#bt_save").click( function() { 

    //var gridData=$("#indic_table").jqGrid('getGridParam','data');
    if ((selICol!=0)&&(selIRow!=0))
    {
       jQuery('#indic_table').editCell(selIRow,selICol, false); 
    }
    
    
    var data_obj = $('#indic_table').getChangedCells('all');
    var json_str = JSON.stringify(data_obj);
    //alert(json);
    $.ajaxSetup({type: "POST",   dataType: "json"});
    
    var request = $.ajax({
            url: "ind_packs_input_edit.php",
            type: "POST",
            data: {
                id_pack : id_pack,
                json_data : json_str  
            },
            dataType: "json"
        });

        request.done(function(data ) {
            if (data.errcode!==undefined)
                {
                    $('#message_zone').append(data.errstr);  
                    $('#message_zone').append("<br>");                 
                }
            $(".mod_column_class").removeClass("mod_column_class");
            
             window.opener.RefreshIndicExternal(id_pack);
               //window.opener.focus();
               //self.close();            


        });
        request.fail(function(data ) {
            if (data.errcode!==undefined)
                {
                    $('#message_zone').append(data.errstr);  
                    $('#message_zone').append("<br>");                 
                }
                else
                    $('#message_zone').append(data);  
            
        });

   });

jQuery("#bt_reset").click( function() { 
    jQuery('#indic_table').trigger('reloadGrid');              
    $(".mod_column_class").removeClass("mod_column_class");
   });

}); 


 

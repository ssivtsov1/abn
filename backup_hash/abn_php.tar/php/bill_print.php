<?php

header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';

function BillIndicStr($text, $ind1, $ind2, $demand, $tarif, $sum) {

    return <<<BILL_INDICSTR
      <tr>
        <td><div align="right"><span class="snorm"> $ind1 </span></div></td>
        <td><div align="right"><span class="snorm"> $ind2 </span></div></td>
        <td><div align="right"><span class="snorm"> $demand </span></div></td>
        <td><div align="right"><span class="snorm"> $tarif </span></div></td>
        <td><span class="snorm"> (+)</span></td>
        <td><div align="right"><span class="snorm"> $sum </span></div></td>
      </tr>    
BILL_INDICSTR;
}

function BillDemandStr($text, $caption, $demand, $tarif, $sum) {

    if ($sum <0)
    {
        $ssum=-$sum;
        $sign = '(-)';
    }
    else 
    {
        $ssum=$sum;
        $sign = '(+)';
    }
    return <<<BILL_DEMCSTR
      <tr>
        <td colspan="3"><span class="snorm"> $caption </span></td>
        <td><div align="right"><span class="snorm"> $demand </span></div></td>
        <td><div align="right"><span class="snorm"> $tarif </span></div></td>
        <td><span class="snorm"> $sign </span></td>
        <td><div align="right"><span class="snorm"> $ssum </span></div></td>
      </tr>

BILL_DEMCSTR;
    
}

function BillSumStr($text, $caption, $sum) {

    if ($sum <0)
    {
        $ssum=-$sum;
        $sign = '(-)';
    }
    else 
    {
        $ssum=$sum;
        $sign = '(+)';
    }
    
    return <<<BILL_SUMSTR
      <tr>
        <td colspan="5"><span class="snorm"> $caption </span></td>
        <td><span class="snorm"> $sign </span></td>
        <td><div align="right"><span class="snorm"> $ssum </span></div></td>
      </tr>

BILL_SUMSTR;
    
}

function BillIndicStrRight($text, $ind1, $ind2, $demand) {

    return <<<BILL_INDICSTRR
      <tr>
        <td>&nbsp;</td>
        <td><div align="right"><span class="snorm"> $ind1 </span></div></td>
        <td><div align="right"><span class="snorm"> $ind2 </span></div></td>
        <td><div align="right"><span class="snorm"> $demand </span></div></td>
      </tr>

BILL_INDICSTRR;
}

session_name("session_kaa");
session_start();
error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) {
  $ids = $_SESSION['id_sess'];

  $res_par = sel_par($ids);
  $row_par = pg_fetch_array($res_par);
  $cons = $row_par['con_str1'];
  $Q = $row_par['qu'];
  $Link = pg_connect($cons);
}
*/
//$lnk_sys = log_s_pgsql("login");
//$lnk1 = $lnk_sys['lnks'];

//$rr = pg_query($Link, $Q);
/*
$idgrt = 0;
$idtar = 0;
$idgrpl = 0;
$idbperc = 0;

$QS = "update dbusr_var set idgrt=" . $idgrt . ",idtar=" . $idtar . ",idgrpl=" . $idgrpl .
        ",idbperc=" . $idbperc . " where id_sess=" . $ids;
$res_qs = pg_query($lnk1, $QS);
*/

$nmp1 = "Абон-енерго (Друк рахунків)";
  
start_mpage($nmp1); //заголовок
head_addrpage();  // хедер, подключение библиотек

$book='';
$mmgg='';
$list_mode=0;

 if ((isset($_POST['bill_list']))&& ($_POST['bill_list']!=''))
 {
    $json_str = $_POST['bill_list'];
    $json_str = stripslashes($json_str); 
    $bill_id_list = json_decode($json_str,true);
    
    $where = " where b.id_doc in ( ";
    
    $i = 0;
    foreach($bill_id_list as $id_bill) {
    
        if ($i>0) $where.=",";
        
        $where.="$id_bill";
        $i++;
    }
    $where.=") ";
    $list_mode = 1;
 }
 else
 {
  $book = sql_field_val('book','int');
  $mmgg = sql_field_val('mmgg','data');
  
  $where = " where book =  $id_book and mmgg = $mmgg ";
 }
      
print('<link rel="stylesheet" type="text/css" href="css/ded_styles.css" /> ');
//print('<link rel="stylesheet" type="text/css" href="css/layout-default-latest.css" /> ');
//print('<script type="text/javascript" src="js/jquery.layout.min-latest.js"></SCRIPT>');
//print('<script type="text/javascript" src="js/jquery.form.js"></script>');
//print('<script type="text/javascript" src="js/jquery.validate.min.js" ></script>');
//print('<script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script> ');
//print('<script type="text/javascript" src="js/jquery.ui.datepicker-uk.js"></script> ');
//print('<script type="text/javascript" src="js/jquery.maskedinput-1.3.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery-barcode-2.0.2.min.js"></script>');

?>

<style type="text/css">
body {background-color: white}

.sbold {font-size: 9pt; font-weight: bold; font-style: italic; margin: 0; padding: 0px; font-family: "Courier New", Courier, monospace; line-height: 10px; }
.sboldm {font-size: 9pt; font-weight: bold; font-style: italic; margin: 0; padding: 0px; font-family: "Courier New", Courier, monospace; line-height: 20px; }
.snorm {font-style: italic; margin: 0; padding: 0px; font-size: 9pt; font-family: "Courier New", Courier, monospace; line-height: 10px; }
.snorm_p {font-style: italic; margin: 0; padding: 0px; font-size: 8pt; font-family: "Courier New", Courier, monospace; line-height: 8px; }

/*.smod1 {font-style: italic; margin:5px; padding: 0px; font-size: 9pt; font-family: "Courier New", Courier, monospace; 	line-height: 10px;}*/
.smod1 {font-style: italic; margin:5px; padding: 0px; font-size: 9pt; font-family: "Times New Roman", Times, serif; line-height: 9px;}
.smod2 {font-style: italic; margin:0, 5px; padding: 0px; font-size: 10pt; font-family: "Courier New", Courier, monospace; line-height: 10px;}

.ssmall {padding: 0px; font-family: "Times New Roman", Times, serif; line-height: 8px; font-size: 9px; margin: 0;}
.sboldp {font-size: 9pt; font-weight: bold; font-style: italic; margin: 0; padding: 3px; font-family: "Courier New", Courier, monospace; line-height: 10px; }

table.bill_left_table { border-collapse:collapse; }
table.bill_left_table td, table.bill_left_table th { border:1px solid black; }

table.bill_left_total { border-collapse:collapse; }
table.bill_left_total td, table.bill_left_total th { border:1px solid black; }

@page {margin-left:0.5cm; margin-right:0.5cm;}

</style>

<script type="text/javascript">

        var settings = {
          output:"css",
          bgColor: "#FFFFFF",
          color: "#000000",
          barWidth: 1,
          barHeight: 20,
          moduleSize: 5,
          posX: 0,
          posY: 0,
          addQuietZone: 1
        };

        var btype = "code128";
        
        jQuery(function(){ 
            
            $('.barcode_area').each(function() {
                  $(this).html("").show().barcode($(this).attr('data_value'), btype, settings);
            });

        });

        

</script>

</head>
<body >
    
<?php
 
$SQL = " select r.*, address_print_full(r.addr,4) as addr_full,
 b.name as ae_bank_name 
    from syi_resinfo_tbl as r
    left join bank as b on (b.mfo = r.ae_mfo)
    where r.id_department = syi_resid_fun() ;"; 

$result = pg_query($Link,$SQL) or die("SQL Error: " .pg_last_error($Link) );
$res_info = pg_fetch_array($result);
 
$res_name       =$res_info['name']; 
$res_short_name =$res_info['short_name']; 

$res_okpo_num =$res_info['okpo_num']; 
$res_bank_acc =$res_info['ae_account']; 
$res_bank =$res_info['ae_bank_name']; 
$res_bank_mfo =$res_info['ae_mfo']; 
$res_phones =$res_info['phone_bill']; 
$ikc_phones =$res_info['phone_ikc']; 
$ikc_addr =$res_info['addr_ikc']; 


 
$SQL = " select b.*, acc.book, acc.code, adr.adr as street, address_print(acc.addr) as adr,
date_part('year', b.mmgg_bill) as bill_year , 
date_part('month', b.mmgg_bill) as bill_month, 
date_part('month', b.mmgg_bill+'1 month'::interval) as next_month, 
date_part('year', b.mmgg_bill+'1 month'::interval) as next_year,
date_part('day', b.mmgg_bill+'1 month'::interval-'1 day'::interval) as last_day 
from acm_bill_tbl as b 
join clm_paccnt_tbl as acc on (acc.id = b.id_paccnt)
join clm_abon_tbl as c on (c.id = acc.id_abon) 
left join adv_addr_tbl as adr on (adr.id = (acc.addr).id_class)
 $where
 order by acc.code ;"; 


$result = pg_query($Link,$SQL) or die("SQL Error: " .pg_last_error($Link) );
$nn = 0;  
$prn_nn = 0;
$prn_max = 3;
$table_text= "";

//echo $SQL;

if ($result) 
{
 while($row = pg_fetch_array($result)) 
  {
    $nn++;

    $id_doc          =$row['id_doc']; 
    $id_paccnt       =$row['id_paccnt']; 
    $adr             =$row['adr']; 
    $street          =$row['street'];     
    $code            =$row['code']; 
    $book            =$row['book']; 
    
    $reg_num         =$row['reg_num']; 
    $reg_date        =$row['reg_date']; 
    $value           =number_format($row['value'],2,'.', ''); 
    $value_tax       =number_format($row['value_tax'],2,'.', ''); 
    
    $bill_year       =$row['bill_year']; 
    $bill_month      =$row['bill_month']; 
    $last_day        =$row['last_day']; 
    
    $bill_month_i = ukr_month($bill_month,2);
    $bill_month_a = ukr_month($bill_month,1);
    
    $next_year       =$row['next_year']; 
    $next_month      =$row['next_month']; 
    $next_month_s = ukr_month($next_month,0);
    
    $indic_str_count = 3;
    
    $table_text.= <<<BILL_HDR_LEFT

<div class="bill_class">
  <div class="bill_left_part" style="float:left; width:12.5cm"> 
    <span class="sbold"> $res_name </span> <br/>
    <span class="sbold">Рахунок № $reg_num від $reg_date року ЗА ЕЛЕКТРОЕНЕРГІЮ</span> <br/>
    <span class="snorm">Особ рах. $book/$code, Адреса : $street $adr </span> <br/>
        
    <table class="bill_left_table" width="457" border="1" cellspacing="0" cellpadding="2">
      <tr>
        <td colspan="5"><span class="snorm">Залишок до сплати на початок $bill_month_a $bill_year р. </span></td>
        <td width="21"><span class="snorm">-</span></td>
        <td width="44"><span class="snorm">-</span></td>
      </tr>
      <tr>
        <td width="96" rowspan="$indic_str_count" valign="top"><span class="snorm">&nbsp;Нараховано&nbsp;</span></td>
        <td colspan="2"><span class="snorm">Показання лічильника </span></td>
        <td width="49"><span class="snorm">Спожито</span></td>
        <td width="63"><span class="snorm">Вартість</span></td>
        <td colspan="2"><div align="center"><span class="snorm">Сума </span></div></td>
      </tr>
      <tr>
        <td width="66"><div align="center"><span class="snorm"> останні </span></div></td>
        <td width="88"><div align="center"><span class="snorm">попередні </span></div></td>
        <td><div align="center"><span class="snorm">квтг</span></div></td>
        <td><span class="snorm">коп/кВтг </span></td>
        <td colspan="2"><div align="center" class="snorm">грн.</div></td>
      </tr>

BILL_HDR_LEFT;


    $table_text.=BillIndicStr($table_text, 1234, 1245, 11, 28.02, 3.08 );

    $table_text.=BillDemandStr($table_text, 'Компенсація пільги 25%' , 75,  7.005, -5.25 );
    $table_text.=BillsumStr($table_text, "Сплачено в $bill_month_i $bill_year р. з 1 по $last_day" , 36.50 );
    $table_text.=BillDemandStr($table_text, "Плановий платіж за $next_month_s $next_year р." , 149, 28.02 ,41.75  );
    
    $table_text.= <<<BILL_FOOTER_LEFT

         <tr>
        <td colspan="3" rowspan="2"><span class="sbold"> Підлягає оплаті в 10-денний термін <br>
          з дня отримання. Зберігати 3 роки </span>
        </td>
        <td colspan="2"><div align="right"><span class="sbold">Всього до оплати </span></div></td>
        <td colspan="2"><div align="right"><span class="sbold">$value</span></div></td>
      </tr>
      <tr>
        <td colspan="2"><div align="right"><span class="snorm">втч ПДВ - 20 %</span></div></td>
        <td colspan="2"><div align="right"><span class="snorm">$value_tax</span></div></td>
      </tr>
    </table>
    <p class="sbold">Телефони по розрахунках $res_phones</p>
    <p class="ssmall">Інформаційно-консультаційний центр (ІКЦ) надає роз'яснення з питань, пов'язаних з електропостачанням</p>
    <p class="sbold">Адреса ІКЦ $ikc_addr</p>
    <p class="sbold">Телефони ІКЦ $ikc_phones</p>
    <p class="ssmall">Відповідно до п.22 ПКЕЕН, оплата спожитої електроенергії може здійснюватися за розрахунковими <br>
      книжками або за платіжними документами, виписаними енергопостачальником</p>
  </div>

BILL_FOOTER_LEFT;
    

    
    
    $table_text.= <<<BILL_HEADER_RIGHT

  <div style="float:left ; width:6.5cm">
    <p align="center" class="sbold">Повідомлення № 289/22_10-12 </p>
    <p align="center" class="sbold">ПАТ &quot;ЧЕРНІГІВОБЛЕНЕРГО&quot; </p>
    <p align="center" class="snorm">$res_short_name</p>
    <p align="center" class="snorm_p">код $res_okpo_num р/р $res_bank_acc</p>
    <p align="center" class="snorm_p">$res_bank ,МФО $res_bank_mfo</p>
    
    <p class="sboldm">Особ рах. $book/$code </p>
    
    <p class="sbold"> ПІБ_________________________________</p>
    <p class="smod1">(ПІБ споживача заповнюється самостійно в обовьязковому порядку)</p>
    
    <p class="smod2">$street $adr</p>
    <table width="252" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="77"><span class="snorm">Лічильник: </span></td>
        <td width="53"><div align="right"><span class="snorm">Поточні</span></div></td>
        <td width="63"><div align="right"><span class="snorm">Попередні</span></div></td>
        <td width="63"><div align="right"><span class="snorm">Різниця</span></div></td>
      </tr>


BILL_HEADER_RIGHT;

$table_text.=BillIndicStrRight($table_text, 1234, 1245, 11);    
    
    $table_text.= <<<BILL_FOOTER_RIGHT

    </table>
    <p class="ssmall">&nbsp;</p>
    <table width="93%" border="1" cellspacing="0" cellpadding="0" class="bill_left_total">
      <tr>
        <td width="64%" ><div align="left" class="sboldp">ВСЬОГО ДО ОПЛАТИ </div></td>
        <td width="36%" ><div align="right" class="sboldp">$value</div></td>
      </tr>
    </table>
    <p class="snorm">&nbsp; </p>
    <div align="center" class="barcode_area" data_value = "$id_doc;$id_paccnt;$bill_month.$bill_year;$value"> </div>
   </div>
  <div style="clear:both;" >
    <HR ALIGN="CENTER" SIZE="1" WIDTH="100%" NOSHADE>
  </div>
</div>

BILL_FOOTER_RIGHT;

    $prn_nn=$prn_nn+1;
    if ($prn_nn>=$prn_max)
    {
        $table_text.= '<br style="page-break-after: always">';

        $prn_nn = 0;
    
    }
    
  }
}
echo $table_text;
 

end_mpage();
?>
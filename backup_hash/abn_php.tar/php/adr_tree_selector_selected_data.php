<?php
header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();

error_reporting(1);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) { 
    $ids=$_SESSION['id_sess'];  
    $res_par=sel_par($ids);
    $row_par=pg_fetch_array($res_par);
    $cons=$row_par['con_str1'];
//    $Q=$row_par['qu'];
    $Link=pg_connect($cons) or die("Connection Error: " .pg_last_error($Link) );
}
*/
$id_class = $_POST['id_class']; 


$SQL = "select fulladr from adv_fulladdr_tbl where id = $id_class ";


$result = pg_query($Link,$SQL) or die("SQL Error: " .pg_last_error($Link) );

$row = pg_fetch_array($result);

$data = $row['fulladr'];

//header("Content-type: application/json;charset=utf-8");
echo $data;

?>

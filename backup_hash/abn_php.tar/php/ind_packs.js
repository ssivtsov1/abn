var cur_doc_id=0;
var cur_indic_id=0;
var validator = null;

jQuery(function(){ 
/*
   setTimeout(function(){
             jQuery('#accnt_table').trigger('reloadGrid');              
    },300);  
*/
  $.datepicker.setDefaults( $.datepicker.regional[ "uk" ] );
  jQuery(".dtpicker").datepicker({showOn: "button", buttonImage: "images/calendar.gif",
			buttonImageOnly: true});

  jQuery(".dtpicker").datepicker( "option", "dateFormat", "dd.mm.yy" );
  jQuery(".dtpicker").mask("99.99.9999");

  //----------------------------------------------------------------------------  
  jQuery('#headers_table').jqGrid({
    url:     'ind_packs_data.php',
    editurl: '',
    datatype: 'json',
    mtype: 'POST',
    height:200,
    width:800,
    colNames:[],
    colModel :[ 
      {name:'id', index:'id', width:40, editable: false, align:'center', key:true, hidden:false},
      {label:'Дата',name:'dt_pack', index:'dt_pack', width:80, editable: true, 
                        align:'left',edittype:'text',formatter:'date', editrules:{required:true}},
      {label:'Номер',name:'num_pack', index:'num_pack', width:80, editable: true, align:'left',edittype:"text"},
      
      {label:'id_sector',name:'id_sector', index:'id_sector', width:40, editable: true, align:'right', hidden:true},                             
      {label:'Дільниця',name:'sector', index:'sector', width:150, editable: true, align:'left',edittype:"text"},

      {label:'id_runner',name:'id_runner', index:'id_kategor', width:40, editable: true, align:'right', hidden:true},                             
      {label:"Кур'єр / контролер",name:'runner', index:'runner', width:120, editable: true, align:'left'},                       

      {label:'Операція',name:'id_ioper', index:'id_ioper', width:120, editable: true, align:'left',
                            edittype:'select',formatter:'select',editoptions:{value:lioper},stype:'text'},                       

      {name:'work_period', index:'work_period', width:80, editable: true, align:'left',edittype:'text', hidden:true},
      {name:'dt_input', index:'dt_input', width:100, editable: true, align:'left', formatter:'date', hidden:true,
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i'}},
      {name:'user_name', index:'user_name', width:100, editable: true, align:'left',edittype:'text', hidden:true},        
        
                            
    ],
    pager: '#headers_tablePager',
    autowidth: true,
    rowNum:100,
    rowList:[20,50,100,300,500],
    sortname: 'dt_pack',
    sortorder: 'desc',
    viewrecords: true,
    gridview: true,
    caption: 'Відомості',
    //hiddengrid: false,
    hidegrid: false,    
    
    gridComplete:function(){

    if ($(this).getDataIDs().length > 0) 
    {      
     var first_id = parseInt($(this).getDataIDs()[0]);
     $(this).setSelection(first_id, true);
    }
    else
    {
         jQuery('#indic_table').jqGrid('setGridParam',{'postData':{'p_id':0}}).trigger('reloadGrid');                
    }
    
  },
    
    onSelectRow: function(id) { 
          cur_doc_id = id;
          jQuery('#indic_table').jqGrid('setGridParam',{'postData':{'p_id':cur_doc_id}}).trigger('reloadGrid');        
      
    },
    
    ondblClickRow: function(id){ 
        gsr = jQuery(this).jqGrid('getGridParam','selrow'); 
        if(gsr)
        { 
            
            // jQuery(this).editGridRow(id,{width:500,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});  
            validator.resetForm();  //для сброса состояния валидатора
            $("#fHeaderEdit").resetForm();
            $("#fHeaderEdit").clearForm();
          
            $("#headers_table").jqGrid('GridToForm',gsr,"#fHeaderEdit"); 
            $("#fHeaderEdit").find("#foper").attr('value','edit');              
            cur_doc_id = id;

            $("#fHeaderEdit").find("#bt_add").hide();
            $("#fHeaderEdit").find("#bt_edit").show();   
            $("#dialog_editform").dialog('open');          
        
        }

     } ,  

  loadError : function(xhr,st,err) {jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText);}

  }).navGrid('#headers_tablePager',
        {edit:false,add:false,del:false},
        {}, 
        {}, 
        {}, 
        {} 
        ); 


//==============================================================================

  jQuery('#indic_table').jqGrid({
    url:'ind_packs_indic_data.php',
    editurl: 'ind_pack_indic_edit.php',
    datatype: 'json',
    mtype: 'POST',
    height:200,
    width:400,
    colNames:[],
    colModel:[
    {name:'id', index:'id', width:40, editable: false, align:'center', key:true ,hidden:true},
    {name:'id_pack', index:'id_pack', width:40, editable: false, align:'center',hidden:true},
    {name:'id_accnt', index:'id_accnt', width:40, editable: false, align:'center',hidden:true},    
    {name:'id_meter', index:'id_meter', width:40, editable: false, align:'center',hidden:true},    
    {name:'id_type_meter', index:'id_type_meter', width:40, editable: false, align:'center',hidden:true},    
    {name:'id_p_indic', index:'id_p_indic', width:40, editable: false, align:'center',hidden:true},    
    
    
    {label:'Книга',name:'book', index:'book', width:40, editable: true, align:'left',edittype:'text'},            
    {label:'Рахунок',name:'code', index:'code', width:40, editable: true, align:'left',edittype:'text'},                
    {label:'Адреса',name:'address', index:'address', width:100, editable: true, align:'left',edittype:'text'},                    
    {label:'Абонент',name:'abon', index:'abon', width:100, editable: true, align:'left',edittype:'text'},                        
    {label:'№ ліч.',name:'num_meter', index:'num_meter', width:80, editable: true, align:'left',edittype:'text'},            
    {label:'Тип ліч.',name:'type_meter', index:'type_meter', width:80, editable: true, align:'left',edittype:'text'},                
    {label:'Розр. ліч.',name:'carry', index:'carry', width:40, editable: true, align:'left',edittype:'text'},                    
    {label:'К.тр',name:'k_tr', index:'k_tr', width:40, editable: true, align:'left',edittype:'text'},                        
    {label:'Зона',name:'id_zone', index:'id_zone', width:60, editable: true, align:'right',
                            edittype:'select',formatter:'select',editoptions:{value:lzones},stype:'text'},                       
 
    {label:'Попер.пок.',name:'p_indic', index:'p_indic', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text'},           

    {label:'Дата попер.',name:'dt_p_indic', index:'dt_p_indic', width:80, editable: true, 
                        align:'left',edittype:'text',formatter:'date'},

    {label:'Поточні пок.',name:'indic', index:'indic', width:80, editable: true, align:'right',hidden:false,
                            edittype:'text'},           
    
    {label:'Дата',name:'dt_indic', index:'dt_indic', width:80, editable: true, 
                        align:'left',edittype:'text',formatter:'date'},


    {name:'work_period', index:'work_period', width:80, editable: true, align:'left',edittype:'text', hidden:true},
    {name:'dt_input', index:'dt_input', width:100, editable: true, align:'left', formatter:'date', hidden:true,
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i'}},
    {name:'user_name', index:'user_name', width:100, editable: true, align:'left',edittype:'text', hidden:true},        

    ],
    pager: '#indic_tablePager',
    autowidth: true,
    //shrinkToFit : false,
    rowNum:500,
 //   rowList:[50,100,200],
    sortname: 'id',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: 'Показники',
    //hiddengrid: false,
    hidegrid: false,   
    //pgbuttons: false,     // disable page control like next, back button
    //pgtext: null,         // disable pager text like 'Page 0 of 10'
    
    postData:{'p_id':0},
    
    gridComplete:function(){

     if ($(this).getDataIDs().length > 0) 
     {      
       var first_id = parseInt($(this).getDataIDs()[0]);
       $(this).setSelection(first_id, true);
     }
    },
    onSelectRow: function(id) { 
          cur_indic_id = id;
    },
    
    //ondblClickRow: function(id){ 
    //     jQuery(this).editGridRow(id,LgtNormEditOptions);  
    //} ,  

    loadError : function(xhr,st,err) {
      jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText);
    }
  
  //  jsonReader : { repeatitems: false }

  }).navGrid('#indic_tablePager',
         {edit:false,add:false,del:false},
        {}, 
        {}, 
        {}, 
        {} 
        ); 

//==============================================================================

//jQuery("#headers_table").jqGrid('bindKeys', {"onEnter":function( id ) { 
//      jQuery(this).editGridRow(id,{width:300,height:300,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});}} );


//jQuery("#accnt_table").jqGrid('bindKeys', {"onEnter":function( id ) { 
//      jQuery(this).editGridRow(id,{width:300,height:300,reloadAfterSubmit:false,closeAfterAdd:true,closeAfterEdit:true,afterSubmit:processAfterEdit});}} );



$("#message_zone").dialog({autoOpen: false});

$("#debug_ls1").click( function() {jQuery("#message_zone").dialog('open');});
$("#debug_ls2").click( function() {jQuery("#message_zone").dialog('close');});
$("#debug_ls3").click( function() {jQuery("#message_zone").html('');});

jQuery(".btn").button();
jQuery(".btnSel").button({icons: {primary:'ui-icon-folder-open'}});

jQuery("#fHeaderEdit :input").addClass("ui-widget-content ui-corner-all");


$("#dialog_editform").dialog({
			resizable: true,
		//	height:140,
                        width:600,
			modal: true,
                        autoOpen: false,
                        title:"Дільниця"
});
//------------------------------------------------------------------------------
$.ajaxSetup({type: "POST",      dataType: "json"});
/*
$("#pAccnt_oper_table").dialog({
    resizable: true,
    height:600,
    width:800,
    modal: true,
    autoOpen: false,
    title:"Вибір абонентів на дільницю",
    buttons: {
        "Додати до дільниці": function() {
                                         
            $("#dialog-changedate").dialog({ 
                resizable: false,
                height:140,
                modal: true,
                autoOpen: false,
                buttons: {
                    "Ok": function() {
                                                    
                        var cur_dt_change = jQuery("#dialog-changedate").find("#fdate_change").val();
                        if (cur_dt_change=='') return;        
                                
                        var ids =jQuery("#accnt_oper_table").jqGrid('getGridParam','selarrrow');
                        //alert(ids);                                                  
                        var request = $.ajax({
                            url: "runner_sectors_accnt_oper_edit.php",
                            data: {
                                id_sector: cur_doc_id, 
                                change_date:cur_dt_change,
                                oper : 'add', 
                                id_array: ids
                            }
                        });

                        request.done(function(data ) {
                              if (data.errcode!==undefined)
                               {
                                $('#message_zone').append(data.errstr);
                                $('#message_zone').append("<br>");
                               }
                               jQuery('#accnt_table').jqGrid('setGridParam',{'postData':{'p_id':cur_doc_id } }).trigger('reloadGrid');
                        });
                        request.fail(function(data ) {    alert("error");   });
                                   
                        $( "#pAccnt_oper_table" ).dialog( "close" );                              
                        $( this ).dialog( "close" );
                    },
                    "Отмена": function() {
                        $( this ).dialog( "close" );
                    }
                }
            });
                                        
            jQuery("#dialog-changedate").dialog('open');
        //$( this ).dialog( "close" );
    },

    "Видалити з дільниці": function() {
            $("#dialog-changedate").dialog({ 
                resizable: false,
                height:140,
                modal: true,
                autoOpen: false,
                buttons: {
                    "Ok": function() {
                                                    
                        var cur_dt_change = jQuery("#dialog-changedate").find("#fdate_change").val();
                        if (cur_dt_change=='') return;        
                                   
                        var ids =jQuery("#accnt_oper_table").jqGrid('getGridParam','selarrrow');
                        //alert(ids);                                                  
                        var request = $.ajax({
                            url: "runner_sectors_accnt_oper_edit.php",
                            data: {
                                id_sector: cur_doc_id, 
                                change_date:cur_dt_change,
                                oper : 'del', 
                                id_array: ids
                            }
                        });

                        request.done(function(data ) {
                              if (data.errcode!==undefined)
                               {
                                $('#message_zone').append(data.errstr);
                                $('#message_zone').append("<br>");
                               }
                               jQuery('#accnt_table').jqGrid('setGridParam',{'postData':{'p_id':cur_doc_id } }).trigger('reloadGrid');
                        });
                        request.fail(function(data ) {    alert("error");   });
                                   
                        $( "#pAccnt_oper_table" ).dialog( "close" );                              
                        $( this ).dialog( "close" );
                    },
                    "Отмена": function() {
                        $( this ).dialog( "close" );
                    }
                }
            });
                                        
            jQuery("#dialog-changedate").dialog('open');

},

"Закрити": function() {
    $( this ).dialog( "close" );
}
},
resize: function(event, ui) { 
    jQuery("#accnt_oper_table").jqGrid('setGridWidth',jQuery("#pAccnt_oper_table").innerWidth()-8);
    jQuery("#accnt_oper_table").jqGrid('setGridHeight',jQuery("#pAccnt_oper_table").innerHeight()-80);
                             
},
open: function(event, ui) { 
    jQuery("#accnt_oper_table").jqGrid('setGridWidth',jQuery("#pAccnt_oper_table").innerWidth()-8);
    jQuery("#accnt_oper_table").jqGrid('setGridHeight',jQuery("#pAccnt_oper_table").innerHeight()-80);
                         
}
});

*/
 outerLayout = $("body").layout({
		name:	"outer" 
	,	north__paneSelector:	"#pmain_header"
	,	north__closable:	false
	,	north__resizable:	false
        ,	north__size:		40
	,	north__spacing_open:	0
	,	south__paneSelector:	"#pmain_footer"
	,	south__closable:	false
	,	south__resizable:	false
        ,	south__size:		40
	,	south__spacing_open:	0
	,	center__paneSelector:	"#pmain_center"
	,	resizeWhileDragging:	true
	,	autoBindCustomButtons:	true

	});

 innerLayout = $("#pmain_center").layout({
		name:	"inner"  
	,	north__paneSelector:	"#pHeaders_table"
	,	north__closable:	false
	,	north__resizable:	true
        ,	north__size:		300
	,	center__paneSelector:	"#pIndic_table"
	,	resizeWhileDragging:	true
	,	autoBindCustomButtons:	true
	,       north__onresize:	function (pane, _pane, state, options) 
        {
            jQuery("#headers_table").jqGrid('setGridWidth',_pane.innerWidth()-10);
            jQuery("#headers_table").jqGrid('setGridHeight',_pane.innerHeight()-85);
        }
	,       center__onresize:	function (pane, _pane, state, options) 
        {
            jQuery("#indic_table").jqGrid('setGridWidth',_pane.innerWidth()-10);
            jQuery("#indic_table").jqGrid('setGridHeight',_pane.innerHeight()-85);
        }

	});

        outerLayout.resizeAll();
        
        
 var form_options = { 
    dataType:"json",
    beforeSubmit: FormBeforeSubmit, // функция, вызываемая перед передачей 
    success: FormSubmitResponse // функция, вызываемая при получении ответа
  };

fHeader_ajaxForm = $("#fHeaderEdit").ajaxForm(form_options);
        
// опции валидатора общей формы
var form_valid_options = { 

		rules: {
			dt_pack: "required",
                        sector:"required",
                        runner: "required"
		},
		messages: {
			dt_pack: "Вкажіть дату",
                        sector:"Вкажіть дільницю",
                        runner: "Вкажіть працівника!"
		}
};

validator = $("#fHeaderEdit").validate(form_valid_options);


$("#fHeaderEdit").find("#bt_reset").click( function() 
{
  jQuery("#dialog_editform").dialog('close');                           
});
        
jQuery("#headers_table").jqGrid('navButtonAdd','#headers_tablePager',{caption:"Новий",
    onClickButton:function(){ 

        validator.resetForm();
        $("#fHeaderEdit").resetForm();
        $("#fHeaderEdit").clearForm();
          
        $("#fHeaderEdit").find("#fid").attr('value',-1 );    
        $("#fHeaderEdit").find("#foper").attr('value','add');              
          
        $("#fHeaderEdit").find("#bt_add").show();
        $("#fHeaderEdit").find("#bt_edit").hide();            
        jQuery("#dialog_editform").dialog('open');          
            
    } 
});

jQuery("#headers_table").jqGrid('navButtonAdd','#headers_tablePager',{caption:"Видалити",
	onClickButton:function(){ 

      if ($("#headers_table").getDataIDs().length == 0) 
       {return} ;    

      jQuery("#dialog-confirm").find("#dialog-text").html('Видалити документ?');
    
      $("#dialog-confirm").dialog({
			resizable: false,
			height:140,
			modal: true,
                        autoOpen: false,
                        title:'Видалення',
			buttons: {
				"Видалити": function() {
                                                      
                                        fHeader_ajaxForm[0].id.value = cur_doc_id;
                                        //fHeader_ajaxForm[0].change_date.value = cur_dt_change;
                                        fHeader_ajaxForm[0].oper.value = 'del';
                                        fHeader_ajaxForm.ajaxSubmit(form_options);   

					$( this ).dialog( "close" );                                    
				},
				"Відмінити": function() {
					$( this ).dialog( "close" );
				}
			}
		});
    
        jQuery("#dialog-confirm").dialog('open');   
          
        ;} 
});

jQuery("#headers_table").jqGrid('navButtonAdd','#headers_tablePager',{caption:"Занести показ.",
	onClickButton:function(){ 
            
        gsr = jQuery(this).jqGrid('getGridParam','selrow'); 
        if(gsr)
        { 

            validator.resetForm();  //для сброса состояния валидатора
            $("#fHeaderEdit").resetForm();
            $("#fHeaderEdit").clearForm();
          
            $("#headers_table").jqGrid('GridToForm',gsr,"#fHeaderEdit"); 

            $("#fHeaderEdit").attr('target',"ind_input_win" );           
            $("#fHeaderEdit").attr('action',"ind_packs_input.php" );               
    
            var ww = window.open("ind_packs_input.php", "ind_input_win", "toolbar=0,width=800,height=600");
            document.fHeaderEdit.submit();
            ww.focus();
     
            $("#fHeaderEdit").attr('target',"" );           
            $("#fHeaderEdit").attr('action',"ind_packs_edit.php" );               
        }

     } 
});

jQuery("#headers_table").jqGrid('navButtonAdd','#headers_tablePager',{
    caption:"Друк відомості",
    onClickButton:function(){ 
        gsr = jQuery(this).jqGrid('getGridParam','selrow'); 
        if(gsr)
        { 

            validator.resetForm();  //для сброса состояния валидатора
            $("#fHeaderEdit").resetForm();
            $("#fHeaderEdit").clearForm();
          
            $("#headers_table").jqGrid('GridToForm',gsr,"#fHeaderEdit"); 

            //$("#fHeaderEdit").attr('target',"ind_print_win" );           
            $("#fHeaderEdit").attr('target',"_blank" );           
            $("#fHeaderEdit").attr('action',"ind_packs_print.php" );               
    
            //var ww = window.open("ind_packs_print.php", "ind_print_win", "width=800,height=600");
            //var ww = window.open("ind_packs_print.php", '_blank');
            document.fHeaderEdit.submit();
            ww.focus();
     
            $("#fHeaderEdit").attr('target',"" );           
            $("#fHeaderEdit").attr('action',"ind_packs_edit.php" );               
        }


    } 
});

//=========================================================================

//выбор участка
jQuery("#btSectorSel").click( function() {

    sector_target_id =jQuery("#fid_sector");
    sector_target_name=jQuery("#fsector");
    sector_target_runner_id=jQuery("#fid_runner");
    sector_target_runner_name=jQuery("#frunner");

    createSectorGrid(); 
    jQuery("#grid_selsector").css({'left': $(this).position().left+1, 'top': $(this).position().top+20});
    jQuery("#grid_selsector").toggle( );
});


   jQuery("#btRunnerSel").click( function() { 

   $("#fcntrl_sel_params_id_cntrl").attr('value', $("#fHeaderEdit").find("#fid_runner").val() );    
     var www = window.open("staff_list.php", "cntrl_win", "toolbar=0,width=800,height=600");
     document.cntrl_sel_params.submit();
     www.focus();
   });


        
// обработчик, который вызываетя перед отправкой формы
function FormBeforeSubmit(formData, jqForm, options) { 

    submit_form = jqForm;

    var queryString = $.param(formData);     
    $('#message_zone').append('Вот что мы передаем:' + queryString);  
    $('#message_zone').append("<br>");                 
    
    var btn = '';
    for (var i=0; i < formData.length; i++) { 
        if (formData[i].name =='submitButton') { 
           btn= formData[i].value; 
           submit_form[0].oper.value = btn;
        } 
    } 

    if((btn=='edit')||(btn=='add'))
    {
       if(!submit_form.validate().form())  {return false;}
       else {
           
            $("#fHeaderEdit").find("#bt_add").attr("disabled", true);
            $("#fHeaderEdit").find("#bt_reset").attr("disabled", true);
            
            $("#fHeaderEdit").find("#lwait").show();
            
            return true; 

       }
    }
    else {return true;}       
    //}
    
} ;

// обработчик ответа сервера после отправки формы
function FormSubmitResponse(responseText, statusText)
{
             errorInfo = responseText;
             
              $("#fHeaderEdit").find("#bt_add").attr("disabled", false);
              $("#fHeaderEdit").find("#bt_reset").attr("disabled", false);
            
              $("#fHeaderEdit").find("#lwait").hide();
             

             if (errorInfo.errcode==0) {
             return [true,errorInfo.errstr]
             }; 

             if (errorInfo.errcode==-1) {
                 
               jQuery("#dialog_editform").dialog('close');                           
               jQuery('#headers_table').trigger('reloadGrid');        
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');  
              // jQuery('#message_zone').dialog('open');
               return [true,errorInfo.errstr]};              
             
             if (errorInfo.errcode==1) {
                 
               //var fid = jQuery("#fid").val();
               //if(fid) 
               //{ 
               //  jQuery("#lgt_category_table").jqGrid('FormToGrid',fid,"#fLgtCategoryEdit"); 
               //}  
               
               
               jQuery('#headers_table').trigger('reloadGrid');        
               
               jQuery("#dialog_editform").dialog('close');                                            
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');  
              // jQuery('#message_zone').dialog('open');
               return [true,errorInfo.errstr]};              
               
             if (errorInfo.errcode==2) {
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');                 
               jQuery('#message_zone').dialog('open');
               return [false,errorInfo.errstr]};   

};


}); 

function SelectPersonExternal(id, name) {
        $("#fHeaderEdit").find("#fid_runner").attr('value',id );
        $("#fHeaderEdit").find("#frunner").attr('value',name );    
    
}


function RefreshIndicExternal(id_doc)
{
  if( cur_doc_id == id_doc)
  {
        jQuery('#indic_table').jqGrid('setGridParam',{'postData':{'p_id':cur_doc_id}}).trigger('reloadGrid');        
  }
    
}

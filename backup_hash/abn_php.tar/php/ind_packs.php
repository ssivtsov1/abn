<?php

header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();
error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) {
  $ids = $_SESSION['id_sess'];

  $res_par = sel_par($ids);
  $row_par = pg_fetch_array($res_par);
  $cons = $row_par['con_str1'];
  $Q = $row_par['qu'];
  $Link = pg_connect($cons);
}
*/
//$lnk_sys = log_s_pgsql("login");
//$lnk1 = $lnk_sys['lnks'];

//$rr = pg_query($Link, $Q);
/*
$idgrt = 0;
$idtar = 0;
$idgrpl = 0;
$idbperc = 0;

$QS = "update dbusr_var set idgrt=" . $idgrt . ",idtar=" . $idtar . ",idgrpl=" . $idgrpl .
        ",idbperc=" . $idbperc . " where id_sess=" . $ids;
$res_qs = pg_query($lnk1, $QS);
*/

$nmp1 = "Абон-енерго (Відомості зняття показань)";
  
start_mpage($nmp1); //заголовок
head_addrpage();  // хедер, подключение библиотек

$lioper=DbTableSelList($Link,'indic_opration','id','name');
$lioperselect=DbTableSelect($Link,'indic_opration','id','name');

$lzones=DbTableSelList($Link,'eqk_zone_tbl','id','nm');
$lzoneselect=DbTableSelect($Link,'eqk_zone_tbl','id','nm');



print('<link rel="stylesheet" type="text/css" href="css/ded_styles.css" /> ');
print('<link rel="stylesheet" type="text/css" href="css/layout-default-latest.css" /> ');
print('<script type="text/javascript" src="js/jquery.layout.min-latest.js"></SCRIPT>');
print('<script type="text/javascript" src="js/jquery.form.js"></script>');
print('<script type="text/javascript" src="js/jquery.validate.min.js" ></script>');
print('<script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.ui.datepicker-uk.js"></script> ');
print('<script type="text/javascript" src="js/jquery.maskedinput-1.3.min.js"></script> ');


print('<script type="text/javascript" src="ind_packs.js"></script> ');
print('<script type="text/javascript" src="runner_sectors_sel.js"></script> ');

echo <<<SCRYPT
<script type="text/javascript">
    var lioper = $lioper;
    var lzones = $lzones;
</script>
SCRYPT;

?>

</head>
<body >

    <DIV id="pmain_header"> 
        <?php main_menu(); ?>
    </DIV> 

    <DIV id="pmain_footer">
        <a href="javascript:void(0)" id="debug_ls1">show debug window</a> 
        <a href="javascript:void(0)" id="debug_ls2">hide debug window</a> 
        <a href="javascript:void(0)" id="debug_ls3">clear debug window</a>
    </DIV>

    <DIV id="pmain_center">    
        
        <div id="pHeaders_table" style="padding:2px; margin:3px;">    
            <table id="headers_table" > </table>
            <div   id="headers_tablePager" ></div>
        </div>    

        <div id="pIndic_table" style="padding:2px; margin:3px;">    
            <table id="indic_table" > </table>
            <div   id="indic_tablePager" ></div>
        </div>    

    </DIV>
    
        <div id="dialog_editform" style="display:none; overflow:visible; padding:1px; ">        
        <form id="fHeaderEdit" name="fHeaderEdit" method="post" action="ind_packs_edit.php" >
          <div class="pane"  >
            <input name="id" type="hidden" id="fid" value="" />
            <input name="oper" type="hidden" id="foper" value="" />            
            <input name="change_date" type="hidden" id ="fchange_date" value="" />                            
            <div class="pane"  >    


                <p>            
                    <label>Номер відомості.
                        <input name="num_pack" type="text" id = "fnum_pack" size="20" value= "" data_old_value = ""/>
                    </label> 
                    <label>Дата 
                        <input name="dt_pack" type="text" size="12" value="" id="fdt_pack" class="dtpicker" data_old_value = "" />
                    </label>

                </p>
                
                <p>            
                    <input name="id_sector" type="hidden" id = "fid_sector" size="10" value= "" data_old_value = ""/>    
                    <label >Дільниця
                        <input name="sector" type="text" id = "fsector" size="60" value= "" data_old_value = ""/>
                    </label> 
                    <button type="button" class ="btnSel" id="btSectorSel"></button>       
                </p>
                
                <p>            
                    <input name="id_runner" type="hidden" id = "fid_runner" size="10" value= "" data_old_value = ""/>    
                    <label >Кур'єр / контролер
                        <input name="runner" type="text" id = "frunner" size="60" value= "" data_old_value = ""/>
                    </label> 
                    <button type="button" class ="btnSel" id="btRunnerSel"></button>       
                </p>

                <p> 
                    <label>Робота
                        <select name="id_ioper" size="1" id = "fid_ioper" size="10" value= "" data_old_value = "">                             
                            <?php echo "$lioperselect" ?>;
                        </select>                    
                    </label> 
                </p>


                
            </div>    

        </div>    
        <div class="pane" >
                <button name="submitButton" type="submit" class ="btn" id="bt_edit" value="edit" >Записати</button>
                <button name="submitButton" type="submit" class ="btn" id="bt_add" value="add" style="display:none;">Записати новий</button>                
                <button name="resetButton" type="button" class ="btn" id="bt_reset" value="bt_reset" >Відмінити</button>         
                &nbsp;&nbsp;
                <span id="lwait" style="color:navy; display:none; "> Зачекайте закінчення операції ... </span>
        </div>
            
      </FORM>
            
      </div>  
    

      <div id="dialog-confirm" title="" style="display:none;">
	<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        <p id="dialog-text"> </p></p>
      </div>

    <div id="dialog-changedate" title="Дата редагування" style="display:none;">
	<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
        <p id="dialog-text">Вкажіть дату редагування </p></p>
        <br>
        <input name="date_change" type="text" size="20" class="dtpicker" id ="fdate_change"/>
    </div>

    <form id="fcntrl_sel_params" name="cntrl_sel_params" target="cntrl_win" method="post" action="staff_list.php">
        <input type="hidden" name="select_mode" value="1" />
        <input type="hidden" name="id_person" id="fcntrl_sel_params_id_cntrl" value="0" />        
    </form>
    
     <div id="grid_selsector" style="display:none; position:absolute; margin:1px; background: #FFFFCC; borderWidth:1px;z-index: 100000;" >   
            <table id="sectors_sel_table" style="margin:1px;"></table>
            <div id="sectors_sel_tablePager"></div>
     </div>       
    
<?php

print('<div id="message_zone" style ="padding: 5px;color: blue;" >  </div>');


end_mpage();
?>
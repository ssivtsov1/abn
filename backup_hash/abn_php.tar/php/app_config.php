<?php
    $app_host = "10.71.1.94";
    $app_main_db = "abn_en_mcn";
    $app_maintenance_db = "sys_en";
    $app_user = "local";
    $app_pass = "postgres";
    $app_maint_cstr="host=$app_host dbname=$app_maintenance_db user=$app_user password=$app_pass";
?>
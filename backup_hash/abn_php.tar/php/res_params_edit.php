<?php
header('Content-type: text/html; charset=utf-8');

require 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();

error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) { $ids=$_SESSION['id_sess'];  

	$res_par=sel_par($ids);
	$row_par=pg_fetch_array($res_par);
	$cons=$row_par['con_str1'];
	$Q=$row_par['qu'];
//	$id=$row_par['id'];
//	$id_e1=$row_par['idreg'];
	$Link=pg_connect($cons);}

	$lnk_sys=log_s_pgsql("login");
	$lnk1=$lnk_sys['lnks'];
 */
try {

    
if (isset($_POST['submitButton'])) 
{    
  $oper=$_POST['submitButton'];
}
else
{    
    if (isset($_POST['oper'])) {
        $oper=$_POST['oper'];
    }
}
    
//throw new Exception(json_encode($_POST));

//------------------------------------------------------
if ($oper=="edit") {

$p_name = sql_field_val('name','string');
$p_short_name = sql_field_val('short_name','string');
$p_code = sql_field_val('code','string');

$p_addr=sql_field_val('addr','record');
$p_addr_str=sql_field_val('addr_str','string');

$p_id_boss = sql_field_val('id_boss','int');
$p_id_buh = sql_field_val('id_buh','int');

$p_ae_mfo = sql_field_val('ae_mfo','int');
$p_ae_account = sql_field_val('ae_account','int');

$p_phone_bill = sql_field_val('phone_bill','string');
$p_addr_ikc = sql_field_val('addr_ikc','string');
$p_phone_ikc = sql_field_val('phone_ikc','string');

$p_licens_num = sql_field_val('licens_num','string');
$p_okpo_num = sql_field_val('okpo_num','string');
$p_tax_num = sql_field_val('tax_num','string');

$p_addr_district = sql_field_val('addr_district','int');

$p_id=sql_field_val('id','int');    


$QE="UPDATE syi_resinfo_tbl

   SET name=$p_name, short_name=$p_short_name, code=$p_code, addr=$p_addr, addr_str=$p_addr_str, 
       id_boss=$p_id_boss, id_buh=$p_id_buh, ae_mfo=$p_ae_mfo, ae_account=$p_ae_account, 
       phone_bill=$p_phone_bill, addr_ikc=$p_addr_ikc, phone_ikc=$p_phone_ikc,
       licens_num=$p_licens_num, okpo_num=$p_okpo_num, tax_num=$p_tax_num,
       addr_district =$p_addr_district
 WHERE id_department = $p_id;";

 $res_e=pg_query($Link,$QE);
 if ($res_e) {
     echo_result(1,'Data updated');

     }
 else        {
     echo_result(2,pg_last_error($Link));
     }
}
//------------------------------------------------------


}
catch (Exception $e) {

 echo echo_result(1,'Error: '.$e->getMessage());
}

?>
<?php

header('Content-type: text/html; charset=utf-8');

require_once 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();
//error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];

/*
if (isset($_SESSION['id_sess'])) {
  $ids = $_SESSION['id_sess'];
  $res_s = sel_par($ids);
  $row_s = pg_fetch_array($res_s);
  $page1 = $row_s['pg'];
  $rnum1 = $row_s['rn'];
  $id11 = $row_s['id1'];
  $cons = $row_s['con_str1'];
  $Link = pg_connect($cons);
  $Qm_pp = $row_s['qm_paccnt'];
}
*/
/*
$lnk_sys = log_s_pgsql("login");
$lnk1 = $lnk_sys['lnks'];

$nacc = 0;
$QS = "update dbusr_var set nacc=" . $nacc . " where id_sess=" . $ids;
$res_qs = pg_query($lnk1, $QS);
//$QS_1 = "update s_var set Qm_pcalc='',work_p=null,avance='f' where id_sess=" . $ids;
$QS_1 = "update s_var set Qm_pcalc='',work_p=null where id_sess=" . $ids;

$res_qs_1 = pg_query($lnk1, $QS_1);
*/


$nm1 = "Абон-енерго (Рахунки абонентів )";

start_mpage($nm1);
head_addrpage();

print('<link rel="stylesheet" type="text/css" href="css/ded_styles.css" /> ');
print('<link rel="stylesheet" type="text/css" href="css/layout-default-latest.css" /> ');
    
print('<script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.form.js"></script>');
print('<script type="text/javascript" src="js/jquery.validate.min.js" ></script>');
print('<script type="text/javascript" src="js/jquery.ui.datepicker-uk.js"></script> ');
print('<script type="text/javascript" src="js/jquery.maskedinput-1.3.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.layout.min-latest.js"></SCRIPT>');
print('<script type="text/javascript" src="Abon_en_bills.js"></script> ');

$lid_pref=DbTableSelList($Link,'aci_pref_tbl','id','name');
$lidk_doc=DbTableSelList($Link,'dci_doc_tbl','id','name');



?>
<style type="text/css"> 
#pmain_content {padding:3}

.tabPanel {padding:1px; margin:1px; }
.ui-tabs .ui-tabs-panel {padding:1px;}

.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {  color: #111111; }

</style>   


<script type="text/javascript">

var lid_pref = <?php echo "$lid_pref" ?>; 
var lidk_doc = <?php echo "$lidk_doc" ?>; 
 
</script>

</head>
<body >


<DIV id="pmain_header"> 
    
    <?php main_menu(); ?>

</DIV>
    
<DIV id="pmain_footer">
    
   <a href="javascript:void(0)" id="debug_ls1">show debug window</a> 
   <a href="javascript:void(0)" id="debug_ls2">hide debug window</a> 
   <a href="javascript:void(0)" id="debug_ls3">clear debug window</a>

</DIV>  

    <DIV id="pmain_content">

       <div id="tab_bill" > 
           <table id="bill_table" style="margin:1px;"></table>
           <div id="bill_tablePager"></div>
       </div>

    </DIV>

    
    <DIV style="display:none;">
       <form id="fprint_params" name="print_params" method="post" action="bill_print.php">
         <input type="text" name="book" id="pbook" value="" />         
         <input type="text" name="mmgg" id="pmmgg" value="" />         
         <input type="text" name="bill_list" id="pbill_list" value="" />                  
       </form>
    </DIV>
    
<div id="message_zone" style ="padding: 5px;color: blue;" >  </div>


<?php

end_mpage();
?>



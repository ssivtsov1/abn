var SelectAbonTarget='';
var SelectPersonTarget='';
var SelectPersonStrTarget='';
var isMainHistGridCreated =false;
var form_options = { 
    dataType:"json",
    beforeSubmit: AccFormBeforeSubmit, 
    success: AccFormSubmitResponse 
  };


jQuery(function(){ 


    outerLayout = $("body").layout({
		name:	"outer" 
	,	north__paneSelector:	"#pmain_header"
	,	north__closable:	false
	,	north__resizable:	false
        ,	north__size:		40
	,	north__spacing_open:	0
	,	south__paneSelector:	"#pmain_footer"
	,	south__closable:	false
	,	south__resizable:	false
        ,	south__size:		40
	,	south__spacing_open:	0
	,	center__paneSelector:	"#pmain_content"
	//,	center__onresize:		'innerLayout.resizeAll'
	,	resizeWhileDragging:	true
	,	autoBindCustomButtons:	true
   //     ,	center__onresize:   $.layout.callbacks.resizeTabLayout        
	});
    
    $( "#pwork_center" ).tabs({
      //  show: $.layout.callbacks.resizeTabLayout        
    });

    innerLayout = $("#pmain_content").layout({
		name:			"inner" 
	,	north__paneSelector:	"#pwork_header"
	,	north__closable:	false
	,	north__resizable:	false
        ,	north__spacing_open:	0
        ,	north__size:		230
        ,	center__paneSelector:	"#pwork_center"
	,	autoBindCustomButtons:	true
//        ,	center__onresize:   $.layout.callbacks.resizeTabLayout
	,       center__onresize:	function (pane, $pane, state, options) 
        {
            //jQuery("#paccnt_meters_table").jqGrid('setGridWidth',$pane.innerWidth()-20);
            //jQuery("#paccnt_meters_table").jqGrid('setGridWidth',jQuery("#paccnt_meters_list").innerWidth());
            //jQuery("#paccnt_lgt_table").jqGrid('setGridWidth',jQuery("#paccnt_lgt_list").innerWidth());            
            
            jQuery("#paccnt_meters_table").jqGrid('setGridWidth',$pane.innerWidth()-20);
            jQuery("#paccnt_lgt_table").jqGrid('setGridWidth',$pane.innerWidth()-20);
            jQuery("#paccnt_dogovor_table").jqGrid('setGridWidth',$pane.innerWidth()-20);
            jQuery("#paccnt_plomb_table").jqGrid('setGridWidth',$pane.innerWidth()-20);
            jQuery("#paccnt_notlive_table").jqGrid('setGridWidth',$pane.innerWidth()-20);

            jQuery("#paccnt_works_table").jqGrid('setGridWidth',$pane.innerWidth()-20);
            jQuery("#paccnt_works_indic_table").jqGrid('setGridWidth',$pane.innerWidth()-20);

            //jQuery("#client_table").jqGrid('setGridHeight',$pane.innerHeight()-142);

        }
        
	});
        
    meterLayout = $("#pMeterParam").layout({
		name:			"meter_param" 
        //,       initPanes:		false
        //,       resizeWithWindow:	false
	,	east__paneSelector:	"#pMeterParam_right"
	,	east__closable:	true
	,	east__resizable:	true
        ,	east__size:		230
        ,	center__paneSelector:	"#pMeterParam_left"
	,	autoBindCustomButtons:	true
        ,	south__paneSelector:	"#pMeterParam_buttons"
	,	south__closable:	false
	,	south__resizable:	false
        ,	south__spacing_open:	0
        ,	south__size:            40
	,       center__onresize:	function (pane, $pane, state, options) 
        {
            //jQuery("#client_table").jqGrid('setGridWidth',$pane.innerWidth()-9);
            //jQuery("#client_table").jqGrid('setGridHeight',$pane.innerHeight()-142);

        }
    });

/*
    meterLayout = $("#tab_meters").layout({
		name:			"meters" 
        ,       initPanes:		false
        ,       resizeWithWindow:	false
	,	south__paneSelector:	"#pMeterParam"
	,	south__closable:	true
	,	south__resizable:	true
        ,	south__size:		300
        ,	center__paneSelector:	"#paccnt_meters_list"
        ,       center__minSize:	100
	,	autoBindCustomButtons:	true
	,       center__onresize:	function (pane, $pane, state, options) 
        {
            //jQuery("#client_table").jqGrid('setGridWidth',$pane.innerWidth()-9);
            //jQuery("#client_table").jqGrid('setGridHeight',$pane.innerHeight()-142);

        }
        
	});*/

   innerLayout.resizeAll(); 
 //  meterLayout.resizeAll();         


       
    jQuery(".btn").button();
    jQuery(".btnSel").button({ icons: {primary:'ui-icon-folder-open'} });
    jQuery("#fAccEdit :input").addClass("ui-widget-content ui-corner-all");
    
    $.datepicker.setDefaults( $.datepicker.regional[ "uk" ] );
    jQuery(".dtpicker").datepicker({showOn: "button", buttonImage: "images/calendar.gif",
			buttonImageOnly: true});

    jQuery(".dtpicker").datepicker( "option", "dateFormat", "dd.mm.yy" );
    jQuery(".dtpicker").mask("99.99.9999");
    
        
   $("#debug_ls1").click( function() {jQuery("#message_zone").dialog('open'); });
   $("#debug_ls2").click( function() {jQuery("#message_zone").dialog('close');});
   $("#debug_ls3").click( function() {jQuery("#message_zone").html('');});
   
   $("#message_zone").dialog({ autoOpen: false });
   $("#dialog-mainhistory").dialog({ autoOpen: false ,resizable: true, height:253, width:750 });
//-----------------------------------------------------
   jQuery("#btAbonSel").click( function() { 
     SelectAbonTarget='fAccEdit';

    if ($("#fAccEdit").find("#fid_abon").val()!='')
        $("#fabon_sel_params_id_abon").attr('value', $("#fAccEdit").find("#fid_abon").val() );    
    else
        $("#fabon_sel_params_id_abon").attr('value', '0' );    
    
     var ww = window.open("dov_abon.php", "abon_win", "toolbar=0,width=900,height=600");
     document.abon_sel_params.submit();
     ww.focus();
   });


   jQuery("#btCntrlSel").click( function() { 

    SelectPersonTarget='#fid_cntrl';
    SelectPersonStrTarget='#fcntrl';

    if ($("#fAccEdit").find("#fid_cntrl").val()!='')
        $("#fcntrl_sel_params_id_cntrl").attr('value', $("#fAccEdit").find("#fid_cntrl").val() );    
    else
        $("#fcntrl_sel_params_id_cntrl").attr('value', '0' );    
    
     var www = window.open("staff_list.php", "cntrl_win", "toolbar=0,width=900,height=600");
     document.cntrl_sel_params.submit();
     www.focus();
   });

   jQuery("#btTarSel").click( function() { 

     var www = window.open("tarif_list.php", "tar_win", "toolbar=0,width=900,height=600");
     document.tarif_sel_params.submit();
     www.focus();
   });

   jQuery("#btAddrSel").click( function() { 
        SelectAdrTarget='#faddr';
        SelectAdrStrTarget='#faddr_str';

        $("#fadr_sel_params_address").attr('value', $("#fAccEdit").find("#faddr").val() );    
    
       // $("#fadr_sel_params").attr('target',"_blank" );           
        var ww = window.open("adr_tree_selector.php", "adr_win", "toolbar=0,width=900,height=600");
        document.adr_sel_params.submit();
        ww.focus();
   });

   jQuery("#bt_mainhistory").click( function() { 

    createMainHistGrid();
    jQuery("#dialog-mainhistory").dialog('open');
   });

 //---------------------------------------------

$.ajaxSetup({  type: "POST",   dataType: "json" });

var fAccEdit_ajaxForm = $("#fAccEdit").ajaxForm(form_options);

// опции валидатора общей формы
var form_valid_options = { 
                errorPlacement: function(error, element) {
				error.appendTo( element.parent("label").parent("div"));
                },
		rules: {
			book: "required",
			code: "required",                        
			//addr: "required",
                        abon: "required",
                        dt_b: "required"
		},
		messages: {
			book: "Вкажіть номер книги!",
			code: "Вкажіть особовий рахунок!",
			//addr: "Вкажіть адресу",
                        abon: "Вкажіть абонента",
                        dt_b: "Вкажіть дату"
		}
};

validator = $("#fAccEdit").validate(form_valid_options);

//$.ajaxSetup({  type: "POST",   dataType: "json" });

if (mode == 0)
{
 var request = $.ajax({
     url: "Abon_en_paccnt_data.php",
     type: "POST",
     data: {id : id_paccnt },
     dataType: "json" });

 request.done(function(data ) {
     LoadAccData(data);
 });
 request.fail(function(data ) { alert("error"); });

 $("#fAccEdit").find("#bt_add").hide();
 $("#fAccEdit").find("#bt_edit").show(); 

}
else
{
 $("#fAccEdit").find("#bt_add").show();
 $("#fAccEdit").find("#bt_edit").hide();   
 $("#fAccEdit").find("#bt_delabon").hide();   
 $("#fAccEdit").find("#bt_showtree").hide();   
 $("#fAccEdit").find("#bt_mainhistory").hide();   
 $("#fAccEdit").find("#archive_label").hide();
 $("#fAccEdit").find("#bt_archabon").hide();

 $("#pwork_center").hide();

}

$("#fAccEdit").find("#bt_reset").click( function() 
{
    if (mode==0)
    {        
        validator.resetForm();
        ResetJQFormVal($("#fAccEdit"));
    }
    else
    {
        window.location = 'Abon_en_main.php';
    }
});

$("#fAccEdit").find("#bt_showtree").click( function() 
{
    $("#fpaccnt_params").attr("action","eqp_tree.php");
    $("#fpaccnt_params").attr('target',"_blank" );           
    document.paccnt_params.submit();
});

//---------------------------------------------------
$("#fAccEdit").find("#bt_delabon").click( function() 
{
      jQuery("#dialog-confirm").find("#dialog-text").html('Видалити особовий рахунок?');
    
      $("#dialog-confirm").dialog({
			resizable: false,
			height:140,
			modal: true,
                        autoOpen: false,
                        title:'Видалення',
			buttons: {
				"Видалити": function() {

                                        $("#dialog-changedate").dialog({ 
                                            resizable: false,
                                            height:140,
                                            modal: true,
                                            autoOpen: false,
                                            buttons: {
                                                "Ok": function() {
                                                    
                                                      var cur_dt_change = jQuery("#dialog-changedate").find("#fdate_change").val();
                                                      
                                                      fAccEdit_ajaxForm[0].change_date.value = cur_dt_change;
                                                      fAccEdit_ajaxForm[0].oper.value = 'del';
                                                      fAccEdit_ajaxForm.ajaxSubmit(form_options);   
                                                      
                                                    $( this ).dialog( "close" );
                                                },
                                                "Отмена": function() {
                                                    $( this ).dialog( "close" );
                                                }
                                            }

                                        });
                                        
                                        jQuery("#dialog-changedate").dialog('open');


					$( this ).dialog( "close" );
				},
				"Відмінити": function() {
					$( this ).dialog( "close" );
				}
			}
		});
    
       jQuery("#dialog-confirm").dialog('open');
          
});


//------------------------------------------------------
//----------------таблица истории  -------------
var createMainHistGrid = function(){ 
    
  if (isMainHistGridCreated) return;
  isMainHistGridCreated =true;


  jQuery('#mainhistory_table').jqGrid({
    url:'Abon_en_paccnt_main_hist_data.php',
    //editurl: '',
    datatype: 'json',
    mtype: 'POST',
    height:150,
    //width:800,
    autowidth: true,
    shrinkToFit : false,
    scroll: 0,
    colModel :[ 
      {name:'id_key', index:'id_key', width:40, editable: false, align:'center', key:true,hidden:true},
      {label:'id',name:'id', index:'id', width:40, editable: false, align:'center', key:true, hidden:true},     
      {label:'Книга',name:'book', index:'book', width:40, editable: true, align:'left',edittype:'text'},           
      {label:'Рах.',name:'code', index:'code', width:40, editable: true, align:'left',edittype:'text'},                 
      {label:'Адреса',name:'addr', index:'addr', width:200, editable: true, align:'left',edittype:'text'},           
      {label:'Абонент',name:'abon', index:'abon', width:200, editable: true, align:'left',edittype:'text'},
      {label:'Арх.',name:'archive', index:'archive', width:30, editable: false, align:'right',hidden:false,
          formatter:'checkbox',edittype:'checkbox'},
      {label:'Тариф',name:'gtar', index:'gtar', width:100, editable: true, align:'left',edittype:'text'},
      {label:'Інспектор',name:'cntrl', index:'cntrl', width:100, editable: true, align:'left',edittype:'text'},
      {label:'Підкл.',name:'activ', index:'activ', width:30, editable: false, align:'right',hidden:false,
          formatter:'checkbox',edittype:'checkbox'},
      {label:'Прац.РЕМ',name:'rem_worker', index:'rem_worker', width:30, editable: false, align:'right',hidden:false,
          formatter:'checkbox',edittype:'checkbox'},
      {label:'Не прож.',name:'not_live', index:'not_live', width:30, editable: false, align:'right',hidden:false,
          formatter:'checkbox',edittype:'checkbox'},
      {label:'Контроль',name:'pers_cntrl', index:'pers_cntrl', width:30, editable: false, align:'right',hidden:false,
          formatter:'checkbox',edittype:'checkbox'},
      {label:'№ субс.',name:'n_subs', index:'n_subs', width:50, editable: true, align:'left',edittype:'text'},              
      {label:'Опал.пл.',name:'heat_area', index:'heat_area', width:50, editable: true, align:'left',edittype:'text'},              
      {label:'Тип житла',name:'house_kind', index:'house_kind', width:100, editable: true, align:'left',edittype:'text'},
      {label:'Прим.',name:'note', index:'note', width:100, editable: true, align:'left',edittype:'text'},

      {label:'dt_b',name:'dt_b', index:'dt_b', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      {label:'dt_e',name:'dt_e', index:'dt_e', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      
      {label:'period_open',name:'period_open', index:'period_open', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      {label:'dt_open',name:'dt_open', index:'dt_open', width:100, editable: true, align:'left', formatter:'date',
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i'}},
      {label:'user_open',name:'user_name_open', index:'user_name_open', width:100, editable: true, align:'left',edittype:'text'},

      {label:'period_close',name:'period_close', index:'period_close', width:80, editable: true, align:'left',edittype:'text',formatter:'date'},
      {label:'dt_close',name:'dt_close', index:'dt_close', width:100, editable: true, align:'left', formatter:'date',
            formatoptions:{srcformat:'Y-m-d H:i:s', newformat:'d.m.Y H:i'}},
      {label:'user_close',name:'user_name_close', index:'user_name_close', width:100, editable: true, align:'left',edittype:'text'},

    ],
    pager: '#mainhistory_tablePager',
    rowNum:50,
    sortname: 'dt_b',
    sortorder: 'asc',
    viewrecords: true,
    gridview: true,
    caption: '',
    pgbuttons: false,
    pgtext: null, 
    hiddengrid: false,
    jsonReader : {repeatitems: false},
    postData:{'p_id': id_paccnt},
      
  loadError : function(xhr,st,err) {jQuery('#message_zone').html('Type: '+st+'; Response: '+ xhr.status + ' '+xhr.responseText);}

  }).navGrid('#mainhistory_tablePager',
        {edit:false,add:false,del:false,search:false}
        ); 
        
};   

});

function SelectAbonExternal(id, name) {
    if(SelectAbonTarget=='fAccEdit')
    {
        $("#fAccEdit").find("#fid_abon").attr('value',id );
        $("#fAccEdit").find("#fabon").attr('value',name );    
    }

    if(SelectAbonTarget=='fDogovorParam')
    {
        $("#fDogovorParam").find("#fid_abon").attr('value',id );
        $("#fDogovorParam").find("#fabon").attr('value',name );    
    }

}

function SelectPersonExternal(id, name) {
    
        $(SelectPersonTarget).attr('value',id );
        $(SelectPersonStrTarget).attr('value',name );    
    
}

function SelectTarExternal(id, name) {
        $("#fAccEdit").find("#fid_gtar").attr('value',id );
        $("#fAccEdit").find("#fgtar").attr('value',name );    
    
}

function SelectAddrExternal(code, name) {
    
        $("#fAccEdit").find(SelectAdrTarget).attr('value',code );
        $("#fAccEdit").find(SelectAdrStrTarget).attr('value',name );    
    
} 

function RefreshMetersExternal(id, name) {
        $("#paccnt_meters_table").jqGrid('setGridParam',{'postData':{'p_id': id_paccnt, 'free_only': 0, 'hist_mode': 0}}).trigger('reloadGrid');                       
        $("#paccnt_works_table").jqGrid('setGridParam',{'postData':{'p_id': id_paccnt}}).trigger('reloadGrid');                       
         innerLayout.resizeAll(); 


}


// обработчик, который вызываетя перед отправкой формы
function AccFormBeforeSubmit(formData, jqForm, options) { 

    submit_form = jqForm;

    var queryString = $.param(formData);     
    $('#message_zone').append('Вот что мы передаем:' + queryString);  
    $('#message_zone').append("<br>");                 
    
    var btn = '';
    for (var i=0; i < formData.length; i++) { 
        if (formData[i].name =='submitButton') { 
           btn= formData[i].value; 
           submit_form[0].oper.value = btn;
        }  
    } 

    if (btn=='arch')
    {
        if ($("#fAccEdit").find("#factiv").prop('checked')==true)
            {
                alert("Абонент должен быть отключен перед отправкой в архив!")
                return false;
            }
    }


    if((btn=='edit')||(btn=='add')||(btn=='arch'))
    {
       if(!submit_form.validate().form())  {return false; }
       else {
        if ((btn=='edit')||(btn=='arch'))
            {
               $("#dialog-changedate").dialog({ 
			resizable: false,
			height:140,
			modal: true,
                        autoOpen: false,
			buttons: {
				"Ok": function() {
                                          var cur_dt_change = jQuery("#dialog-changedate").find("#fdate_change").val();
  
                                          submit_form[0].change_date.value = cur_dt_change;
                                          if (btn=='arch')
                                          {
                                              $("#fAccEdit").find("#archive_label").show();  
                                              //submit_form[0].archive.value = 1;    
                                              $("#fAccEdit").find("#farchive").prop('checked',true);
                                              $("#fAccEdit").find("#fdt_archive").datepicker( "setDate" , cur_dt_change );
                                          }
                                          
                                          submit_form.ajaxSubmit(form_options);    
					$( this ).dialog( "close" );
				},
				"Отмена": function() {
					$( this ).dialog( "close" );
				}
			}

                });
                
                $("#dialog-changedate").dialog('open');
                return false; 
                
            }
            else
                {return true;}        

       }
    }
    else {return true; }       
    //}
    
} ;

// обработчик ответа сервера после отправки формы
function AccFormSubmitResponse(responseText, statusText)
{
             errorInfo = responseText;

             if (errorInfo.errcode==0) {
             return [true,errorInfo.errstr]
             }; 

             if (errorInfo.errcode==-1) {  // insert
                 
                 
               id_paccnt =  errorInfo.id;
               $("#fAccEdit").find("#bt_add").hide();
               $("#fAccEdit").find("#bt_edit").show();   
               $("#fAccEdit").find("#bt_showtree").show(); 
               $("#fAccEdit").find("#bt_delabon").show();   
               $("#fAccEdit").find("#bt_mainhistory").show();   

               $("#pwork_center").show();
               $("#fpaccnt_params").find("#pid_paccnt").attr('value',id_paccnt );   
               $("#fAccEdit").find("#fid").attr('value',id_paccnt );
               
               jQuery('#paccnt_meters_table').jqGrid('setGridParam',{'postData':{'p_id':id_paccnt}}).trigger('reloadGrid');        
               jQuery('#paccnt_lgt_table').jqGrid('setGridParam',{'postData':{'p_id':id_paccnt}}).trigger('reloadGrid');                       
               
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');  
              // jQuery('#message_zone').dialog('open');
               return [true,errorInfo.errstr]};              
             
             if (errorInfo.errcode==-2) {  // delete
                window.location = 'Abon_en_main.php';
             }
             if (errorInfo.errcode==1) {
                 
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');  
              // jQuery('#message_zone').dialog('open');
              
               CommitJQFormVal(submit_form);
               return [true,errorInfo.errstr]};              
               
             if (errorInfo.errcode==2) {
               jQuery('#message_zone').append(errorInfo.errstr);  
               jQuery('#message_zone').append('<br>');                 
               jQuery('#message_zone').dialog('open');
               return [false,errorInfo.errstr]};   

};

function LoadAccData(data)
{
  //   var str = $.param(data); 
  //alert(str); 
  if (data.errcode===undefined)
  {    
    $("#fAccEdit").resetForm();
    $("#fAccEdit").clearForm();
      
      
    $("#fAccEdit").find("#fid").attr('value',data.id );
    $("#fAccEdit").find("#fbook").attr('value', data.book);
    $("#fAccEdit").find("#fcode").attr('value', data.code);

    $("#fAccEdit").find("#faddr").attr('value', data.addr);
    $("#fAccEdit").find("#faddr_str").attr('value', data.addr_str);

    $("#fAccEdit").find("#fid_abon").attr('value', data.id_abon);
    $("#fAccEdit").find("#fabon").attr('value', data.abon);

    $("#fAccEdit").find("#fid_gtar").attr('value', data.id_gtar);
    $("#fAccEdit").find("#fgtar").attr('value', data.gtar);

    $("#fAccEdit").find("#fid_cntrl").attr('value', data.id_cntrl);
    $("#fAccEdit").find("#fcntrl").attr('value', data.cntrl);
    $("#fAccEdit").find("#fidk_house").attr('value', data.idk_house);
    
    $("#fAccEdit").find("#fn_subs").attr('value', data.n_subs);
    $("#fAccEdit").find("#fheat_area").attr('value', data.heat_area);

    $("#fAccEdit").find("#fnote").attr('value', data.note);
    $("#fAccEdit").find("#fdt_b").datepicker( "setDate" , data.dt_b );
    
    if (data.activ=="t")
    {
      $("#fAccEdit").find("#factiv").prop('checked',true);
    }
    else
    {
      $("#fAccEdit").find("#factiv").prop('checked',false);
    }

    if (data.rem_worker=="t")
    {
      $("#fAccEdit").find("#frem_worker").prop('checked',true);
    }
    else
    {
      $("#fAccEdit").find("#frem_worker").prop('checked',false);
    }

    if (data.not_live=="t")
    {
      $("#fAccEdit").find("#fnot_live").prop('checked',true);
    }
    else
    {
      $("#fAccEdit").find("#fnot_live").prop('checked',false);
    }

    if (data.archive==1)
    {
        
      $("#fAccEdit").find("#archive_label").show();  
      $("#fAccEdit").find("#farchive").prop('checked',true);
      $("#fAccEdit").find("#bt_archabon").hide();
      $("#fAccEdit").find("#fdt_archive").datepicker( "setDate" , data.dt_archive );
      
    }
    else
    {
      $("#fAccEdit").find("#archive_label").hide();
      $("#fAccEdit").find("#bt_archabon").show();
    }

    if (data.pers_cntrl=="t")
    {
      $("#fAccEdit").find("#fpers_cntrl").prop('checked',true);
    }
    else
    {
      $("#fAccEdit").find("#fpers_cntrl").prop('checked',false);
    }

    $("#fpaccnt_params").find("#pid_paccnt").attr('value',data.id );    

    
    
//    $("#fCommonParam").find("#fdt_change").datepicker( "setDate" , data.dt_change_str );
                    
    //if (tree_mode==1)                

    CommitJQFormVal($("#fAccEdit"));
    
    //jQuery('#hist1_table').jqGrid('setGridParam',{'postData':{'p_id':data.id}}).trigger('reloadGrid');
    //EditorLayout.resizeAll();
  }
  else
  {
    $('#message_zone').append(data.errstr);  
    $('#message_zone').append("<br>");                 
    jQuery("#message_zone").dialog('open');
  }
};
//----------------------------------------------------------------------------
function ResetJQFormVal(form) 
{
  form.find('[data_old_value]').each(function() {
        var vlastValue = $(this).attr('data_old_value');
        $(this).attr('value',vlastValue);
        $(this).focus();
  });
        
  form.find('[data_old_checked]').each(function() {
        var vlastValue = $(this).attr('data_old_checked');
        //alert(vlastValue);
        if (vlastValue=='true')
        {
          $(this).prop('checked',true);
        }
        else
        {
          $(this).prop('checked',false);
        }    
    
 });
};

function CommitJQFormVal(form)
{
   form.find('[data_old_value]').each(function() {
            var vlastValue = $(this).attr('value');
             $(this).attr('data_old_value',vlastValue);  
             //alert($(this).attr('data_old_value'));             
   });
        
   form.find('[data_old_checked]').each(function() {
            var vlastValue = $(this).prop('checked');
             $(this).attr('data_old_checked',vlastValue);  
   });    
};
//-----------------------------------------------------------------------------
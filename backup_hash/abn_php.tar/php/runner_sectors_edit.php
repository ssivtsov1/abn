<?php

header('Content-type: text/html; charset=utf-8');

include_once 'Abon_en_func.php';
include_once 'abon_ded_func.php';

session_name("session_kaa");
session_start();

error_reporting(0);

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];
/*
if (isset($_SESSION['id_sess'])) {
  $ids = $_SESSION['id_sess'];

  $res_par = sel_par($ids);
  $row_par = pg_fetch_array($res_par);
  $cons = $row_par['con_str1'];
  $Q = $row_par['qu'];
//	$id=$row_par['id'];
//	$id_e1=$row_par['idreg'];
  $Link = pg_connect($cons);
}
*/
//$lnk_sys = log_s_pgsql("login");
//$lnk1 = $lnk_sys['lnks'];

//if (isset($_POST['id_dov'])) { $idtwn=$_POST['id_dov']; 
//	$QS="update dbusr_var set idtwn=".$idtwn." where id_sess=".$ids;
//	$res_qs=pg_query($lnk1,$QS);
//	echo $idtwn."+++".$QS;
//}
// connect to the database
//$rr=pg_query($Link,$Q);

$table_name = 'prs_runner_sectors';

try {

  if (isset($_POST['oper'])) {
      
    $oper = $_POST['oper'];

    $p_id = sql_field_val('id', 'int');
    $p_name = sql_field_val('name', 'string');
    $p_notes = sql_field_val('notes', 'string');
    
    $p_id_runner = sql_field_val('id_runner', 'int');
   
    $p_dt_b = sql_field_val('dt_b', 'date');
    
    $p_change_date=sql_field_val('change_date','date');
    $p_id_usr = $session_user;
    
    
    
//------------------------------------------------------
    if ($oper == "edit") {

      $QE = "select prs_runner_sector_edit_fun($p_id,$p_name,$p_id_runner,$p_notes,$p_change_date,$p_id_usr);"; 

      $res_e = pg_query($Link, $QE);
      if ($res_e) {
        echo_result(1, 'Data updated');
      } else {
        echo_result(2, pg_last_error($Link));
      }
    }
//------------------------------------------------------
    if ($oper == "add") {

      $QE = "select prs_runner_sector_new_fun($p_name,$p_id_runner,$p_notes,$p_dt_b,$p_id_usr);";         
        
      $res_e = pg_query($Link, $QE);
      if ($res_e)
        echo_result(1, 'Data ins');
      else
        echo_result(2, pg_last_error($Link));
    }
//------------------------------------------------------
    if ($oper == "del") {

      $QE = "select prs_runner_sector_del_fun($p_id,$p_change_date,$p_id_usr);";                 

      $res_e = pg_query($Link, $QE);

      if ($res_e)
        echo_result(1, 'Data deleted');
      else
        echo_result(2, pg_last_error($Link));
    }
  }
} catch (Exception $e) {

  echo echo_result(1, 'Error: ' . $e->getMessage());
}
?>



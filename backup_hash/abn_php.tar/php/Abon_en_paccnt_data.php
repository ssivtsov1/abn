<?php
header("Content-type: application/json;charset=utf-8");

require 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();

$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];

error_reporting(1);
/*
if (isset($_SESSION['id_sess'])) { 
    $ids=$_SESSION['id_sess'];  
    $res_par=sel_par($ids);
    $row_par=pg_fetch_array($res_par);
    $cons=$row_par['con_str1'];
//    $Q=$row_par['qu'];
    $Link=pg_connect($cons) or die("Connection Error: " .pg_last_error($Link) );
}
*/
$id = $_POST['id']; 

if ($id !=0)
{
$SQL = "select acc.id, acc.book, acc.code, acc.id_abon, acc.addr, acc.archive,
    to_char(CASE WHEN acc.archive =1 THEN (select min(dt_b) from clm_paccnt_h where archive =1 and id = $id ) ELSE null END ,'DD.MM.YYYY') as dt_archive,
    address_print_full(acc.addr,4) as addr_str,
    acc.note, 
 (c.last_name||' '||coalesce(c.name,'')||' '||coalesce(c.patron_name,''))::varchar as abon,
  acc.id_cntrl, cn.represent_name as cntrl, acc.id_agreem, acc.id_gtar, tar.sh_nm as gtar,
  acc.n_subs , acc.activ, acc.rem_worker, acc.not_live,acc.idk_house, acc.pers_cntrl ,
  to_char(acc.dt_b, 'DD.MM.YYYY') as dt_b, acc.dt_input, acc.heat_area
from clm_paccnt_tbl as acc 
left join clm_abon_tbl as c on (c.id = acc.id_abon) 
left join prs_persons as cn on (cn.id = acc.id_cntrl)     
left join aqi_grptar_tbl as tar on (tar.id = acc.id_gtar)         
    where acc.id = $id ;";
   
$result = pg_query($Link,$SQL);

 if ($result) {
    $row = pg_fetch_array($result);
    echo json_encode($row);
 }
 else
 {
     echo_result(2,pg_last_error($Link));
 }

}    
 else {
     echo_result(2,"Unknown id!");    
}




?>

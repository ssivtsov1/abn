<?php
header('Content-type: text/html; charset=utf-8');

require_once 'Abon_en_func.php';
require 'abon_ded_func.php';

session_name("session_kaa");
session_start();
//error_reporting(0);
$Link = get_database_link($_SESSION);
$session_user = $_SESSION['ses_usr_id'];

$nam = "Абон-енерго (Звіти)";

start_mpage($nam);
head_addrpage();

print('<link rel="stylesheet" type="text/css" href="css/ded_styles.css" /> ');
print('<link rel="stylesheet" type="text/css" href="css/layout-default-latest.css" /> ');
    
print('<script type="text/javascript" src="js/jquery-ui-1.8.20.custom.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.form.js"></script>');
print('<script type="text/javascript" src="js/jquery.validate.min.js" ></script>');
print('<script type="text/javascript" src="js/jquery.ui.datepicker-uk.js"></script> ');
print('<script type="text/javascript" src="js/jquery.maskedinput-1.3.min.js"></script> ');
print('<script type="text/javascript" src="js/jquery.layout.min-latest.js"></SCRIPT>');
print('<script type="text/javascript" src="reps_main.js"></script> ');

?>

</head>
<body >

<DIV id="pmain_header"> 
   
    <?php main_menu(); ?>

</DIV>
    
<DIV id="pmain_footer">
    
   <a href="javascript:void(0)" id="debug_ls1">show debug window</a> 
   <a href="javascript:void(0)" id="debug_ls2">hide debug window</a> 
   <a href="javascript:void(0)" id="debug_ls3">clear debug window</a>

</DIV>

<DIV id="pmain_content">
    
    <form id="freps_params" name="reps_params" method="post" action="rep_main_build.php">
        
        <DIV id="preps_header">
            <input type="hidden" name="oper" id="foper" value="" />            
            Параметри 
        </DIV>

        <DIV id="preps_buttons">

            <div class="ui-corner-all ui-state-default" id="pActionBar">

                <button name="submitButton" type="submit" class ="btn" id="bt_rep1" value="rep1" >Перелік абонентів</button>

            </div>

        </DIV>
    </FORM>

    
</DIV>

<div id="message_zone" style ="padding: 5px;color: blue;" >  </div>

</body>
</html>


